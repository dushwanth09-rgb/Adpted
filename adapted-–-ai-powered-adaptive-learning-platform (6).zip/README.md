# AdaptEd – AI-Powered Adaptive Learning Platform for Students with Disabilities

**Project ID:** HI-03 – Adaptive Learning for Students with Disabilities  
**Target Compliance:** WCAG 2.1 AA  
**Models:** Gemini 3.8 Flash (`@google/genai`), Bayesian Knowledge Tracing (BKT), Contextual Multi-Armed Bandit (UCB1)

---

## 1. Project Overview

**AdaptEd** is an intelligent, full-stack adaptive learning platform designed for neurodivergent learners, low-vision students, auditory learners, and students with diverse sensory and cognitive requirements.

### Core Philosophy
Traditional educational software forces students into diagnostic labels (e.g., "ADHD student" or "Dyslexic student"), assuming all students under that category require identical accommodations. **AdaptEd never forces medical or disability labels.** Instead, adaptation is strictly governed by:
1. **Explicit Learner Preferences** (Font size, Lexend dyslexia-friendly typeface, high contrast, line spacing, audio narration).
2. **Bayesian Knowledge Tracing (BKT)** (Observed accuracy, slip probability, guess probability, and latent mastery).
3. **Contextual Multi-Armed Bandit** (Format-difficulty pairs calibrated through student comfort feedback).
4. **Preserved Educational Integrity** (Transformations simplify presentation and cognitive load without sacrificing facts, formulas, or standards).

---

## 2. Supported Learning Formats

- **Standard Text**: Traditional, clean prose with section breakdowns.
- **Large Text**: Chunked, high-legibility sentences with high contrast and scalable font size up to 20px.
- **Dyslexia-Friendly Text**: Leverages bottom-weighted typography (Lexend) to eliminate optical letter crowding and inversion.
- **Simplified English**: Active voice, concise sentences, and contextual definitions for specialized scientific vocabulary.
- **Audio Lessons**: Built-in speech synthesis narrator with playback speed controls (0.75x–1.5x) and synchronized live captions.
- **Visual Explanations**: Interactive biochemical and scientific diagrams with labeled inputs, processes, and outputs.
- **Step-by-Step Explanations**: Linear sequential milestones equipped with practical observation tips.
- **Live Captions**: Synchronized real-time captioning accompanying auditory lessons.

---

## 3. Demo Accounts for Evaluation

Quick 1-click switchers are accessible in the top navigation bar. You may also log in manually using the credentials below:

| Role | Name | Email | Password | Active Profile / Focus |
| :--- | :--- | :--- | :--- | :--- |
| **Student A** | Aarav Sharma | `student.a@adapted.demo` | `adapted123` | Grade 6 · Large Text & Audio · Slow/Guided Pace · 35% Prior Mastery |
| **Student B** | Meera Rao | `student.b@adapted.demo` | `adapted123` | Grade 6 · Simplified English & Interactive Visuals · Moderate Pace · 60% Prior Mastery |
| **Teacher** | Ms. Elena Sharma | `teacher@adapted.demo` | `adapted123` | Grade 6 Science · Class Analytics, Ingestion Upload & Pedagogical Alerts |
| **Parent** | Mr. Rajesh Patel | `parent@adapted.demo` | `adapted123` | Authorized Guardian Portal for Aarav Sharma |

---

## 4. Key Architectural Modules

### A. Bayesian Knowledge Tracing (BKT) Engine (`src/server/bkt.ts`)
Calculates the probability $P(L_t)$ that a learner has mastered a specific cognitive skill:
- **$P(L_0)$**: Prior probability of initial mastery (calibrated via 5-question onboarding check).
- **$P(T)$**: Learning transition probability ($0.15$ to $0.18$).
- **$P(G)$**: Guess probability ($0.15$ to $0.25$).
- **$P(S)$**: Slip probability ($0.08$ to $0.12$).

$$P(L_t \mid \text{Correct}) = \frac{P(L_{t-1}) \cdot (1 - P(S))}{P(L_{t-1}) \cdot (1 - P(S)) + (1 - P(L_{t-1})) \cdot P(G)}$$
$$P(L_{t+1}) = P(L_t \mid \text{Obs}) + (1 - P(L_t \mid \text{Obs})) \cdot P(T)$$

### B. Contextual Multi-Armed Bandit
Evaluates seven distinct arms:
`[standard_easy, standard_medium, simplified_easy, simplified_medium, audio_easy, visual_medium, large_text_medium]`
- Balances exploration vs. exploitation using Upper Confidence Bound (UCB1).
- **Hard Autonomy Override**: If a student explicitly activates Large Text, Audio, or Dyslexia font, the bandit respects the accessibility requirement as a hard priority constraint.

### C. AI Adaptation Service (`src/server/aiAdaptation.ts`)
- Uses `@google/genai` with model `gemini-3.8-flash` on the server side when `GEMINI_API_KEY` is present.
- Equipped with a high-fidelity deterministic fallback adapter ensuring instant, 100% reliable evaluation offline or in sandboxes.

### D. The Flagship Compare Demo (`/demo`)
Renders the side-by-side comparison for **Aarav** and **Meera** learning the same core lesson (*Photosynthesis*). Features an animated 6-stage pipeline and a "Run Live Adaptation" button for testing custom curriculum texts.

### E. Firebase Integration (Authentication, Firestore, Storage)
- **Firebase Project ID**: `bubbly-camera-36lcq`
- **Cloud Firestore Database ID**: `ai-studio-adaptedaipowered-7c3e25db-c2d2-49cf-b41a-40b566ef4c3e`
- **Firebase Storage Bucket**: `bubbly-camera-36lcq.firebasestorage.app`
- **Firebase Authentication**: Supports Google Sign-In with popup + Email/password + 1-click evaluation roles.
- **Cloud Firestore Collections**:
  - `/users/{userId}`: User identity and RBAC role.
  - `/learnerProfiles/{userId}`: Sensory preferences, learning pace, and aggregate mastery.
  - `/lessons/{lessonId}`: Curriculum content and multi-variant adaptations.
  - `/masteryStates/{studentId}/topics/{topic}`: Probabilistic BKT records.
  - `/attempts/{attemptId}`: Historical practice quiz answers and mastery transitions.
  - `/lessonFeedback/{feedbackId}`: Student comfort ratings for bandit feedback.
  - `/alerts/{alertId}`: Teacher pedagogical recommendations.
- **Firebase Storage Assets**: Upload and stream PDFs, images, and audio files with size constraints and secure read/write rules.
- **Security Rules**: Enforced via `firestore.rules` and `storage.rules`, successfully deployed to Firebase.

---

## 5. Running the Application

### Development (Port 3000)
```bash
npm run dev
```

### Production Build
```bash
npm run build
npm start
```

### Type Checking & Linting
```bash
npm run lint
```
