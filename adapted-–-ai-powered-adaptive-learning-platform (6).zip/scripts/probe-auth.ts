import { initializeApp, getApps } from 'firebase/app';
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  sendPasswordResetEmail,
  signOut,
} from 'firebase/auth';
import firebaseConfig from '../firebase-applet-config.json' with { type: 'json' };

async function probeAuth() {
  const app = getApps().length > 0 ? getApps()[0] : initializeApp(firebaseConfig);
  const auth = getAuth(app);

  console.log('Testing Firebase Auth on project:', firebaseConfig.projectId);

  // Test 1: Register
  try {
    const cred = await createUserWithEmailAndPassword(auth, `teststudent_${Date.now()}@adapted.demo`, 'TestPass123!');
    console.log('User registered successfully! UID:', cred.user.uid);
  } catch (err: any) {
    console.log('Register error code:', err.code, 'message:', err.message);
  }

  // Test 2: Login
  try {
    const cred = await signInWithEmailAndPassword(auth, 'nonexistent@adapted.demo', 'TestPass123!');
    console.log('User login:', cred.user.uid);
  } catch (err: any) {
    console.log('Login error code:', err.code, 'message:', err.message);
  }

  // Test 3: Password reset
  try {
    await sendPasswordResetEmail(auth, 'student@adapted.demo');
    console.log('Password reset email sent');
  } catch (err: any) {
    console.log('Password reset error code:', err.code, 'message:', err.message);
  }
}

probeAuth();
