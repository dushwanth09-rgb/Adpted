async function probeBucket() {
  const buckets = [
    'bubbly-camera-36lcq.firebasestorage.app',
    'bubbly-camera-36lcq.appspot.com',
  ];

  for (const b of buckets) {
    try {
      const url = `https://firebasestorage.googleapis.com/v0/b/${b}/o`;
      const res = await fetch(url);
      const text = await res.text();
      console.log(`Bucket ${b} status:`, res.status, text);
    } catch (e: any) {
      console.log(`Bucket ${b} fetch error:`, e.message);
    }
  }
}

probeBucket();
