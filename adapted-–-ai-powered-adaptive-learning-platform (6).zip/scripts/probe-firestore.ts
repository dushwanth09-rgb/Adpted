import { initializeApp, getApps } from 'firebase/app';
import { getFirestore, doc, setDoc, getDoc, collection, getDocs } from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json' with { type: 'json' };

async function probeFirestore() {
  const app = getApps().length > 0 ? getApps()[0] : initializeApp(firebaseConfig);
  const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

  console.log('Testing Firestore on database:', firebaseConfig.firestoreDatabaseId);

  try {
    const testDocRef = doc(db, 'users', 'test_probe_user');
    await setDoc(testDocRef, { name: 'Probe User', role: 'student', updatedAt: new Date().toISOString() });
    console.log('Direct write to users/test_probe_user succeeded');
  } catch (err: any) {
    console.log('Direct write error code:', err.code, 'message:', err.message);
  }

  try {
    const snap = await getDoc(doc(db, 'users', 'test_probe_user'));
    console.log('Direct read exists?:', snap.exists());
  } catch (err: any) {
    console.log('Direct read error code:', err.code, 'message:', err.message);
  }
}

probeFirestore();
