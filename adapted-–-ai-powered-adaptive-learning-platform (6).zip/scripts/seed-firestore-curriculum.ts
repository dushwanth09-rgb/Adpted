import { initializeApp } from 'firebase/app';
import { getFirestore, doc, setDoc } from 'firebase/firestore';
import fs from 'fs';
import path from 'path';
import firebaseConfig from '../firebase-applet-config.json' with { type: 'json' };

async function seedCurriculumToFirestore() {
  console.log('--- Seeding Initial Curriculum & Profiles to Cloud Firestore ---');
  const app = initializeApp(firebaseConfig);
  const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

  const dbFilePath = path.resolve(process.cwd(), '.data', 'adapted_db.json');
  if (!fs.existsSync(dbFilePath)) {
    console.log('No local db file found at:', dbFilePath);
    return;
  }

  const localDb = JSON.parse(fs.readFileSync(dbFilePath, 'utf-8'));

  // 1. Seed Lessons
  for (const lesson of localDb.lessons || []) {
    try {
      await setDoc(doc(db, 'lessons', lesson.id), lesson, { merge: true });
      console.log(`✅ Seeded lesson: ${lesson.title} (${lesson.id})`);
    } catch (err: any) {
      console.error(`❌ Failed to seed lesson ${lesson.id}:`, err.message);
    }
  }

  // 2. Seed Users
  for (const user of localDb.users || []) {
    try {
      const { passwordHash, ...cleanUser } = user;
      await setDoc(doc(db, 'users', user.id), cleanUser, { merge: true });
      console.log(`✅ Seeded user: ${user.name} (${user.role})`);
    } catch (err: any) {
      console.error(`❌ Failed to seed user ${user.id}:`, err.message);
    }
  }

  // 3. Seed Learner Profiles
  for (const [userId, profile] of Object.entries(localDb.learnerProfiles || {})) {
    try {
      await setDoc(doc(db, 'learnerProfiles', userId), profile as any, { merge: true });
      console.log(`✅ Seeded learner profile: ${(profile as any).name}`);
    } catch (err: any) {
      console.error(`❌ Failed to seed profile ${userId}:`, err.message);
    }
  }

  // 5. Seed Teacher Records
  const teachers = [
    {
      teacherId: 'user_teacher_1',
      name: 'Ms. Elena Sharma',
      email: 'teacher@adapted.demo',
      school: 'AdaptEd Demonstration Academy',
      subjects: ['Science', 'Biology', 'Inclusive Learning'],
      authorized: true,
      createdAt: new Date().toISOString(),
    },
  ];
  for (const t of teachers) {
    try {
      await setDoc(doc(db, 'teacherRecords', t.teacherId), t, { merge: true });
      await setDoc(doc(db, 'teachers', t.teacherId), t, { merge: true });
      console.log(`✅ Seeded teacher record: ${t.name}`);
    } catch (err: any) {
      console.error(`❌ Failed to seed teacher ${t.teacherId}:`, err.message);
    }
  }

  // 6. Seed Guardian Records
  const guardians = [
    {
      guardianId: 'user_guardian_1',
      name: 'Mr. Rajesh Patel',
      email: 'parent@adapted.demo',
      studentIds: ['user_student_a'],
      relationship: 'Father',
      authorized: true,
      createdAt: new Date().toISOString(),
    },
  ];
  for (const g of guardians) {
    try {
      await setDoc(doc(db, 'guardianRecords', g.guardianId), g, { merge: true });
      await setDoc(doc(db, 'guardians', g.guardianId), g, { merge: true });
      console.log(`✅ Seeded guardian record: ${g.name}`);
    } catch (err: any) {
      console.error(`❌ Failed to seed guardian ${g.guardianId}:`, err.message);
    }
  }

  console.log('🎉 Cloud Firestore Database seeded successfully!');
  process.exit(0);
}

seedCurriculumToFirestore().catch((err) => {
  console.error('Fatal seed error:', err);
  process.exit(1);
});
