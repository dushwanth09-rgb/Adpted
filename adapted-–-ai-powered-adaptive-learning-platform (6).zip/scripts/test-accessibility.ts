/**
 * Audit Accessibility Features across UI & Components:
 * 1. Large text
 * 2. Audio lessons & speech controls
 * 3. Captions
 * 4. Simplified language variant
 * 5. Keyboard navigation (tabIndex, keydown, focus styling)
 * 6. Screen-reader friendly labels (aria-labels, role, aria-live)
 * 7. Flexible learning pace
 */

import fs from 'fs';
import path from 'path';

function testAccessibility() {
  console.log('Auditing Accessibility Features in AdaptEd...\n');

  const cssPath = path.resolve(process.cwd(), 'src/index.css');
  const accCtxPath = path.resolve(process.cwd(), 'src/context/AccessibilityContext.tsx');
  const playerPath = path.resolve(process.cwd(), 'src/pages/LessonPlayer.tsx');
  const navbarPath = path.resolve(process.cwd(), 'src/components/Navbar.tsx');
  const modalPath = path.resolve(process.cwd(), 'src/components/AccessibilityModal.tsx');
  const audioBarPath = path.resolve(process.cwd(), 'src/components/AudioPlayerBar.tsx');

  const css = fs.readFileSync(cssPath, 'utf-8');
  const accCtx = fs.readFileSync(accCtxPath, 'utf-8');
  const player = fs.existsSync(playerPath) ? fs.readFileSync(playerPath, 'utf-8') : '';
  const navbar = fs.existsSync(navbarPath) ? fs.readFileSync(navbarPath, 'utf-8') : '';
  const modal = fs.existsSync(modalPath) ? fs.readFileSync(modalPath, 'utf-8') : '';
  const audioBar = fs.existsSync(audioBarPath) ? fs.readFileSync(audioBarPath, 'utf-8') : '';

  // 1. Large text
  const hasLargeText = css.includes('text-size-lg') && css.includes('text-size-xl') && accCtx.includes('increaseTextSize');
  console.log('1. Large Text Support:', hasLargeText ? '✅ PASS' : '❌ FAIL');

  // 2. Audio lessons
  const hasAudio = accCtx.includes('speechSynthesis') && accCtx.includes('speakText');
  console.log('2. Audio Lessons & Speech Synthesis:', hasAudio ? '✅ PASS' : '❌ FAIL');

  // 3. Captions
  const hasCaptions = (
    player.includes('caption') ||
    player.includes('Caption') ||
    accCtx.includes('captions') ||
    modal.includes('captions') ||
    audioBar.includes('Captions') ||
    audioBar.includes('caption')
  );
  console.log('3. Captions & Synced Text Display:', hasCaptions ? '✅ PASS' : '❌ FAIL');

  // 4. Simplified language
  const hasSimplified = player.includes('simplified') || player.includes('Simplified') || css.includes('simplified');
  console.log('4. Simplified Language Mode:', hasSimplified ? '✅ PASS' : '❌ FAIL');

  // 5. Keyboard navigation
  const hasKeyboard = (player.includes('onKeyDown') || player.includes('tabIndex') || modal.includes('keydown') || modal.includes('tabIndex') || navbar.includes('aria-label'));
  console.log('5. Keyboard Navigation & Focus Guards:', hasKeyboard ? '✅ PASS' : '❌ FAIL');

  // 6. Screen-reader friendly labels
  const hasAria = (player.includes('aria-label') || navbar.includes('aria-label') || modal.includes('aria-label'));
  console.log('6. Screen-Reader ARIA Labels:', hasAria ? '✅ PASS' : '❌ FAIL');

  // 7. Flexible learning pace
  const hasPace = (accCtx.includes('speechRate') || player.includes('pace') || player.includes('Pace'));
  console.log('7. Flexible Learning Pace & Speech Rates:', hasPace ? '✅ PASS' : '❌ FAIL');

  if (hasLargeText && hasAudio && hasCaptions && hasSimplified && hasAria && hasPace) {
    console.log('\n🎉 ALL ACCESSIBILITY AUDIT CHECKS PASSED!');
  } else {
    throw new Error('Accessibility audit failed');
  }
}

testAccessibility();
