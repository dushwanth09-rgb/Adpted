/**
 * Test Adaptive Learning Engine:
 * 1. BKT updates student knowledge mastery after quiz attempts
 * 2. Contextual bandit selects appropriate learning formats
 * 3. Student performance changes next lesson's difficulty/format
 * 4. Explicit learner preferences override AI recommendations
 */

import { updateMasteryBKT, recommendFormat, INITIAL_ARMS, DEFAULT_BKT_PARAMS } from '../src/server/bkt.ts';

function testAdaptiveEngine() {
  console.log('Testing Adaptive Learning Engine...\n');

  // 1. BKT update verification
  const prior = 0.40;
  const correct = updateMasteryBKT(prior, true, DEFAULT_BKT_PARAMS.photosynthesis);
  const incorrect = updateMasteryBKT(prior, false, DEFAULT_BKT_PARAMS.photosynthesis);

  console.log('1. BKT Mastery Updates:');
  console.log(`   - Prior Mastery: ${prior}`);
  console.log(`   - After Correct Answer: ${correct.updatedMastery} (Posterior: ${correct.posterior}, Expected Acc: ${correct.expectedAccuracy})`);
  console.log(`   - After Incorrect Answer: ${incorrect.updatedMastery} (Posterior: ${incorrect.posterior}, Expected Acc: ${incorrect.expectedAccuracy})`);

  if (correct.updatedMastery <= prior || incorrect.updatedMastery >= prior) {
    throw new Error('BKT math assertion failed: correct must increase mastery and incorrect must decrease it.');
  }
  console.log('   ✅ BKT Mathematical Invariants Verified.');

  // 2. Contextual Bandit format selection
  console.log('\n2. Contextual Bandit Format Selection:');
  const banditLow = recommendFormat(INITIAL_ARMS, {}, 0.20);
  const banditHigh = recommendFormat(INITIAL_ARMS, {}, 0.85);

  console.log(`   - Low Mastery (0.20): Selected ${banditLow.format} (${banditLow.difficulty}) - ${banditLow.explanation}`);
  console.log(`   - High Mastery (0.85): Selected ${banditHigh.format} (${banditHigh.difficulty}) - ${banditHigh.explanation}`);

  if (!banditLow.format || !banditHigh.format) {
    throw new Error('Bandit did not return valid format');
  }
  console.log('   ✅ Contextual Bandit Selection Verified.');

  // 3. Performance alters difficulty/format
  console.log("\n3. Performance-Driven Format/Difficulty Adaptation:");
  console.log(`   - Struggling learner format: ${banditLow.format} difficulty: ${banditLow.difficulty}`);
  console.log(`   - Advanced learner format: ${banditHigh.format} difficulty: ${banditHigh.difficulty}`);

  if (banditLow.difficulty === 'advanced' && banditHigh.difficulty === 'easy') {
    throw new Error('Difficulty adaptation inverted!');
  }
  console.log('   ✅ Difficulty and format dynamically adapts based on mastery.');

  // 4. Explicit preference overrides AI recommendation
  console.log('\n4. Explicit Preference Overriding AI Recommendation:');
  const explicitLargeText = recommendFormat(
    INITIAL_ARMS,
    { largeTextPreferred: true },
    0.85 // even with high mastery where bandit might prefer standard
  );
  console.log(`   - With largeTextPreferred=true: Format=${explicitLargeText.format}, isOverride=${explicitLargeText.isOverrideFromPreference}`);

  const explicitAudio = recommendFormat(
    INITIAL_ARMS,
    { audioPreferred: true, visualPreferred: false },
    0.75
  );
  console.log(`   - With audioPreferred=true: Format=${explicitAudio.format}, isOverride=${explicitAudio.isOverrideFromPreference}`);

  if (explicitLargeText.format !== 'large_text' || !explicitLargeText.isOverrideFromPreference) {
    throw new Error('Explicit large text preference failed to override AI recommendation');
  }
  if (explicitAudio.format !== 'audio' || !explicitAudio.isOverrideFromPreference) {
    throw new Error('Explicit audio preference failed to override AI recommendation');
  }
  console.log('   ✅ Explicit Learner Preferences strictly override AI suggestions.');

  console.log('\n🎉 ALL ADAPTIVE ENGINE AUDIT CHECKS PASSED!');
}

testAdaptiveEngine();
