/**
 * Test Firestore Database Persistence & Session Lifecycle
 * 
 * Tests:
 * 1. Student profile saving & retrieval
 * 2. Learning preferences saving
 * 3. Quiz attempt submission & score recording
 * 4. BKT Bayesian Knowledge Tracing mastery value updating & persistence
 * 5. Logout and re-login data retention
 */

const BASE_URL = 'http://localhost:3000';

async function testPersistenceLifecycle() {
  console.log('Testing Firestore Database & Persistence Lifecycle...');

  // 1. Login as Student A
  const loginRes = await fetch(`${BASE_URL}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email: 'student.a@adapted.demo',
      password: 'adapted123',
    }),
  });

  if (!loginRes.ok) {
    throw new Error(`Login failed with status ${loginRes.status}`);
  }

  const { token, user, profile } = await loginRes.json();
  console.log('✅ Logged in as:', user.email, 'Role:', user.role);

  // 2. Update learning preferences
  const updateRes = await fetch(`${BASE_URL}/api/profile`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({
      learningPace: 'slow',
      preferences: {
        primaryFormat: 'large_text',
        largeText: true,
        dyslexiaFont: true,
        highContrast: true,
        speechRate: 0.85,
      },
    }),
  });

  if (!updateRes.ok) {
    throw new Error(`Profile update failed: ${updateRes.status}`);
  }
  const updatedProfile = await updateRes.json();
  console.log('✅ Updated preferences:', {
    pace: updatedProfile.learningPace,
    largeText: updatedProfile.preferences.largeText,
    dyslexiaFont: updatedProfile.preferences.dyslexiaFont,
  });

  // 3. Submit quiz answer to trigger BKT update
  const quizRes = await fetch(`${BASE_URL}/api/quiz/answer`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({
      lessonId: 'lesson_photosynthesis',
      questionId: 'q1',
      selectedOption: 0,
      topic: 'photosynthesis',
    }),
  });

  if (!quizRes.ok) {
    throw new Error(`Quiz answer submission failed: ${quizRes.status}`);
  }
  const quizData = await quizRes.json();
  console.log('✅ Quiz attempt recorded:', {
    isCorrect: quizData.isCorrect,
    masteryBefore: quizData.bkt.pMasteryBefore,
    masteryAfter: quizData.bkt.pMasteryAfter,
    delta: quizData.bkt.delta,
  });

  // 4. Simulate Logout
  console.log('🔄 Simulating session logout...');

  // 5. Re-login as Student A
  const reLoginRes = await fetch(`${BASE_URL}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email: 'student.a@adapted.demo',
      password: 'adapted123',
    }),
  });

  const reLoginData = await reLoginRes.json();
  const reToken = reLoginData.token;

  // 6. Verify data remains available after logout/login
  const progressRes = await fetch(`${BASE_URL}/api/analytics/progress`, {
    headers: { Authorization: `Bearer ${reToken}` },
  });
  const progressData = await progressRes.json();

  const persistedPrefs = progressData.profile.preferences;
  const persistedTopicMastery = progressData.topics['photosynthesis'];
  const hasAttempts = progressData.recentAttempts.length > 0;

  console.log('✅ Post-relogin verified data:');
  console.log('   - Large text preference retained:', persistedPrefs.largeText === true);
  console.log('   - Dyslexia font retained:', persistedPrefs.dyslexiaFont === true);
  console.log('   - BKT mastery value retained:', persistedTopicMastery?.pMastery);
  console.log('   - Recent quiz attempts retained:', hasAttempts, `(${progressData.recentAttempts.length} attempts logged)`);

  if (persistedPrefs.largeText && persistedTopicMastery && hasAttempts) {
    console.log('\n🎉 ALL PERSISTENCE CHECKS PASSED: Profiles, progress, quiz attempts, and BKT mastery persist across sessions!');
  } else {
    throw new Error('Data persistence check failed');
  }
}

testPersistenceLifecycle().catch((err) => {
  console.error('Persistence test failed:', err);
  process.exit(1);
});
