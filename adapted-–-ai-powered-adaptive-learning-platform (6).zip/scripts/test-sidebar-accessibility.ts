import fs from 'fs';
import path from 'path';

function runSidebarAudit() {
  console.log('===============================================================');
  console.log(' AUDIT: Left Sidebar & Accessibility Integration Verification');
  console.log('===============================================================');

  const appFile = fs.readFileSync(path.resolve(process.cwd(), 'src/App.tsx'), 'utf-8');
  const sidebarFile = fs.readFileSync(path.resolve(process.cwd(), 'src/components/Sidebar.tsx'), 'utf-8');
  const navbarFile = fs.readFileSync(path.resolve(process.cwd(), 'src/components/Navbar.tsx'), 'utf-8');
  const toolbarFile = fs.readFileSync(path.resolve(process.cwd(), 'src/components/AccessibilityToolbar.tsx'), 'utf-8');
  const contextFile = fs.readFileSync(path.resolve(process.cwd(), 'src/context/AccessibilityContext.tsx'), 'utf-8');
  const cssFile = fs.readFileSync(path.resolve(process.cwd(), 'src/index.css'), 'utf-8');

  // Check 1: Floating right-side icon removed from Navbar
  const navbarHasRightAccess = navbarFile.includes('<span className="hidden sm:inline">Access</span>');
  console.log('Check 1 - Old right-side access button removed from Navbar:', !navbarHasRightAccess ? 'PASS' : 'FAIL');

  // Check 2: Sidebar component exists and is imported in App.tsx
  const appHasSidebar = appFile.includes('<Sidebar') && appFile.includes("import { Sidebar } from './components/Sidebar.tsx';");
  console.log('Check 2 - Left Sidebar mounted in App layout:', appHasSidebar ? 'PASS' : 'FAIL');

  // Check 3: Sidebar has Accessibility Settings item with label and styling
  const sidebarHasAccessItem =
    sidebarFile.includes('Accessibility Settings') &&
    sidebarFile.includes('Large Text · Audio · Contrast') &&
    sidebarFile.includes('isAccessibilityOpen');
  console.log('Check 3 - Accessibility Settings item in Left Sidebar:', sidebarHasAccessItem ? 'PASS' : 'FAIL');

  // Check 4: Responsive sidebar (expanded, collapsed tooltip, mobile off-canvas drawer)
  const sidebarIsResponsive =
    sidebarFile.includes('w-64') &&
    sidebarFile.includes('w-20') &&
    sidebarFile.includes('isMobileOpen') &&
    sidebarFile.includes('lg:hidden');
  console.log('Check 4 - Responsive sidebar with collapsed tooltips and mobile drawer:', sidebarIsResponsive ? 'PASS' : 'FAIL');

  // Check 5: All 8 required accessibility options
  const reqOptions = [
    { name: 'Large Text Mode', check: toolbarFile.includes('Large Text Mode') && contextFile.includes('largeTextMode') },
    { name: 'Simplified English', check: toolbarFile.includes('Simplified English') && contextFile.includes('simplifiedEnglish') },
    { name: 'Audio-Based Learning', check: toolbarFile.includes('Audio-Based Learning') && contextFile.includes('audioLearning') },
    { name: 'Text-to-Speech (TTS)', check: toolbarFile.includes('Text-to-Speech (TTS)') && contextFile.includes('textToSpeechEnabled') },
    { name: 'High Contrast Mode', check: toolbarFile.includes('High Contrast Mode') && contextFile.includes('highContrast') },
    { name: 'Keyboard Navigation', check: toolbarFile.includes('Keyboard Navigation') && contextFile.includes('keyboardNavigation') },
    { name: 'Screen Reader Support', check: toolbarFile.includes('Screen Reader Support') && contextFile.includes('screenReaderSupport') },
    { name: 'Reduce Animations', check: toolbarFile.includes('Reduce Animations') && contextFile.includes('reducedMotion') },
  ];

  console.log('\n--- Checking 8 Required Accessibility Options in Panel & Context ---');
  let allOptionsPass = true;
  for (const opt of reqOptions) {
    console.log(`- ${opt.name}: ${opt.check ? 'PASS' : 'FAIL'}`);
    if (!opt.check) allOptionsPass = false;
  }

  // Check 6: Preserved existing features
  const preservedFeatures =
    contextFile.includes('dyslexiaFont') &&
    contextFile.includes('darkMode') &&
    contextFile.includes('spacedReading') &&
    contextFile.includes('speechRate');
  console.log('\nCheck 6 - Existing features (Dyslexia font, Dark mode, Spacing, Speed) preserved:', preservedFeatures ? 'PASS' : 'FAIL');

  // Check 7: Global keyboard CSS
  const keyboardCss = cssFile.includes('html.keyboard-mode');
  console.log('Check 7 - Keyboard focus ring CSS styles in index.css:', keyboardCss ? 'PASS' : 'FAIL');

  console.log('\n===============================================================');
  const overallPass = !navbarHasRightAccess && appHasSidebar && sidebarHasAccessItem && sidebarIsResponsive && allOptionsPass && preservedFeatures && keyboardCss;
  console.log('OVERALL AUDIT RESULT:', overallPass ? '100% PASS' : 'FAIL');
  console.log('===============================================================');
}

runSidebarAudit();
