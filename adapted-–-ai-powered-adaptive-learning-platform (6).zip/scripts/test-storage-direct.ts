import { initializeApp, getApps } from 'firebase/app';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import firebaseConfig from '../firebase-applet-config.json' with { type: 'json' };

async function testStorage() {
  console.log('Testing storage on bucket:', firebaseConfig.storageBucket);
  const app = getApps().length > 0 ? getApps()[0] : initializeApp(firebaseConfig);
  const storage = getStorage(app);

  const testData = new Uint8Array([72, 101, 108, 108, 111, 32, 65, 100, 97, 112, 116, 69, 100]); // "Hello AdaptEd"
  const storageRef = ref(storage, 'test/test.txt');

  try {
    const uploadResult = await uploadBytes(storageRef, testData, {
      contentType: 'text/plain',
    });
    console.log('Upload success:', uploadResult.metadata.fullPath);
    const downloadUrl = await getDownloadURL(storageRef);
    console.log('Download URL:', downloadUrl);
  } catch (err: any) {
    console.error('Storage upload error code:', err?.code);
    console.error('Storage upload error message:', err?.message);
    console.error('Storage upload serverResponse:', err?.serverResponse);
  }
}

testStorage();
