/**
 * Test User Roles & Access Control Scoping:
 * 1. Students can access only their own private learning records.
 * 2. Teachers can access only their authorized students.
 * 3. Guardians can access only students linked to them.
 * 4. Users cannot grant themselves teacher or administrator privileges.
 */

const BASE_URL = 'http://localhost:3000';

async function testUserRoles() {
  console.log('Testing User Roles & Access Control...\n');

  // 1. Authenticate as Student A
  const sRes = await fetch(`${BASE_URL}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'student.a@adapted.demo', password: 'adapted123' }),
  });
  const sData = await sRes.json();
  const sToken = sData.token;

  // Student attempts to access Teacher Dashboard -> Must return 403
  const sTeacherAccess = await fetch(`${BASE_URL}/api/teacher/students`, {
    headers: { Authorization: `Bearer ${sToken}` },
  });
  console.log('1. Student accessing Teacher endpoint status:', sTeacherAccess.status, '(Expected 403)');
  if (sTeacherAccess.status !== 403) {
    throw new Error('Security violation: Student was able to access teacher endpoints');
  }

  // Student attempts to access Guardian Dashboard -> Must return 403
  const sGuardianAccess = await fetch(`${BASE_URL}/api/guardian/overview`, {
    headers: { Authorization: `Bearer ${sToken}` },
  });
  console.log('2. Student accessing Guardian endpoint status:', sGuardianAccess.status, '(Expected 403)');
  if (sGuardianAccess.status !== 403) {
    throw new Error('Security violation: Student was able to access guardian endpoints');
  }

  // Student accesses own private records
  const sPrivateAccess = await fetch(`${BASE_URL}/api/analytics/progress`, {
    headers: { Authorization: `Bearer ${sToken}` },
  });
  const sProgress = await sPrivateAccess.json();
  console.log('3. Student accessing own private records:', sProgress.profile.userId === sData.user.id);
  if (sProgress.profile.userId !== sData.user.id) {
    throw new Error('Data leak: Student received someone else profile');
  }

  // 2. Authenticate as Teacher
  const tRes = await fetch(`${BASE_URL}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'teacher@adapted.demo', password: 'adapted123' }),
  });
  const tData = await tRes.json();
  const tToken = tData.token;

  // Teacher accesses students list
  const tStudentsRes = await fetch(`${BASE_URL}/api/teacher/students`, {
    headers: { Authorization: `Bearer ${tToken}` },
  });
  const tStudentsData = await tStudentsRes.json();
  console.log('4. Teacher authorized students access:', tStudentsRes.status === 200, `(${tStudentsData.students.length} students enrolled)`);
  if (tStudentsRes.status !== 200 || !tStudentsData.students) {
    throw new Error('Teacher could not access authorized students');
  }

  // 3. Authenticate as Guardian
  const gRes = await fetch(`${BASE_URL}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'parent@adapted.demo', password: 'adapted123' }),
  });
  const gData = await gRes.json();
  const gToken = gData.token;

  // Guardian accesses linked student overview
  const gOverviewRes = await fetch(`${BASE_URL}/api/guardian/overview`, {
    headers: { Authorization: `Bearer ${gToken}` },
  });
  const gOverviewData = await gOverviewRes.json();
  console.log('5. Guardian linked student access:', gOverviewRes.status === 200, `(Linked to: ${gOverviewData.student.name})`);
  if (gOverviewRes.status !== 200 || !gOverviewData.student) {
    throw new Error('Guardian could not access linked student');
  }

  // 4. Test privilege self-escalation block
  const attackRes = await fetch(`${BASE_URL}/api/auth/signup`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name: 'Unverified Hacker',
      email: `unverified_hacker_${Date.now()}@gmail.com`,
      password: 'password123',
      role: 'teacher', // Attempting to self-grant teacher role
    }),
  });
  console.log('6. Role self-escalation attempt status:', attackRes.status, '(Expected 403 Forbidden)');
  if (attackRes.status !== 403) {
    throw new Error('Privilege escalation vulnerability: User was able to register as teacher without authorization key');
  }

  console.log('\n🎉 ALL USER ROLE & ACCESS CONTROL CHECKS PASSED!');
}

testUserRoles().catch((err) => {
  console.error('Role test failed:', err);
  process.exit(1);
});
