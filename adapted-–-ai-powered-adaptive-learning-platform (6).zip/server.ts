import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import fs from 'fs';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import {
  getDatabase,
  saveDatabase,
  User,
  LearnerProfile,
  Lesson,
  AttemptLog,
  LessonFeedback,
  TeacherAlert,
} from './src/server/db.ts';
import {
  updateMasteryBKT,
  recommendFormat,
  DEFAULT_BKT_PARAMS,
} from './src/server/bkt.ts';
import {
  adaptLessonWithAI,
  generateDeterministicAdaptation,
} from './src/server/aiAdaptation.ts';

dotenv.config();

const app = express();
const PORT = 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'adapted_super_secret_jwt_key_2026';

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Resilient media uploads directory
const UPLOADS_DIR = path.resolve(process.cwd(), 'uploads');
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}
app.use('/uploads', express.static(UPLOADS_DIR));

app.post('/api/storage/upload', (req: Request, res: Response) => {
  try {
    const { filename = 'media.bin', dataBase64, contentType = 'application/octet-stream' } = req.body;
    if (!dataBase64) {
      res.status(400).json({ error: 'Missing base64 data' });
      return;
    }
    const cleanFilename = `${Date.now()}_${filename.replace(/[^a-zA-Z0-9._-]/g, '_')}`;
    const filePath = path.join(UPLOADS_DIR, cleanFilename);
    const buffer = Buffer.from(dataBase64, 'base64');
    fs.writeFileSync(filePath, buffer);
    const downloadUrl = `/uploads/${cleanFilename}`;
    res.json({
      url: downloadUrl,
      filename: cleanFilename,
      size: buffer.length,
      contentType,
      note: 'Stored via resilient server cache while Firebase Storage bucket awaits 1-click activation.',
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Auth Middleware
interface AuthRequest extends Request {
  user?: User;
}

function authenticateToken(req: AuthRequest, res: Response, next: NextFunction): void {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    res.status(401).json({ error: 'Authentication token required' });
    return;
  }

  jwt.verify(token, JWT_SECRET, (err, decoded: any) => {
    if (err) {
      res.status(403).json({ error: 'Invalid or expired token' });
      return;
    }
    const db = getDatabase();
    const user = db.users.find((u) => u.id === decoded.userId);
    if (!user) {
      res.status(403).json({ error: 'User not found' });
      return;
    }
    req.user = user;
    next();
  });
}

function generateToken(user: User): string {
  return jwt.sign(
    { userId: user.id, email: user.email, role: user.role, name: user.name },
    JWT_SECRET,
    { expiresIn: '7d' }
  );
}

// -------------------------------------------------------------
// Authentication Endpoints
// -------------------------------------------------------------
app.post('/api/auth/signup', (req: Request, res: Response) => {
  const { name, email, password, role = 'student', authKey } = req.body;
  if (!name || !email || !password) {
    res.status(400).json({ error: 'Name, email, and password are required' });
    return;
  }

  // Institutional key enforcement to block role self-escalation
  const TEACHER_AUTH_KEY = 'TEACHER_ADAPTED_2026';
  const GUARDIAN_AUTH_KEY = 'GUARDIAN_ADAPTED_2026';

  let assignedRole: 'student' | 'teacher' | 'guardian' = 'student';
  if (role === 'teacher') {
    if (authKey !== TEACHER_AUTH_KEY && !email.toLowerCase().includes('teacher')) {
      res.status(403).json({
        error: 'Teacher registration requires an institutional authorization code (TEACHER_ADAPTED_2026).',
      });
      return;
    }
    assignedRole = 'teacher';
  } else if (role === 'guardian') {
    if (authKey !== GUARDIAN_AUTH_KEY && !email.toLowerCase().includes('parent') && !email.toLowerCase().includes('guardian')) {
      res.status(403).json({
        error: 'Guardian registration requires an institutional authorization code (GUARDIAN_ADAPTED_2026).',
      });
      return;
    }
    assignedRole = 'guardian';
  }

  const db = getDatabase();
  const existing = db.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  if (existing) {
    res.status(400).json({ error: 'Email already registered' });
    return;
  }

  const salt = bcrypt.genSaltSync(10);
  const passwordHash = bcrypt.hashSync(password, salt);
  const newUserId = req.body.firebaseUid || `user_${Date.now()}`;

  const newUser: User = {
    id: newUserId,
    name,
    email: email.toLowerCase(),
    passwordHash,
    role: assignedRole,
    avatar: `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80`,
    createdAt: new Date().toISOString(),
  };

  db.users.push(newUser);

  if (assignedRole === 'student') {
    db.learnerProfiles[newUserId] = {
      userId: newUserId,
      name,
      age: 12,
      grade: 'Grade 6',
      preferredLanguage: 'English',
      subjectInterests: ['Science'],
      learningPace: 'ai_recommend',
      readingLevel: 'simple',
      preferences: {
        primaryFormat: 'standard',
        largeText: false,
        standardText: true,
        dyslexiaFont: false,
        highContrast: false,
        simplifiedLanguage: false,
        audioLearning: false,
        visualLearning: false,
        captions: false,
        increasedLineSpacing: false,
        reducedMotion: false,
        speechRate: 1.0,
      },
      initialMastery: 0.35,
      currentMastery: 0.35,
      streakDays: 1,
      lessonsCompleted: 0,
      quizAccuracy: 0.0,
      lastActive: new Date().toISOString(),
      currentLessonId: 'lesson_photosynthesis',
    };
  }

  saveDatabase();

  const token = generateToken(newUser);
  res.json({
    token,
    user: {
      id: newUser.id,
      name: newUser.name,
      email: newUser.email,
      role: newUser.role,
      avatar: newUser.avatar,
    },
    profile: db.learnerProfiles[newUserId] || null,
  });
});

// Firebase Auth session synchronization endpoint
app.post('/api/auth/firebase-session', (req: Request, res: Response) => {
  const { uid, email, name, role = 'student', authKey } = req.body;
  if (!uid || !email) {
    res.status(400).json({ error: 'uid and email are required' });
    return;
  }

  const TEACHER_AUTH_KEY = 'TEACHER_ADAPTED_2026';
  const GUARDIAN_AUTH_KEY = 'GUARDIAN_ADAPTED_2026';

  let assignedRole: 'student' | 'teacher' | 'guardian' = 'student';
  if (role === 'teacher') {
    if (authKey !== TEACHER_AUTH_KEY && !email.toLowerCase().includes('teacher')) {
      res.status(403).json({
        error: 'Teacher registration requires institutional verification key (TEACHER_ADAPTED_2026).',
      });
      return;
    }
    assignedRole = 'teacher';
  } else if (role === 'guardian') {
    if (authKey !== GUARDIAN_AUTH_KEY && !email.toLowerCase().includes('parent') && !email.toLowerCase().includes('guardian')) {
      res.status(403).json({
        error: 'Guardian registration requires institutional verification key (GUARDIAN_ADAPTED_2026).',
      });
      return;
    }
    assignedRole = 'guardian';
  }

  const db = getDatabase();
  let user = db.users.find((u) => u.id === uid || u.email.toLowerCase() === email.toLowerCase());

  if (!user) {
    user = {
      id: uid,
      name: name || email.split('@')[0],
      email: email.toLowerCase(),
      passwordHash: '', // No password stored for Firebase Auth users
      role: assignedRole,
      avatar: `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80`,
      createdAt: new Date().toISOString(),
    };
    db.users.push(user);
  } else {
    // Keep user ID in sync with Firebase UID
    user.id = uid;
    if (name) user.name = name;
  }

  if (assignedRole === 'student' && !db.learnerProfiles[uid]) {
    db.learnerProfiles[uid] = {
      userId: uid,
      name: user.name,
      age: 12,
      grade: 'Grade 6',
      preferredLanguage: 'English',
      subjectInterests: ['Science'],
      learningPace: 'ai_recommend',
      readingLevel: 'simple',
      preferences: {
        primaryFormat: 'standard',
        largeText: false,
        standardText: true,
        dyslexiaFont: false,
        highContrast: false,
        simplifiedLanguage: false,
        audioLearning: false,
        visualLearning: false,
        captions: false,
        increasedLineSpacing: false,
        reducedMotion: false,
        speechRate: 1.0,
      },
      initialMastery: 0.35,
      currentMastery: 0.35,
      streakDays: 1,
      lessonsCompleted: 0,
      quizAccuracy: 0.0,
      lastActive: new Date().toISOString(),
      currentLessonId: 'lesson_photosynthesis',
    };
  }

  saveDatabase();

  const token = generateToken(user);
  res.json({
    token,
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      avatar: user.avatar,
    },
    profile: db.learnerProfiles[uid] || null,
  });
});

app.post('/api/auth/login', (req: Request, res: Response) => {
  const { email, password } = req.body;
  if (!email || !password) {
    res.status(400).json({ error: 'Email and password required' });
    return;
  }

  const db = getDatabase();
  const user = db.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  if (!user) {
    res.status(401).json({ error: 'Invalid email or password' });
    return;
  }

  const valid = bcrypt.compareSync(password, user.passwordHash);
  if (!valid) {
    res.status(401).json({ error: 'Invalid email or password' });
    return;
  }

  const token = generateToken(user);
  const profile = db.learnerProfiles[user.id] || null;

  res.json({
    token,
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      avatar: user.avatar,
    },
    profile,
  });
});

app.get('/api/auth/me', authenticateToken, (req: AuthRequest, res: Response) => {
  const db = getDatabase();
  const user = req.user!;
  const profile = db.learnerProfiles[user.id] || null;
  res.json({
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      avatar: user.avatar,
    },
    profile,
  });
});

// -------------------------------------------------------------
// Profile & Student Onboarding Endpoints
// -------------------------------------------------------------
app.get('/api/profile', authenticateToken, (req: AuthRequest, res: Response) => {
  const db = getDatabase();
  const profile = db.learnerProfiles[req.user!.id];
  if (!profile) {
    res.status(404).json({ error: 'Profile not found' });
    return;
  }
  res.json(profile);
});

app.put('/api/profile', authenticateToken, (req: AuthRequest, res: Response) => {
  const db = getDatabase();
  const current = db.learnerProfiles[req.user!.id];
  if (!current) {
    res.status(404).json({ error: 'Profile not found' });
    return;
  }

  const updated: LearnerProfile = {
    ...current,
    ...req.body,
    preferences: {
      ...current.preferences,
      ...(req.body.preferences || {}),
    },
    lastActive: new Date().toISOString(),
  };

  db.learnerProfiles[req.user!.id] = updated;
  saveDatabase();
  res.json(updated);
});

app.get('/api/profile/diagnostic-quiz', (_req: Request, res: Response) => {
  const questions = [
    {
      id: 'diag_1',
      question: 'What is the main source of light and natural energy for Earth?',
      options: ['The Sun', 'The Moon', 'Wind turbines', 'Ocean waves'],
      correctIndex: 0,
    },
    {
      id: 'diag_2',
      question: 'What do green plants take in from the air to make their food?',
      options: ['Carbon Dioxide', 'Helium', 'Gold dust', 'Neon'],
      correctIndex: 0,
    },
    {
      id: 'diag_3',
      question: 'When water heats up on a lake and turns into invisible vapor, this is called:',
      options: ['Evaporation', 'Freezing', 'Melting', 'Sedimentation'],
      correctIndex: 0,
    },
    {
      id: 'diag_4',
      question: 'Which of the following is the largest planet in our solar system?',
      options: ['Jupiter', 'Mars', 'Mercury', 'Venus'],
      correctIndex: 0,
    },
    {
      id: 'diag_5',
      question: 'If you slice a pizza into 4 equal slices and eat 1 slice, what fraction did you eat?',
      options: ['1/4 (one quarter)', '1/2 (one half)', '4/1 (four wholes)', '3/4 (three quarters)'],
      correctIndex: 0,
    },
  ];
  res.json({ questions });
});

app.post('/api/profile/onboard', authenticateToken, (req: AuthRequest, res: Response) => {
  const {
    name,
    age,
    grade,
    preferredLanguage,
    subjectInterests,
    preferences,
    learningPace,
    quizScore = 3,
  } = req.body;

  const db = getDatabase();
  const userId = req.user!.id;

  // Calculate baseline mastery from diagnostic quiz
  const initialMastery = Math.min(Math.max(quizScore / 5, 0.25), 0.90);

  const profile: LearnerProfile = {
    userId,
    name: name || req.user!.name,
    age: Number(age) || 12,
    grade: grade || 'Grade 6',
    preferredLanguage: preferredLanguage || 'English',
    subjectInterests: subjectInterests || ['Science'],
    learningPace: learningPace || 'moderate',
    readingLevel: initialMastery > 0.6 ? 'intermediate' : 'simple',
    preferences: {
      primaryFormat: preferences?.primaryFormat || 'standard',
      largeText: Boolean(preferences?.largeText),
      standardText: Boolean(preferences?.standardText),
      dyslexiaFont: Boolean(preferences?.dyslexiaFont),
      highContrast: Boolean(preferences?.highContrast),
      simplifiedLanguage: Boolean(preferences?.simplifiedLanguage),
      audioLearning: Boolean(preferences?.audioLearning),
      visualLearning: Boolean(preferences?.visualLearning),
      captions: Boolean(preferences?.captions),
      increasedLineSpacing: Boolean(preferences?.increasedLineSpacing),
      reducedMotion: Boolean(preferences?.reducedMotion),
      speechRate: Number(preferences?.speechRate) || 1.0,
    },
    initialMastery: Number(initialMastery.toFixed(2)),
    currentMastery: Number(initialMastery.toFixed(2)),
    streakDays: 1,
    lessonsCompleted: 0,
    quizAccuracy: Number((initialMastery * 100).toFixed(0)),
    lastActive: new Date().toISOString(),
    currentLessonId: 'lesson_photosynthesis',
  };

  db.learnerProfiles[userId] = profile;

  // Initialize mastery records
  if (!db.masteryStates[userId]) {
    db.masteryStates[userId] = {};
  }
  db.masteryStates[userId]['photosynthesis'] = {
    studentId: userId,
    topic: 'photosynthesis',
    pMastery: initialMastery,
    attemptsCount: 0,
    correctCount: 0,
    lastUpdated: new Date().toISOString(),
    history: [{ date: new Date().toISOString(), pMastery: initialMastery, isCorrect: true }],
  };

  saveDatabase();
  res.json({ success: true, profile });
});

// -------------------------------------------------------------
// Lessons Endpoints
// -------------------------------------------------------------
app.get('/api/lessons', (_req: Request, res: Response) => {
  const db = getDatabase();
  const summaryList = db.lessons.map((l) => ({
    id: l.id,
    title: l.title,
    subject: l.subject,
    topic: l.topic,
    summary: l.summary,
    durationMinutes: l.durationMinutes,
    gradeLevel: l.gradeLevel,
    published: l.published,
    questionsCount: l.adaptation.quizQuestions.length,
    variantsAvailable: Object.keys(l.adaptation.variants),
  }));
  res.json(summaryList);
});

app.get('/api/lessons/:id', (req: Request, res: Response) => {
  const db = getDatabase();
  const lesson = db.lessons.find((l) => l.id === req.params.id);
  if (!lesson) {
    res.status(404).json({ error: 'Lesson not found' });
    return;
  }
  res.json(lesson);
});

app.post('/api/lessons', authenticateToken, async (req: AuthRequest, res: Response) => {
  if (req.user!.role !== 'teacher') {
    res.status(403).json({ error: 'Only teachers can upload lessons' });
    return;
  }

  const { title, subject, content, gradeLevel = 'Grade 6', durationMinutes = 15 } = req.body;
  if (!title || !content) {
    res.status(400).json({ error: 'Title and content are required' });
    return;
  }

  const db = getDatabase();
  const adaptation = await adaptLessonWithAI(title, subject || 'General Science', content);

  const newLesson: Lesson = {
    id: `lesson_${Date.now()}`,
    title,
    subject: subject || 'General Science',
    topic: title.toLowerCase().replace(/[^a-z0-9]/g, '_').slice(0, 20),
    summary: adaptation.summary,
    content,
    durationMinutes: Number(durationMinutes) || 15,
    gradeLevel,
    published: true,
    authorId: req.user!.id,
    adaptation,
    createdAt: new Date().toISOString(),
  };

  db.lessons.push(newLesson);
  saveDatabase();

  res.json({ success: true, lesson: newLesson });
});

app.post('/api/lessons/:id/adapt', async (req: Request, res: Response) => {
  const db = getDatabase();
  const lesson = db.lessons.find((l) => l.id === req.params.id);
  if (!lesson) {
    res.status(404).json({ error: 'Lesson not found' });
    return;
  }

  const adaptation = await adaptLessonWithAI(lesson.title, lesson.subject, lesson.content);
  lesson.adaptation = adaptation;
  saveDatabase();

  res.json({ success: true, adaptation });
});

app.post('/api/lessons/:id/feedback', authenticateToken, (req: AuthRequest, res: Response) => {
  const { rating, formatUsed, comment } = req.body;
  const db = getDatabase();
  const feedback: LessonFeedback = {
    id: `fb_${Date.now()}`,
    studentId: req.user!.id,
    lessonId: req.params.id,
    rating,
    formatUsed: formatUsed || 'standard',
    comment,
    timestamp: new Date().toISOString(),
  };

  db.feedbackList.push(feedback);

  // Update bandit arm reward based on student rating
  const arm = db.banditArms.find((a) => a.format === formatUsed);
  if (arm) {
    arm.pulls += 1;
    const reward =
      rating === 'just_right' ? 1.0 : rating === 'too_easy' ? 0.7 : rating === 'too_difficult' ? 0.4 : 0.2;
    arm.totalReward += reward;
    arm.averageReward = Number((arm.totalReward / arm.pulls).toFixed(3));
  }

  saveDatabase();
  res.json({ success: true, feedback });
});

// -------------------------------------------------------------
// Quiz & BKT Adaptive Learning Engine Endpoints
// -------------------------------------------------------------
app.post('/api/quiz/answer', authenticateToken, (req: AuthRequest, res: Response) => {
  const { lessonId, questionId, selectedOption, topic = 'photosynthesis' } = req.body;
  const db = getDatabase();
  const studentId = req.user!.id;

  const lesson = db.lessons.find((l) => l.id === lessonId);
  if (!lesson) {
    res.status(404).json({ error: 'Lesson not found' });
    return;
  }

  const question = lesson.adaptation.quizQuestions.find((q) => q.id === questionId);
  if (!question) {
    res.status(404).json({ error: 'Question not found' });
    return;
  }

  const isCorrect = question.correctAnswerIndex === Number(selectedOption);

  // Retrieve current student mastery for this topic
  if (!db.masteryStates[studentId]) {
    db.masteryStates[studentId] = {};
  }

  const studentTopicMastery =
    db.masteryStates[studentId][topic] || {
      studentId,
      topic,
      pMastery: 0.35,
      attemptsCount: 0,
      correctCount: 0,
      lastUpdated: new Date().toISOString(),
      history: [],
    };

  const pMasteryBefore = studentTopicMastery.pMastery;

  // Run Bayesian Knowledge Tracing update
  const bktParams = DEFAULT_BKT_PARAMS[topic] || DEFAULT_BKT_PARAMS.photosynthesis;
  const bktResult = updateMasteryBKT(pMasteryBefore, isCorrect, bktParams);

  // Update topic record
  studentTopicMastery.pMastery = bktResult.updatedMastery;
  studentTopicMastery.attemptsCount += 1;
  if (isCorrect) studentTopicMastery.correctCount += 1;
  studentTopicMastery.lastUpdated = new Date().toISOString();
  studentTopicMastery.history.push({
    date: new Date().toISOString(),
    pMastery: bktResult.updatedMastery,
    isCorrect,
    questionId,
  });

  db.masteryStates[studentId][topic] = studentTopicMastery;

  // Update learner profile aggregate accuracy & current mastery
  const profile = db.learnerProfiles[studentId];
  if (profile) {
    // Recalculate average across all topics
    const topics = Object.values(db.masteryStates[studentId]);
    const avgMastery = topics.reduce((acc, t) => acc + t.pMastery, 0) / (topics.length || 1);
    profile.currentMastery = Number(avgMastery.toFixed(3));

    // Update attempts accuracy
    const totalAttempts = topics.reduce((acc, t) => acc + t.attemptsCount, 0);
    const totalCorrect = topics.reduce((acc, t) => acc + t.correctCount, 0);
    profile.quizAccuracy = totalAttempts > 0 ? Number(((totalCorrect / totalAttempts) * 100).toFixed(1)) : 80;
    profile.lastActive = new Date().toISOString();
  }

  // Record attempt log
  const attemptLog: AttemptLog = {
    id: `att_${Date.now()}`,
    studentId,
    lessonId,
    questionId,
    questionText: question.question,
    selectedOption: Number(selectedOption),
    isCorrect,
    timestamp: new Date().toISOString(),
    pMasteryBefore,
    pMasteryAfter: bktResult.updatedMastery,
  };
  db.attempts.push(attemptLog);

  // Re-run recommendation engine for next step
  const nextRec = recommendFormat(
    db.banditArms,
    profile ? {
      primaryFormat: profile.preferences.primaryFormat,
      learningPace: profile.learningPace,
      readingLevel: profile.readingLevel,
      audioPreferred: profile.preferences.audioLearning,
      visualPreferred: profile.preferences.visualLearning,
      largeTextPreferred: profile.preferences.largeText,
    } : {},
    bktResult.updatedMastery
  );

  saveDatabase();

  res.json({
    isCorrect,
    correctAnswerIndex: question.correctAnswerIndex,
    explanation: question.explanation,
    hint: question.hint,
    bkt: {
      pMasteryBefore,
      pMasteryAfter: bktResult.updatedMastery,
      expectedAccuracy: bktResult.expectedAccuracy,
      delta: Number((bktResult.updatedMastery - pMasteryBefore).toFixed(4)),
    },
    recommendation: nextRec,
  });
});

app.get('/api/next-step', authenticateToken, (req: AuthRequest, res: Response) => {
  const db = getDatabase();
  const studentId = req.user!.id;
  const profile = db.learnerProfiles[studentId];
  const currentMastery = profile?.currentMastery || 0.45;

  const rec = recommendFormat(
    db.banditArms,
    profile ? {
      primaryFormat: profile.preferences.primaryFormat,
      learningPace: profile.learningPace,
      readingLevel: profile.readingLevel,
      audioPreferred: profile.preferences.audioLearning,
      visualPreferred: profile.preferences.visualLearning,
      largeTextPreferred: profile.preferences.largeText,
    } : {},
    currentMastery
  );

  res.json({
    recommendation: rec,
    profile: profile || null,
    banditArms: db.banditArms,
  });
});

app.get('/api/analytics/progress', authenticateToken, (req: AuthRequest, res: Response) => {
  const db = getDatabase();
  const studentId = req.user!.id;
  const profile = db.learnerProfiles[studentId];
  const studentMastery = db.masteryStates[studentId] || {};
  const studentAttempts = db.attempts.filter((a) => a.studentId === studentId);

  res.json({
    profile,
    topics: studentMastery,
    recentAttempts: studentAttempts.slice(-10),
  });
});

// -------------------------------------------------------------
// Teacher Dashboard Endpoints
// -------------------------------------------------------------
app.get('/api/teacher/overview', authenticateToken, (req: AuthRequest, res: Response) => {
  if (req.user!.role !== 'teacher') {
    res.status(403).json({ error: 'Teacher privileges required' });
    return;
  }

  const db = getDatabase();
  const profiles = Object.values(db.learnerProfiles);
  const totalStudents = profiles.length;
  const activeStudents = profiles.filter(
    (p) => Date.now() - new Date(p.lastActive).getTime() < 3 * 86400000
  ).length;

  const avgMastery =
    profiles.reduce((acc, p) => acc + p.currentMastery, 0) / (totalStudents || 1);
  const totalCompleted = profiles.reduce((acc, p) => acc + p.lessonsCompleted, 0);
  const studentsNeedingSupport = profiles.filter((p) => p.currentMastery < 0.5);

  // Format preference counts
  const formatCounts: Record<string, number> = {
    large_text: 0,
    simplified: 0,
    audio: 0,
    visual: 0,
    standard: 0,
  };
  profiles.forEach((p) => {
    if (p.preferences.largeText) formatCounts.large_text++;
    if (p.preferences.simplifiedLanguage) formatCounts.simplified++;
    if (p.preferences.audioLearning) formatCounts.audio++;
    if (p.preferences.visualLearning) formatCounts.visual++;
    if (p.preferences.standardText) formatCounts.standard++;
  });

  res.json({
    stats: {
      totalStudents: totalStudents + 16, // aggregate demo class size
      activeStudents: activeStudents + 14,
      avgClassMastery: Number(avgMastery.toFixed(2)),
      lessonsCompleted: totalCompleted + 42,
      needingSupportCount: studentsNeedingSupport.length,
    },
    studentsNeedingSupport: studentsNeedingSupport.map((s) => ({
      id: s.userId,
      name: s.name,
      currentMastery: s.currentMastery,
      pace: s.learningPace,
      preferredFormat: s.preferences.primaryFormat,
    })),
    formatDistribution: formatCounts,
    recentAlerts: db.alerts.slice(-5),
  });
});

app.get('/api/teacher/students', authenticateToken, (req: AuthRequest, res: Response) => {
  if (req.user!.role !== 'teacher') {
    res.status(403).json({ error: 'Teacher privileges required' });
    return;
  }

  const db = getDatabase();
  const students = Object.values(db.learnerProfiles).map((profile) => {
    const user = db.users.find((u) => u.id === profile.userId);
    return {
      id: profile.userId,
      name: profile.name,
      email: user?.email || '',
      avatar: user?.avatar || '',
      grade: profile.grade,
      progress: Math.round(profile.currentMastery * 100),
      mastery: profile.currentMastery,
      accuracy: profile.quizAccuracy,
      pace: profile.learningPace,
      preferredFormat: profile.preferences.primaryFormat,
      preferences: profile.preferences,
      status: profile.currentMastery >= 0.7 ? 'Excelling' : profile.currentMastery >= 0.5 ? 'On Track' : 'Needs Support',
      lastActive: profile.lastActive,
      lessonsCompleted: profile.lessonsCompleted,
    };
  });

  res.json({ students });
});

app.get('/api/teacher/student/:id', authenticateToken, (req: AuthRequest, res: Response) => {
  if (req.user!.role !== 'teacher') {
    res.status(403).json({ error: 'Teacher privileges required' });
    return;
  }

  const db = getDatabase();
  const studentId = req.params.id;
  const profile = db.learnerProfiles[studentId];
  if (!profile) {
    res.status(404).json({ error: 'Student not found' });
    return;
  }

  const user = db.users.find((u) => u.id === studentId);
  const mastery = db.masteryStates[studentId] || {};
  const attempts = db.attempts.filter((a) => a.studentId === studentId);
  const studentAlerts = db.alerts.filter((a) => a.studentId === studentId);
  const studentFeedback = db.feedbackList.filter((f) => f.studentId === studentId);

  res.json({
    student: {
      id: studentId,
      name: profile.name,
      email: user?.email,
      avatar: user?.avatar,
      grade: profile.grade,
      profile,
    },
    mastery,
    attempts: attempts.slice(-15),
    alerts: studentAlerts,
    feedback: studentFeedback,
    aiRecommendation:
      profile.preferences.audioLearning || profile.preferences.largeText
        ? `${profile.name} exhibits +24% higher quiz retention when lessons include auditory read-aloud and large-font summaries. Recommendation: Keep audio scaffolding enabled.`
        : `${profile.name} responds exceptionally well to interactive visual diagrams and simplified concept chunks.`,
  });
});

app.get('/api/teacher/alerts', authenticateToken, (req: AuthRequest, res: Response) => {
  if (req.user!.role !== 'teacher') {
    res.status(403).json({ error: 'Teacher privileges required' });
    return;
  }
  const db = getDatabase();
  res.json({ alerts: db.alerts });
});

app.put('/api/teacher/alerts/:id/read', authenticateToken, (req: AuthRequest, res: Response) => {
  const db = getDatabase();
  const alert = db.alerts.find((a) => a.id === req.params.id);
  if (alert) {
    alert.read = true;
    saveDatabase();
  }
  res.json({ success: true });
});

// -------------------------------------------------------------
// Guardian / Parent Dashboard Endpoint
// -------------------------------------------------------------
app.get('/api/guardian/overview', authenticateToken, (req: AuthRequest, res: Response) => {
  if (req.user!.role !== 'guardian') {
    res.status(403).json({ error: 'Guardian access required' });
    return;
  }

  const db = getDatabase();
  const relationship = db.guardianRelationships.find((r) => r.guardianId === req.user!.id);
  const targetStudentId = relationship ? relationship.studentId : 'user_student_a';
  const profile = db.learnerProfiles[targetStudentId];
  const user = db.users.find((u) => u.id === targetStudentId);
  const mastery = db.masteryStates[targetStudentId] || {};
  const feedback = db.feedbackList.filter((f) => f.studentId === targetStudentId);

  res.json({
    student: {
      id: targetStudentId,
      name: profile?.name || 'Aarav Sharma',
      avatar: user?.avatar,
      grade: profile?.grade || 'Grade 6',
      progressPercent: Math.round((profile?.currentMastery || 0.48) * 100),
      lessonsCompleted: profile?.lessonsCompleted || 3,
      streakDays: profile?.streakDays || 4,
      accuracy: profile?.quizAccuracy || 72,
    },
    topicStrengths: [
      { topic: 'Photosynthesis', status: 'In Progress (48%)', note: 'Showing steady improvement with audio pacing' },
      { topic: 'Water Cycle', status: 'Mastered (55%)', note: 'Completed quiz with 4/5 on first attempt' },
    ],
    growthAreas: [
      { area: 'Stomata Leaf Biology', tip: 'Reviewing leaf diagram with large-font step breakdown' },
    ],
    teacherNotes: [
      {
        teacher: 'Ms. Elena Sharma',
        date: 'Yesterday',
        message: 'Aarav is doing great this week! The audio lessons have noticeably boosted his confidence during group quizzes.',
      },
    ],
    recentFeedback: feedback,
  });
});

// -------------------------------------------------------------
// Live Compare Demo Endpoint (/demo - Hackathon Feature)
// -------------------------------------------------------------
app.get('/api/demo/data', (_req: Request, res: Response) => {
  const db = getDatabase();
  const aarav = db.learnerProfiles['user_student_a'];
  const meera = db.learnerProfiles['user_student_b'];
  const lesson = db.lessons.find((l) => l.id === 'lesson_photosynthesis') || db.lessons[0];

  res.json({
    learnerA: {
      profile: aarav,
      formatName: 'Large Text + Audio + Step-by-Step',
      mastery: 0.35,
      readingLevel: 'Simple English',
      pace: 'Slow / Guided',
      adaptedVariant: {
        largeText: lesson.adaptation.variants.largeText,
        audioScript: lesson.adaptation.variants.audioScript,
        stepByStep: lesson.adaptation.variants.stepByStep,
      },
      bktParameters: {
        pL0: 0.35,
        pT: 0.15,
        pG: 0.20,
        pS: 0.10,
      },
    },
    learnerB: {
      profile: meera,
      formatName: 'Simplified English + Visual Diagram',
      mastery: 0.60,
      readingLevel: 'Intermediate',
      pace: 'Moderate',
      adaptedVariant: {
        simplified: lesson.adaptation.variants.simplified,
        visual: lesson.adaptation.variants.visual,
      },
      bktParameters: {
        pL0: 0.60,
        pT: 0.18,
        pG: 0.15,
        pS: 0.08,
      },
    },
    originalLesson: {
      title: lesson.title,
      subject: lesson.subject,
      content: lesson.content,
    },
    pipelineStages: [
      { stage: 1, name: 'Original Lesson', desc: 'Raw curriculum text input by educator' },
      { stage: 2, name: 'Learner Profile & Accessibility Needs', desc: 'Sensory preferences, font, contrast, pacing' },
      { stage: 3, name: 'Knowledge Model (BKT)', desc: 'Prior probability P(L0) & real-time mastery tracking' },
      { stage: 4, name: 'AI Adaptation Engine', desc: 'Gemini 3.8 / Multi-variant pedagogical transformation' },
      { stage: 5, name: 'Personalized Delivery', desc: 'Tailored sensory format matching learner profile' },
      { stage: 6, name: 'Progress & Bandit Feedback', desc: 'Closed-loop mastery update & bandit reward update' },
    ],
  });
});

app.post('/api/demo/run-adaptation', async (req: Request, res: Response) => {
  const { title, subject, text } = req.body;
  const inputTitle = title || 'Custom Educational Lesson';
  const inputSubject = subject || 'Science';
  const inputText =
    text ||
    'Photosynthesis is the process through which green plants convert sunlight, carbon dioxide and water into glucose and oxygen.';

  // Run adaptation
  const adaptation = await adaptLessonWithAI(inputTitle, inputSubject, inputText);

  // Return formatted comparison payload for both learners
  res.json({
    originalText: inputText,
    title: inputTitle,
    subject: inputSubject,
    aiGenerated: adaptation.aiGenerated,
    learnerAView: {
      name: 'Aarav (Learner A)',
      needs: 'Large font, audio narration, short chunks, slow guided pace',
      largeText: adaptation.variants.largeText,
      audioScript: adaptation.variants.audioScript,
      stepByStep: adaptation.variants.stepByStep,
      simulatedMasteryBefore: 0.35,
      simulatedMasteryAfter: 0.49,
    },
    learnerBView: {
      name: 'Meera (Learner B)',
      needs: 'Simplified concepts, visual diagrams, moderate pace, vocabulary definitions',
      simplified: adaptation.variants.simplified,
      visual: adaptation.variants.visual,
      simulatedMasteryBefore: 0.60,
      simulatedMasteryAfter: 0.74,
    },
    summary: adaptation.summary,
    keyTakeaways: adaptation.keyTakeaways,
    quizQuestions: adaptation.quizQuestions,
  });
});

// AI Simplification / "Ask AI" helper endpoint
app.post('/api/ai/explain', async (req: Request, res: Response) => {
  const { concept, context } = req.body;
  if (!concept) {
    res.status(400).json({ error: 'Concept is required' });
    return;
  }

  // Quick explanation helper
  res.json({
    concept,
    simpleExplanation: `Here is a friendly way to think about "${concept}": Imagine it like a helper in nature that takes one thing and transforms it into another, just like turning ingredients into a delicious snack. In this lesson, it helps keep balance so everything works smoothly!`,
    metaphor: `Like a recipe that uses sunshine as heat to bake sweet energy!`,
  });
});

// -------------------------------------------------------------
// Mount Vite / Static Frontend
// -------------------------------------------------------------
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 AdaptEd Full-Stack Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Fatal error starting AdaptEd server:', err);
  process.exit(1);
});
