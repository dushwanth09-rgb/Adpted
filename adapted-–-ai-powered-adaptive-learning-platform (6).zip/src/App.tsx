import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { AccessibilityProvider } from './context/AccessibilityContext.tsx';
import { Navbar } from './components/Navbar.tsx';
import { Sidebar } from './components/Sidebar.tsx';
import { AccessibilityToolbar } from './components/AccessibilityToolbar.tsx';
import { LandingPage } from './pages/LandingPage.tsx';
import { AuthPage } from './pages/AuthPage.tsx';
import { OnboardingPage } from './pages/OnboardingPage.tsx';
import { StudentDashboard } from './pages/StudentDashboard.tsx';
import { LessonPlayer } from './pages/LessonPlayer.tsx';
import { PracticeQuiz } from './pages/PracticeQuiz.tsx';
import { TeacherDashboard } from './pages/TeacherDashboard.tsx';
import { GuardianDashboard } from './pages/GuardianDashboard.tsx';
import { CompareDemoPage } from './pages/CompareDemoPage.tsx';
import { LessonsListPage } from './pages/LessonsListPage.tsx';
import { HowItWorksPage } from './pages/HowItWorksPage.tsx';

function MainApp() {
  const { user } = useAuth();
  const [currentView, setCurrentView] = useState<string>(() => {
    // Check initial pathname or default to landing
    if (window.location.pathname === '/demo') return 'demo';
    return 'landing';
  });
  const [navPayload, setNavPayload] = useState<any>(null);
  const [accessibilityDrawerOpen, setAccessibilityDrawerOpen] = useState<boolean>(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState<boolean>(false);

  const handleNavigate = (view: string, payload?: any) => {
    setCurrentView(view);
    setNavPayload(payload || null);
    window.scrollTo({ top: 0, behavior: 'smooth' });

    // Update browser URL state without page reload
    if (view === 'demo') {
      window.history.pushState({}, '', '/demo');
    } else if (view === 'landing') {
      window.history.pushState({}, '', '/');
    }
  };

  return (
    <div className="min-h-screen flex bg-[#F7F9FC] dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors">
      {/* 1. Left Sidebar Navigation Menu */}
      <Sidebar
        currentView={currentView}
        onNavigate={handleNavigate}
        isAccessibilityOpen={accessibilityDrawerOpen}
        onOpenAccessibility={() => setAccessibilityDrawerOpen(true)}
        isMobileOpen={mobileSidebarOpen}
        onCloseMobile={() => setMobileSidebarOpen(false)}
      />

      {/* 2. Main Page Stage */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen">
        {/* Top Bar Navigation */}
        <Navbar
          currentView={currentView}
          onNavigate={handleNavigate}
          onOpenMobileSidebar={() => setMobileSidebarOpen(true)}
        />

      {/* Main Content Stage */}
      <main className="flex-1">
        {currentView === 'landing' && <LandingPage onNavigate={handleNavigate} />}

        {currentView === 'demo' && <CompareDemoPage />}

        {currentView === 'auth' && <AuthPage onNavigate={handleNavigate} />}

        {currentView === 'onboarding' && (
          <OnboardingPage onComplete={() => handleNavigate('student_dashboard')} />
        )}

        {currentView === 'student_dashboard' && (
          <StudentDashboard
            onNavigate={handleNavigate}
            onOpenAccessibility={() => setAccessibilityDrawerOpen(true)}
          />
        )}

        {currentView === 'lesson_player' && (
          <LessonPlayer
            lessonId={navPayload?.lessonId || 'lesson_photosynthesis'}
            onNavigate={handleNavigate}
            onOpenAccessibility={() => setAccessibilityDrawerOpen(true)}
          />
        )}

        {currentView === 'practice' && <PracticeQuiz onNavigate={handleNavigate} />}

        {currentView === 'teacher_dashboard' && (
          <TeacherDashboard onNavigate={handleNavigate} />
        )}

        {currentView === 'guardian_dashboard' && (
          <GuardianDashboard onNavigate={handleNavigate} />
        )}

        {currentView === 'lessons' && <LessonsListPage onNavigate={handleNavigate} />}

        {currentView === 'how_it_works' && <HowItWorksPage onNavigate={handleNavigate} />}
      </main>
      </div>

      {/* Global Accessibility Toolbar Overlay */}
      <AccessibilityToolbar
        isOpen={accessibilityDrawerOpen}
        onClose={() => setAccessibilityDrawerOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AccessibilityProvider>
        <MainApp />
      </AccessibilityProvider>
    </AuthProvider>
  );
}
