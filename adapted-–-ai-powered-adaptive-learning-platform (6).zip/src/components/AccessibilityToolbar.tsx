import React from 'react';
import { useAccessibility } from '../context/AccessibilityContext.tsx';
import {
  X,
  Type,
  Sun,
  Moon,
  AlignJustify,
  ZapOff,
  Volume2,
  RotateCcw,
  Eye,
  Sliders,
  Check,
  BookOpen,
  Keyboard,
  Radio,
  Sparkles,
  Headphones,
} from 'lucide-react';

interface AccessibilityToolbarProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AccessibilityToolbar: React.FC<AccessibilityToolbarProps> = ({
  isOpen,
  onClose,
}) => {
  const {
    textSize,
    setTextSize,
    largeTextMode,
    toggleLargeTextMode,
    dyslexiaFont,
    toggleDyslexiaFont,
    highContrast,
    toggleHighContrast,
    darkMode,
    toggleDarkMode,
    spacedReading,
    toggleSpacedReading,
    reducedMotion,
    toggleReducedMotion,
    simplifiedEnglish,
    toggleSimplifiedEnglish,
    audioLearning,
    toggleAudioLearning,
    textToSpeechEnabled,
    toggleTextToSpeech,
    keyboardNavigation,
    toggleKeyboardNavigation,
    screenReaderSupport,
    toggleScreenReaderSupport,
    speechRate,
    setSpeechRate,
    speakText,
    stopSpeech,
    isSpeaking,
    resetToDefaults,
  } = useAccessibility();

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 z-40 bg-black/40 backdrop-blur-xs transition-opacity animate-in fade-in duration-150"
        aria-hidden="true"
      />

      {/* Accessible Settings Slide-Over Drawer */}
      <div
        role="dialog"
        aria-labelledby="accessibility-settings-title"
        aria-modal="true"
        className="fixed inset-y-0 right-0 z-50 w-full sm:w-[420px] bg-white dark:bg-slate-900 shadow-2xl border-l border-slate-200 dark:border-slate-800 p-6 overflow-y-auto animate-in slide-in-from-right duration-200"
      >
        {/* Drawer Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#1F4E79] dark:bg-blue-600 text-white flex items-center justify-center shadow-xs">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <h2
                id="accessibility-settings-title"
                className="text-base font-bold text-slate-900 dark:text-white"
              >
                Accessibility Settings
              </h2>
              <span className="text-[11px] text-slate-500 dark:text-slate-400">
                WCAG 2.1 AA Adaptive Sensory Accommodations
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            aria-label="Close accessibility settings"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-5 space-y-5">
          {/* 1. Large Text Mode */}
          <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="block text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  <Type className="w-4 h-4 text-[#1F4E79] dark:text-blue-400" />
                  Large Text Mode
                </span>
                <span className="block text-xs text-slate-500 dark:text-slate-400">
                  Instant text magnification across the entire interface
                </span>
              </div>
              <button
                onClick={toggleLargeTextMode}
                role="switch"
                aria-checked={largeTextMode}
                className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                  largeTextMode ? 'bg-[#1F4E79]' : 'bg-slate-300 dark:bg-slate-700'
                }`}
              >
                <div
                  className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                    largeTextMode ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Granular Sizing */}
            <div className="grid grid-cols-4 gap-1 p-1 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700">
              {(['sm', 'md', 'lg', 'xl'] as const).map((size) => (
                <button
                  key={size}
                  onClick={() => setTextSize(size)}
                  className={`py-1 text-xs font-medium rounded-lg transition-all ${
                    textSize === size
                      ? 'bg-[#1F4E79] text-white font-bold shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {size === 'sm' && 'Small'}
                  {size === 'md' && '100%'}
                  {size === 'lg' && '125%'}
                  {size === 'xl' && '150%'}
                </button>
              ))}
            </div>
          </div>

          {/* 2. Simplified English */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
            <div>
              <span className="block text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <BookOpen className="w-4 h-4 text-[#1F4E79] dark:text-blue-400" />
                Simplified English
              </span>
              <span className="block text-xs text-slate-500 dark:text-slate-400">
                Transforms complex sentences into clear, plain language chunks
              </span>
            </div>
            <button
              onClick={toggleSimplifiedEnglish}
              role="switch"
              aria-checked={simplifiedEnglish}
              className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                simplifiedEnglish ? 'bg-[#1F4E79]' : 'bg-slate-300 dark:bg-slate-700'
              }`}
            >
              <div
                className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                  simplifiedEnglish ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* 3. Audio-Based Learning */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
            <div>
              <span className="block text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <Headphones className="w-4 h-4 text-[#1F4E79] dark:text-blue-400" />
                Audio-Based Learning
              </span>
              <span className="block text-xs text-slate-500 dark:text-slate-400">
                Activates spoken narration, audio player bars, and sound guidance
              </span>
            </div>
            <button
              onClick={toggleAudioLearning}
              role="switch"
              aria-checked={audioLearning}
              className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                audioLearning ? 'bg-[#1F4E79]' : 'bg-slate-300 dark:bg-slate-700'
              }`}
            >
              <div
                className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                  audioLearning ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* 4. Text-to-Speech (TTS) */}
          <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="block text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  <Volume2 className="w-4 h-4 text-[#1F4E79] dark:text-blue-400" />
                  Text-to-Speech (TTS)
                </span>
                <span className="block text-xs text-slate-500 dark:text-slate-400">
                  Read aloud any highlighted lesson text, quiz, or question
                </span>
              </div>
              <button
                onClick={toggleTextToSpeech}
                role="switch"
                aria-checked={textToSpeechEnabled}
                className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                  textToSpeechEnabled ? 'bg-[#1F4E79]' : 'bg-slate-300 dark:bg-slate-700'
                }`}
              >
                <div
                  className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                    textToSpeechEnabled ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {textToSpeechEnabled && (
              <div className="pt-2 border-t border-slate-200 dark:border-slate-700/60 space-y-2">
                <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-400 font-medium">
                  <span>Playback Speed:</span>
                  <div className="flex gap-1">
                    {[0.75, 1.0, 1.25, 1.5].map((rate) => (
                      <button
                        key={rate}
                        onClick={() => setSpeechRate(rate)}
                        className={`px-2 py-0.5 rounded-md text-[11px] font-bold ${
                          speechRate === rate
                            ? 'bg-[#1F4E79] text-white'
                            : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                        }`}
                      >
                        {rate}x
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() =>
                    isSpeaking
                      ? stopSpeech()
                      : speakText(
                          'AdaptEd is an intelligent adaptive learning platform tailored to individual sensory needs, reading level, and mastery.'
                        )
                  }
                  className={`w-full py-2 px-3 text-xs font-bold rounded-xl transition-colors flex items-center justify-center gap-1.5 shadow-2xs ${
                    isSpeaking
                      ? 'bg-rose-600 text-white hover:bg-rose-700'
                      : 'bg-white dark:bg-slate-900 text-[#1F4E79] dark:text-blue-400 border border-slate-300 dark:border-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>{isSpeaking ? 'Stop Active Speech' : 'Test Speech Reading'}</span>
                </button>
              </div>
            )}
          </div>

          {/* 5. High Contrast Mode */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
            <div>
              <span className="block text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <Eye className="w-4 h-4 text-[#1F4E79] dark:text-blue-400" />
                High Contrast Mode
              </span>
              <span className="block text-xs text-slate-500 dark:text-slate-400">
                Enhance contrast ratio (7:1) for low vision &amp; sunlight readability
              </span>
            </div>
            <button
              onClick={toggleHighContrast}
              role="switch"
              aria-checked={highContrast}
              className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                highContrast ? 'bg-[#1F4E79]' : 'bg-slate-300 dark:bg-slate-700'
              }`}
            >
              <div
                className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                  highContrast ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* 6. Keyboard Navigation */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
            <div>
              <span className="block text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <Keyboard className="w-4 h-4 text-[#1F4E79] dark:text-blue-400" />
                Keyboard Navigation
              </span>
              <span className="block text-xs text-slate-500 dark:text-slate-400">
                Bold high-visibility focus indicators for motor accessibility
              </span>
            </div>
            <button
              onClick={toggleKeyboardNavigation}
              role="switch"
              aria-checked={keyboardNavigation}
              className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                keyboardNavigation ? 'bg-[#1F4E79]' : 'bg-slate-300 dark:bg-slate-700'
              }`}
            >
              <div
                className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                  keyboardNavigation ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* 7. Screen Reader Support */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
            <div>
              <span className="block text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <Radio className="w-4 h-4 text-[#1F4E79] dark:text-blue-400" />
                Screen Reader Support
              </span>
              <span className="block text-xs text-slate-500 dark:text-slate-400">
                ARIA announcements and semantic landmarks for NVDA &amp; VoiceOver
              </span>
            </div>
            <button
              onClick={toggleScreenReaderSupport}
              role="switch"
              aria-checked={screenReaderSupport}
              className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                screenReaderSupport ? 'bg-[#1F4E79]' : 'bg-slate-300 dark:bg-slate-700'
              }`}
            >
              <div
                className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                  screenReaderSupport ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* 8. Reduce Animations */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
            <div>
              <span className="block text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <ZapOff className="w-4 h-4 text-[#1F4E79] dark:text-blue-400" />
                Reduce Animations
              </span>
              <span className="block text-xs text-slate-500 dark:text-slate-400">
                Disables motion, transitions, and pulsing for sensory comfort
              </span>
            </div>
            <button
              onClick={toggleReducedMotion}
              role="switch"
              aria-checked={reducedMotion}
              className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                reducedMotion ? 'bg-[#1F4E79]' : 'bg-slate-300 dark:bg-slate-700'
              }`}
            >
              <div
                className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                  reducedMotion ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Additional Features: Dyslexia Font, Dark Mode, Spaced Reading */}
          <div className="space-y-2.5 pt-2">
            <div className="flex items-center justify-between p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
              <span className="text-xs font-bold text-slate-900 dark:text-white">Dyslexia-Friendly Font (Lexend)</span>
              <button
                onClick={toggleDyslexiaFont}
                role="switch"
                aria-checked={dyslexiaFont}
                className={`w-9 h-5 flex items-center rounded-full p-0.5 transition-colors ${
                  dyslexiaFont ? 'bg-[#1F4E79]' : 'bg-slate-300 dark:bg-slate-700'
                }`}
              >
                <div
                  className={`bg-white w-4 h-4 rounded-full shadow-xs transform transition-transform ${
                    dyslexiaFont ? 'translate-x-4' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
              <span className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                {darkMode ? <Moon className="w-3.5 h-3.5 text-blue-400" /> : <Sun className="w-3.5 h-3.5 text-amber-500" />}
                Dark Theme
              </span>
              <button
                onClick={toggleDarkMode}
                role="switch"
                aria-checked={darkMode}
                className={`w-9 h-5 flex items-center rounded-full p-0.5 transition-colors ${
                  darkMode ? 'bg-[#1F4E79]' : 'bg-slate-300 dark:bg-slate-700'
                }`}
              >
                <div
                  className={`bg-white w-4 h-4 rounded-full shadow-xs transform transition-transform ${
                    darkMode ? 'translate-x-4' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
              <span className="text-xs font-bold text-slate-900 dark:text-white">Spaced Line Reading</span>
              <button
                onClick={toggleSpacedReading}
                role="switch"
                aria-checked={spacedReading}
                className={`w-9 h-5 flex items-center rounded-full p-0.5 transition-colors ${
                  spacedReading ? 'bg-[#1F4E79]' : 'bg-slate-300 dark:bg-slate-700'
                }`}
              >
                <div
                  className={`bg-white w-4 h-4 rounded-full shadow-xs transform transition-transform ${
                    spacedReading ? 'translate-x-4' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>

          {/* Reset to Defaults */}
          <div className="pt-3 border-t border-slate-200 dark:border-slate-800">
            <button
              onClick={resetToDefaults}
              className="w-full py-2.5 px-3 text-xs font-bold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors flex items-center justify-center gap-1.5 border border-slate-200 dark:border-slate-700"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset All Accessibility Preferences
            </button>
          </div>
        </div>
      </div>
    </>
  );
};
