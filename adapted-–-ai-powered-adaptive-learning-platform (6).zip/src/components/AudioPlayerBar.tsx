import React, { useState, useEffect } from 'react';
import { useAccessibility } from '../context/AccessibilityContext.tsx';
import { Play, Pause, Square, Volume2, FastForward, RotateCcw } from 'lucide-react';

interface AudioPlayerBarProps {
  title: string;
  textToSpeak: string;
  captions?: string;
}

export const AudioPlayerBar: React.FC<AudioPlayerBarProps> = ({
  title,
  textToSpeak,
  captions,
}) => {
  const { isSpeaking, isPaused, speakText, pauseSpeech, resumeSpeech, stopSpeech, speechRate, setSpeechRate } =
    useAccessibility();

  const [activeCaption, setActiveCaption] = useState<string>(captions || textToSpeak.slice(0, 140));

  useEffect(() => {
    if (captions) {
      setActiveCaption(captions);
    } else {
      setActiveCaption(textToSpeak.slice(0, 160) + (textToSpeak.length > 160 ? '...' : ''));
    }
  }, [captions, textToSpeak]);

  const handlePlayToggle = () => {
    if (isSpeaking && !isPaused) {
      pauseSpeech();
    } else if (isPaused) {
      resumeSpeech();
    } else {
      speakText(textToSpeak);
    }
  };

  return (
    <div className="bg-slate-900 text-white p-4 rounded-2xl shadow-lg border border-slate-800 transition-all">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        {/* Left: Lesson Audio Info & Live Captions */}
        <div className="flex items-start gap-3 min-w-0 flex-1">
          <div className="w-10 h-10 rounded-xl bg-blue-600/30 border border-blue-500/40 text-blue-300 flex items-center justify-center shrink-0">
            <Volume2 className="w-5 h-5" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <span className="text-xs uppercase tracking-wider font-semibold text-blue-400">
                Audio Lesson Narrator
              </span>
              <span className="text-slate-500 text-xs">·</span>
              <span className="text-xs text-slate-300 font-medium truncate">{title}</span>
            </div>
            {/* Live Captions Display */}
            <p className="mt-1 text-sm text-slate-200 line-clamp-2 bg-slate-800/80 px-2.5 py-1.5 rounded-lg border border-slate-700/60 font-medium">
              "{activeCaption}"
            </p>
          </div>
        </div>

        {/* Right: Audio Playback Controls */}
        <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
          {/* Rate Selector */}
          <div className="flex items-center gap-1 bg-slate-800 px-2 py-1 rounded-lg border border-slate-700 text-xs">
            <span className="text-slate-400 text-[11px]">Speed:</span>
            <select
              value={speechRate}
              onChange={(e) => setSpeechRate(parseFloat(e.target.value))}
              className="bg-transparent text-white font-semibold focus:outline-hidden cursor-pointer"
              aria-label="Speech speed"
            >
              <option value="0.75" className="bg-slate-900 text-white">0.75x</option>
              <option value="1.0" className="bg-slate-900 text-white">1.0x</option>
              <option value="1.25" className="bg-slate-900 text-white">1.25x</option>
              <option value="1.5" className="bg-slate-900 text-white">1.5x</option>
            </select>
          </div>

          {/* Play / Pause Button */}
          <button
            onClick={handlePlayToggle}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs rounded-xl shadow-md transition-colors"
            aria-label={isSpeaking && !isPaused ? 'Pause narration' : 'Play narration'}
          >
            {isSpeaking && !isPaused ? (
              <>
                <Pause className="w-4 h-4" />
                <span>Pause</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                <span>{isPaused ? 'Resume' : 'Listen'}</span>
              </>
            )}
          </button>

          {/* Stop Button */}
          {isSpeaking && (
            <button
              onClick={stopSpeech}
              className="p-2 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition-colors"
              title="Stop playback"
              aria-label="Stop playback"
            >
              <Square className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
