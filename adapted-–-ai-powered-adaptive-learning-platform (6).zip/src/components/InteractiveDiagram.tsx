import React, { useState } from 'react';
import { Sun, Droplets, Wind, Sparkles, CheckCircle2, RefreshCw } from 'lucide-react';

interface DiagramProps {
  title?: string;
  onElementSelect?: (elementName: string) => void;
}

export const InteractiveDiagram: React.FC<DiagramProps> = ({
  title = 'Interactive Photosynthesis Factory',
  onElementSelect,
}) => {
  const [activeStage, setActiveStage] = useState<'all' | 'sunlight' | 'water' | 'co2' | 'reaction' | 'products'>('all');
  const [reactionProgress, setReactionProgress] = useState<number>(100);

  const stages = [
    { id: 'all', label: 'Complete System' },
    { id: 'sunlight', label: '1. Sunlight (Energy)' },
    { id: 'water', label: '2. Water (Roots)' },
    { id: 'co2', label: '3. CO2 (Stomata)' },
    { id: 'reaction', label: '4. Chloroplast Reaction' },
    { id: 'products', label: '5. Glucose & Oxygen' },
  ];

  const handleSelect = (stageId: any) => {
    setActiveStage(stageId);
    if (onElementSelect) onElementSelect(stageId);
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm overflow-hidden">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800 gap-3">
        <div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            {title}
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Tap any element or step to inspect how plant cells convert inputs into energy.
          </p>
        </div>

        {/* Step Selector Tabs */}
        <div className="flex flex-wrap gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg text-xs">
          {stages.map((st) => (
            <button
              key={st.id}
              onClick={() => handleSelect(st.id)}
              className={`px-2.5 py-1 rounded-md font-medium transition-all ${
                activeStage === st.id
                  ? 'bg-white dark:bg-slate-700 text-emerald-700 dark:text-emerald-300 shadow-xs font-semibold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {st.label}
            </button>
          ))}
        </div>
      </div>

      {/* Interactive Visual Stage */}
      <div className="mt-6 relative bg-gradient-to-b from-sky-50 to-emerald-50/50 dark:from-slate-950 dark:to-emerald-950/20 rounded-xl p-6 border border-emerald-100 dark:border-emerald-950/50 min-h-[320px] flex flex-col justify-between">
        {/* Top: Sunlight & Atmosphere */}
        <div className="flex items-center justify-between">
          {/* Sunlight Input */}
          <div
            onClick={() => handleSelect('sunlight')}
            className={`cursor-pointer transition-all transform hover:scale-105 p-3 rounded-xl border ${
              activeStage === 'sunlight' || activeStage === 'all'
                ? 'bg-amber-50 dark:bg-amber-950/60 border-amber-300 dark:border-amber-700 shadow-md ring-2 ring-amber-400/40'
                : 'bg-white/80 dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 opacity-60'
            }`}
          >
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-amber-400/20 text-amber-600 dark:text-amber-300 flex items-center justify-center font-bold">
                <Sun className="w-5 h-5 animate-spin-slow" />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-900 dark:text-white block">
                  Solar Sunlight
                </span>
                <span className="text-[11px] text-amber-700 dark:text-amber-300">
                  Photons deliver energy
                </span>
              </div>
            </div>
          </div>

          {/* Atmospheric CO2 */}
          <div
            onClick={() => handleSelect('co2')}
            className={`cursor-pointer transition-all transform hover:scale-105 p-3 rounded-xl border ${
              activeStage === 'co2' || activeStage === 'all'
                ? 'bg-blue-50 dark:bg-blue-950/60 border-blue-300 dark:border-blue-700 shadow-md ring-2 ring-blue-400/40'
                : 'bg-white/80 dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 opacity-60'
            }`}
          >
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-blue-400/20 text-blue-600 dark:text-blue-300 flex items-center justify-center font-bold">
                <Wind className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-900 dark:text-white block">
                  Carbon Dioxide (CO₂)
                </span>
                <span className="text-[11px] text-blue-700 dark:text-blue-300">
                  Enters leaf stomata pores
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Center: Leaf Chloroplast Organelle */}
        <div
          onClick={() => handleSelect('reaction')}
          className={`my-4 mx-auto max-w-md w-full cursor-pointer transition-all p-4 rounded-2xl border ${
            activeStage === 'reaction' || activeStage === 'all'
              ? 'bg-emerald-100/80 dark:bg-emerald-950/70 border-emerald-400 dark:border-emerald-600 shadow-lg ring-2 ring-emerald-500/30'
              : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 opacity-70'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 dark:text-emerald-300">
              Reaction Chamber: Leaf Chloroplast
            </span>
            <span className="text-[11px] text-emerald-700 dark:text-emerald-400 font-mono font-bold">
              6CO₂ + 6H₂O + Light → C₆H₁₂O₆ + 6O₂
            </span>
          </div>

          <div className="mt-3 flex items-center justify-around gap-2 text-center">
            <div className="p-2 bg-white/90 dark:bg-slate-900/90 rounded-lg border border-emerald-200 dark:border-emerald-800 text-[11px]">
              <span className="text-slate-500 block">Pigment</span>
              <span className="font-bold text-emerald-700 dark:text-emerald-300">Chlorophyll</span>
            </div>
            <span className="text-emerald-600 font-bold">+</span>
            <div className="p-2 bg-white/90 dark:bg-slate-900/90 rounded-lg border border-emerald-200 dark:border-emerald-800 text-[11px]">
              <span className="text-slate-500 block">Splits</span>
              <span className="font-bold text-blue-600 dark:text-blue-300">Water (H₂O)</span>
            </div>
            <span className="text-emerald-600 font-bold">→</span>
            <div className="p-2 bg-white/90 dark:bg-slate-900/90 rounded-lg border border-emerald-200 dark:border-emerald-800 text-[11px]">
              <span className="text-slate-500 block">Forms</span>
              <span className="font-bold text-amber-600 dark:text-amber-300">Sugar Energy</span>
            </div>
          </div>
        </div>

        {/* Bottom: Roots Water + Output Products */}
        <div className="flex items-center justify-between">
          {/* Root Water */}
          <div
            onClick={() => handleSelect('water')}
            className={`cursor-pointer transition-all transform hover:scale-105 p-3 rounded-xl border ${
              activeStage === 'water' || activeStage === 'all'
                ? 'bg-cyan-50 dark:bg-cyan-950/60 border-cyan-300 dark:border-cyan-700 shadow-md ring-2 ring-cyan-400/40'
                : 'bg-white/80 dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 opacity-60'
            }`}
          >
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-cyan-400/20 text-cyan-600 dark:text-cyan-300 flex items-center justify-center font-bold">
                <Droplets className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-900 dark:text-white block">
                  Soil Water (H₂O)
                </span>
                <span className="text-[11px] text-cyan-700 dark:text-cyan-300">
                  Drawn up through roots
                </span>
              </div>
            </div>
          </div>

          {/* Life Sustaining Outputs */}
          <div
            onClick={() => handleSelect('products')}
            className={`cursor-pointer transition-all transform hover:scale-105 p-3 rounded-xl border ${
              activeStage === 'products' || activeStage === 'all'
                ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-300 dark:border-emerald-700 shadow-md ring-2 ring-emerald-400/40'
                : 'bg-white/80 dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 opacity-60'
            }`}
          >
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-emerald-400/20 text-emerald-600 dark:text-emerald-300 flex items-center justify-center font-bold">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-900 dark:text-white block">
                  Glucose (Food) + Oxygen (O₂)
                </span>
                <span className="text-[11px] text-emerald-700 dark:text-emerald-300">
                  Feeds plant & refreshes air
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Stage Explanatory Footnote */}
      <div className="mt-4 p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl text-xs text-slate-600 dark:text-slate-300 flex items-start gap-2.5">
        <Sparkles className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
        <div>
          {activeStage === 'sunlight' && (
            <span>
              <strong>Solar Sunlight:</strong> Chlorophyll pigments absorb electromagnetic wavelengths
              (primarily red and blue light, reflecting green). This energy powers the chemical bonding.
            </span>
          )}
          {activeStage === 'water' && (
            <span>
              <strong>Soil Water:</strong> Microscopic root hairs absorb moisture and essential soil minerals,
              drawing them upward via xylem tubes to the leaf cells.
            </span>
          )}
          {activeStage === 'co2' && (
            <span>
              <strong>Carbon Dioxide:</strong> Air enters through microscopic pores called stomata on the underside
              of leaves, controlled by specialized guard cells.
            </span>
          )}
          {activeStage === 'reaction' && (
            <span>
              <strong>Biochemical Transformation:</strong> Inside cellular chloroplasts, light reactions split water
              molecules and the Calvin cycle converts carbon dioxide into carbohydrate rings.
            </span>
          )}
          {activeStage === 'products' && (
            <span>
              <strong>Outputs for Earth:</strong> Glucose provides chemical energy for plant growth, while
              clean oxygen gas diffuses outward to support animal and human respiration!
            </span>
          )}
          {activeStage === 'all' && (
            <span>
              <strong>Complete Cycle:</strong> Three inputs (Sunlight, Water, CO₂) combine in chloroplasts to produce
              two essential outputs (Glucose sugar for food and pure Oxygen to breathe).
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
