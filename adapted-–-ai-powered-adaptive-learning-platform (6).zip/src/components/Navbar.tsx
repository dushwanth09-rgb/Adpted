import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { useAccessibility } from '../context/AccessibilityContext.tsx';
import {
  Sparkles,
  Sliders,
  LogOut,
  UserCheck,
  ChevronDown,
  Volume2,
  BookOpen,
  LayoutDashboard,
  GraduationCap,
  Menu,
} from 'lucide-react';

interface NavbarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  onOpenMobileSidebar?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  onOpenMobileSidebar,
}) => {
  const { user, profile, logout, switchDemoUser } = useAuth();
  const { isSpeaking, stopSpeech } = useAccessibility();
  const [showDemoDropdown, setShowDemoDropdown] = useState(false);

  return (
    <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Mobile Hamburger & Brand Logo */}
        <div className="flex items-center gap-3">
          {onOpenMobileSidebar && (
            <button
              onClick={onOpenMobileSidebar}
              className="lg:hidden p-2 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              aria-label="Open navigation menu"
            >
              <Menu className="w-5 h-5" />
            </button>
          )}

          <button
            onClick={() => onNavigate('landing')}
            className="flex items-center gap-2.5 text-left group focus-visible:ring-2 focus-visible:ring-[#1F4E79] rounded-lg p-1 transition-all"
            aria-label="AdaptEd Home"
          >
            <img
              src="/assets/aistudio/image_7f43828e.png"
              alt="AdaptEd - Learn • Adapt • Achieve"
              className="h-10 sm:h-11 w-auto object-contain rounded-lg bg-white p-0.5 shadow-2xs group-hover:opacity-95 transition-opacity"
            />
          </button>
        </div>

        {/* Zone 2: 4-5 Clean Nav Links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600 dark:text-slate-300">
          <button
            onClick={() => onNavigate('landing')}
            className={`whitespace-nowrap transition-colors hover:text-[#1F4E79] dark:hover:text-blue-400 ${
              currentView === 'landing' ? 'text-[#1F4E79] dark:text-blue-400 font-semibold' : ''
            }`}
          >
            Home
          </button>
          <button
            onClick={() => onNavigate('demo')}
            className={`whitespace-nowrap flex items-center gap-1.5 transition-colors hover:text-[#1F4E79] dark:hover:text-blue-400 ${
              currentView === 'demo' ? 'text-[#4F46E5] dark:text-indigo-400 font-semibold' : ''
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-[#4F46E5]" />
            Live Demo
          </button>
          <button
            onClick={() => onNavigate('lessons')}
            className={`whitespace-nowrap transition-colors hover:text-[#1F4E79] dark:hover:text-blue-400 ${
              currentView === 'lessons' || currentView === 'lesson_player'
                ? 'text-[#1F4E79] dark:text-blue-400 font-semibold'
                : ''
            }`}
          >
            Lessons
          </button>
          <button
            onClick={() => onNavigate('how_it_works')}
            className={`whitespace-nowrap transition-colors hover:text-[#1F4E79] dark:hover:text-blue-400 ${
              currentView === 'how_it_works' ? 'text-[#1F4E79] dark:text-blue-400 font-semibold' : ''
            }`}
          >
            How AI Adapts
          </button>
          {user && (
            <button
              onClick={() => {
                if (user.role === 'teacher') onNavigate('teacher_dashboard');
                else if (user.role === 'guardian') onNavigate('guardian_dashboard');
                else onNavigate('student_dashboard');
              }}
              className="whitespace-nowrap flex items-center gap-1.5 text-[#1F4E79] dark:text-blue-400 font-medium hover:underline"
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              My Dashboard
            </button>
          )}
        </nav>

        {/* Zone 3: Actions + Accessibility & Demo Accounts */}
        <div className="flex items-center gap-2.5 sm:gap-3 shrink-0">
          {/* Firebase Connection Status Indicator */}
          <div className="hidden lg:flex items-center gap-1.5 px-2 py-1 text-[11px] font-medium text-emerald-700 bg-emerald-50 dark:bg-emerald-950/50 dark:text-emerald-300 rounded-lg border border-emerald-200/80 dark:border-emerald-900">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            <span>Firebase Active</span>
          </div>

          {/* Active Speech Indicator */}
          {isSpeaking && (
            <button
              onClick={stopSpeech}
              title="Stop reading aloud"
              className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-amber-900 bg-amber-100 dark:bg-amber-950 dark:text-amber-200 rounded-md animate-pulse"
              aria-label="Reading aloud active. Click to stop."
            >
              <Volume2 className="w-3.5 h-3.5" />
              <span>Speaking</span>
            </button>
          )}

          {/* Quick Demo Accounts Switcher (For Judges & Hackathon evaluation) */}
          <div className="relative">
            <button
              onClick={() => setShowDemoDropdown((prev) => !prev)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
              aria-label="Switch Demo User"
              aria-expanded={showDemoDropdown}
            >
              <UserCheck className="w-3.5 h-3.5 text-[#1F4E79] dark:text-blue-400" />
              <span className="hidden sm:inline">
                {user ? user.name.split(' ')[0] : 'Demo Roles'}
              </span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {showDemoDropdown && (
              <div
                className="absolute right-0 mt-2 w-64 bg-white dark:bg-slate-800 rounded-xl shadow-xl border border-slate-200 dark:border-slate-700 py-2 z-50 animate-in fade-in zoom-in-95 duration-150"
                role="menu"
              >
                <div className="px-3 py-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                  Switch Demo Account
                </div>
                <button
                  onClick={() => {
                    switchDemoUser('student_a');
                    setShowDemoDropdown(false);
                    onNavigate('student_dashboard');
                  }}
                  className="w-full text-left px-3 py-2 text-xs hover:bg-slate-50 dark:hover:bg-slate-700 flex flex-col transition-colors"
                >
                  <span className="font-semibold text-slate-900 dark:text-white">
                    Learner A: Aarav Sharma
                  </span>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400">
                    Grade 6 · Large Text & Audio · Slow Pace
                  </span>
                </button>
                <button
                  onClick={() => {
                    switchDemoUser('student_b');
                    setShowDemoDropdown(false);
                    onNavigate('student_dashboard');
                  }}
                  className="w-full text-left px-3 py-2 text-xs hover:bg-slate-50 dark:hover:bg-slate-700 flex flex-col transition-colors"
                >
                  <span className="font-semibold text-slate-900 dark:text-white">
                    Learner B: Meera Rao
                  </span>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400">
                    Grade 6 · Simplified English & Visuals
                  </span>
                </button>
                <button
                  onClick={() => {
                    switchDemoUser('teacher');
                    setShowDemoDropdown(false);
                    onNavigate('teacher_dashboard');
                  }}
                  className="w-full text-left px-3 py-2 text-xs hover:bg-slate-50 dark:hover:bg-slate-700 flex flex-col transition-colors"
                >
                  <span className="font-semibold text-slate-900 dark:text-white">
                    Teacher: Ms. Elena Sharma
                  </span>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400">
                    Science Educator · Class Analytics & Alerts
                  </span>
                </button>
                <button
                  onClick={() => {
                    switchDemoUser('guardian');
                    setShowDemoDropdown(false);
                    onNavigate('guardian_dashboard');
                  }}
                  className="w-full text-left px-3 py-2 text-xs hover:bg-slate-50 dark:hover:bg-slate-700 flex flex-col transition-colors"
                >
                  <span className="font-semibold text-slate-900 dark:text-white">
                    Parent: Mr. Rajesh Patel
                  </span>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400">
                    Guardian Portal · Aarav's Progress
                  </span>
                </button>
                {user && (
                  <>
                    <div className="border-t border-slate-100 dark:border-slate-700 my-1" />
                    <button
                      onClick={() => {
                        logout();
                        setShowDemoDropdown(false);
                        onNavigate('landing');
                      }}
                      className="w-full text-left px-3 py-1.5 text-xs text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 flex items-center gap-1.5"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      Sign Out
                    </button>
                  </>
                )}
              </div>
            )}
          </div>

          {/* Primary Action Button */}
          {user ? (
            <button
              onClick={() => {
                if (user.role === 'teacher') onNavigate('teacher_dashboard');
                else if (user.role === 'guardian') onNavigate('guardian_dashboard');
                else onNavigate('student_dashboard');
              }}
              className="px-3.5 py-2 text-xs font-semibold text-white bg-[#1F4E79] hover:bg-[#163a5c] rounded-lg shadow-sm transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
            >
              <GraduationCap className="w-4 h-4" />
              <span>Dashboard</span>
            </button>
          ) : (
            <button
              onClick={() => onNavigate('auth')}
              className="px-4 py-2 text-xs font-semibold text-white bg-[#1F4E79] hover:bg-[#163a5c] rounded-lg shadow-sm transition-colors whitespace-nowrap shrink-0"
            >
              Get Started
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
