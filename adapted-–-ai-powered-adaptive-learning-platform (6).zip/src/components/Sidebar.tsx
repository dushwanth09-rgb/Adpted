import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { useAccessibility } from '../context/AccessibilityContext.tsx';
import {
  Home,
  Sparkles,
  BookOpen,
  Brain,
  LayoutDashboard,
  Sliders,
  ChevronLeft,
  ChevronRight,
  LogOut,
  User,
  GraduationCap,
  Shield,
  Users,
  Sun,
  Moon,
  Volume2,
} from 'lucide-react';

interface SidebarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  isAccessibilityOpen: boolean;
  onOpenAccessibility: () => void;
  isMobileOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onNavigate,
  isAccessibilityOpen,
  onOpenAccessibility,
  isMobileOpen,
  onCloseMobile,
}) => {
  const { user, logout } = useAuth();
  const { darkMode, toggleDarkMode, isSpeaking, stopSpeech } = useAccessibility();
  const [collapsed, setCollapsed] = useState<boolean>(() => {
    return localStorage.getItem('adapted_sidebar_collapsed') === 'true';
  });

  const handleToggleCollapse = () => {
    setCollapsed((prev) => {
      const next = !prev;
      localStorage.setItem('adapted_sidebar_collapsed', String(next));
      return next;
    });
  };

  const navItems = [
    { id: 'landing', label: 'Home', icon: Home },
    { id: 'demo', label: 'Live Demo', icon: Sparkles, badge: 'Flagship' },
    { id: 'lessons', label: 'Lessons', icon: BookOpen },
    { id: 'how_it_works', label: 'How AI Adapts', icon: Brain },
  ];

  const getDashboardId = () => {
    if (!user) return 'student_dashboard';
    if (user.role === 'teacher') return 'teacher_dashboard';
    if (user.role === 'guardian') return 'guardian_dashboard';
    return 'student_dashboard';
  };

  const getDashboardLabel = () => {
    if (!user) return 'Student Portal';
    if (user.role === 'teacher') return 'Teacher Portal';
    if (user.role === 'guardian') return 'Guardian Portal';
    return 'Student Dashboard';
  };

  const handleItemClick = (viewId: string) => {
    onNavigate(viewId);
    onCloseMobile();
  };

  const handleAccessibilityClick = () => {
    onOpenAccessibility();
    onCloseMobile();
  };

  const sidebarContent = (
    <div className="h-full flex flex-col justify-between bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 transition-all duration-300">
      {/* Top Brand Section */}
      <div>
        <div
          className={`flex items-center h-16 px-4 border-b border-slate-200 dark:border-slate-800 ${
            collapsed ? 'justify-center' : 'justify-between'
          }`}
        >
          <button
            onClick={() => handleItemClick('landing')}
            className="flex items-center gap-3 text-left overflow-hidden group focus-visible:ring-2 focus-visible:ring-[#1F4E79] rounded-xl p-1"
            title="AdaptEd Home"
          >
            <img
              src="/assets/aistudio/image_7f43828e.png"
              alt="AdaptEd Logo"
              className="h-10 w-auto object-contain bg-white rounded-lg p-0.5 shadow-2xs group-hover:scale-105 transition-transform shrink-0"
            />
            {!collapsed && (
              <div className="flex flex-col min-w-0">
                <span className="text-base font-extrabold text-[#1F4E79] dark:text-blue-400 tracking-tight leading-none truncate">
                  AdaptEd
                </span>
                <span className="text-[10px] text-slate-500 dark:text-slate-400 font-medium tracking-wide truncate mt-0.5">
                  Learn · Adapt · Achieve
                </span>
              </div>
            )}
          </button>

          {/* Desktop Collapse Toggle Button */}
          {!collapsed && (
            <button
              onClick={handleToggleCollapse}
              className="hidden lg:flex p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
              title="Collapse sidebar"
              aria-label="Collapse sidebar"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Navigation Items List */}
        <nav className="p-3 space-y-1.5" aria-label="Sidebar Navigation">
          {/* Main Views */}
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            return (
              <div key={item.id} className="relative group">
                <button
                  onClick={() => handleItemClick(item.id)}
                  className={`w-full flex items-center gap-3.5 px-3 py-2.5 rounded-xl font-medium text-xs transition-all duration-200 ${
                    isActive
                      ? 'bg-[#1F4E79] text-white shadow-sm font-bold'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-blue-50/70 dark:hover:bg-slate-800/80 hover:text-[#1F4E79] dark:hover:text-blue-300'
                  } ${collapsed ? 'justify-center px-2' : ''}`}
                  aria-current={isActive ? 'page' : undefined}
                >
                  <Icon
                    className={`w-4 h-4 shrink-0 transition-transform group-hover:scale-110 ${
                      isActive ? 'text-white' : 'text-[#1F4E79] dark:text-blue-400'
                    }`}
                  />
                  {!collapsed && (
                    <span className="truncate flex-1 text-left">{item.label}</span>
                  )}
                  {!collapsed && item.badge && !isActive && (
                    <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-bold border border-indigo-200 dark:border-indigo-800">
                      {item.badge}
                    </span>
                  )}
                </button>

                {/* Collapsed Tooltip */}
                {collapsed && (
                  <div className="absolute left-full ml-2 top-1/2 -translate-y-1/2 px-2.5 py-1 bg-slate-900 text-white text-xs font-semibold rounded-md opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity z-50 whitespace-nowrap shadow-lg">
                    {item.label}
                  </div>
                )}
              </div>
            );
          })}

          {/* User Dashboard Item */}
          <div className="relative group pt-1">
            <button
              onClick={() => handleItemClick(getDashboardId())}
              className={`w-full flex items-center gap-3.5 px-3 py-2.5 rounded-xl font-medium text-xs transition-all duration-200 ${
                currentView.includes('dashboard')
                  ? 'bg-[#1F4E79] text-white shadow-sm font-bold'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-blue-50/70 dark:hover:bg-slate-800/80 hover:text-[#1F4E79] dark:hover:text-blue-300'
              } ${collapsed ? 'justify-center px-2' : ''}`}
            >
              <LayoutDashboard
                className={`w-4 h-4 shrink-0 transition-transform group-hover:scale-110 ${
                  currentView.includes('dashboard')
                    ? 'text-white'
                    : 'text-[#1F4E79] dark:text-blue-400'
                }`}
              />
              {!collapsed && (
                <span className="truncate flex-1 text-left">
                  {getDashboardLabel()}
                </span>
              )}
            </button>
            {collapsed && (
              <div className="absolute left-full ml-2 top-1/2 -translate-y-1/2 px-2.5 py-1 bg-slate-900 text-white text-xs font-semibold rounded-md opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity z-50 whitespace-nowrap shadow-lg">
                {getDashboardLabel()}
              </div>
            )}
          </div>

          {/* Section Divider */}
          <div className="pt-4 pb-1">
            {!collapsed ? (
              <div className="px-3 text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                Accessibility &amp; Tools
              </div>
            ) : (
              <div className="h-px bg-slate-200 dark:bg-slate-800 mx-2" />
            )}
          </div>

          {/* REQUIREMENT: ACCESSIBILITY SETTINGS SIDEBAR MENU ITEM */}
          <div className="relative group">
            <button
              onClick={handleAccessibilityClick}
              className={`w-full flex items-center gap-3.5 px-3 py-2.5 rounded-xl font-medium text-xs transition-all duration-200 border ${
                isAccessibilityOpen
                  ? 'bg-[#1F4E79] text-white border-[#1F4E79] shadow-md font-bold'
                  : 'text-slate-800 dark:text-slate-200 border-blue-200/80 dark:border-blue-900/50 bg-blue-50/40 dark:bg-slate-800/40 hover:bg-blue-100/70 dark:hover:bg-slate-800 hover:border-[#1F4E79]'
              } ${collapsed ? 'justify-center px-2' : ''}`}
              title="Open Accessibility Settings (Text, Audio, Contrast, Speed)"
              aria-label="Accessibility Settings"
              aria-expanded={isAccessibilityOpen}
            >
              <div
                className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 transition-transform group-hover:scale-110 ${
                  isAccessibilityOpen
                    ? 'bg-white/20 text-white'
                    : 'bg-[#1F4E79] text-white dark:bg-blue-600'
                }`}
              >
                <Sliders className="w-4 h-4" />
              </div>

              {!collapsed && (
                <div className="flex-1 text-left min-w-0">
                  <span className="block font-bold truncate text-xs leading-tight">
                    Accessibility Settings
                  </span>
                  <span
                    className={`block text-[10px] truncate leading-tight ${
                      isAccessibilityOpen
                        ? 'text-blue-100'
                        : 'text-slate-500 dark:text-slate-400'
                    }`}
                  >
                    Large Text · Audio · Contrast
                  </span>
                </div>
              )}

              {!collapsed && (
                <span
                  className={`w-2 h-2 rounded-full ${
                    isAccessibilityOpen ? 'bg-amber-400 animate-ping' : 'bg-emerald-500'
                  }`}
                  title="Accessibility Active"
                />
              )}
            </button>

            {/* Collapsed Tooltip */}
            {collapsed && (
              <div className="absolute left-full ml-2 top-1/2 -translate-y-1/2 px-2.5 py-1.5 bg-slate-900 text-white text-xs font-semibold rounded-md opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity z-50 whitespace-nowrap shadow-xl border border-slate-700">
                <span className="block font-bold">Accessibility Settings</span>
                <span className="text-[10px] text-slate-400">
                  Large Text, Audio, High Contrast
                </span>
              </div>
            )}
          </div>

          {/* Active Speaking Indicator */}
          {isSpeaking && (
            <div
              className={`p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-xs text-amber-900 dark:text-amber-200 flex items-center gap-2 ${
                collapsed ? 'justify-center' : ''
              }`}
            >
              <Volume2 className="w-4 h-4 text-amber-600 shrink-0 animate-pulse" />
              {!collapsed && (
                <div className="flex-1 min-w-0">
                  <span className="block text-[11px] font-bold">Reading Aloud</span>
                  <button
                    onClick={stopSpeech}
                    className="text-[10px] text-amber-700 dark:text-amber-300 underline hover:text-amber-900"
                  >
                    Stop Speech
                  </button>
                </div>
              )}
            </div>
          )}
        </nav>
      </div>

      {/* Bottom Section: Theme & User & Expand */}
      <div className="p-3 border-t border-slate-200 dark:border-slate-800 space-y-2">
        {/* Dark Mode Quick Toggle */}
        <button
          onClick={toggleDarkMode}
          className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors ${
            collapsed ? 'justify-center px-2' : ''
          }`}
          title="Toggle Dark / Light Mode"
        >
          {darkMode ? (
            <Moon className="w-4 h-4 text-blue-400 shrink-0" />
          ) : (
            <Sun className="w-4 h-4 text-amber-500 shrink-0" />
          )}
          {!collapsed && <span>{darkMode ? 'Dark Theme' : 'Light Theme'}</span>}
        </button>

        {/* User Status / Account */}
        {user ? (
          <div
            className={`flex items-center gap-2.5 p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60 ${
              collapsed ? 'justify-center p-1.5' : ''
            }`}
          >
            <div className="w-8 h-8 rounded-lg bg-[#1F4E79] text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-2xs">
              {user.name.charAt(0)}
            </div>
            {!collapsed && (
              <div className="flex-1 min-w-0">
                <span className="block text-xs font-bold text-slate-900 dark:text-white truncate">
                  {user.name}
                </span>
                <span className="block text-[10px] text-slate-500 dark:text-slate-400 capitalize">
                  {user.role}
                </span>
              </div>
            )}
            {!collapsed && (
              <button
                onClick={() => {
                  logout();
                  handleItemClick('landing');
                }}
                className="p-1 text-slate-400 hover:text-rose-600 transition-colors"
                title="Sign out"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        ) : (
          <button
            onClick={() => handleItemClick('auth')}
            className={`w-full py-2 px-3 text-xs font-bold text-white bg-[#1F4E79] hover:bg-[#163a5c] rounded-xl transition-colors shadow-xs flex items-center justify-center gap-2 ${
              collapsed ? 'px-2' : ''
            }`}
          >
            <User className="w-4 h-4 shrink-0" />
            {!collapsed && <span>Sign In / Register</span>}
          </button>
        )}

        {/* Expand Sidebar Button when Collapsed */}
        {collapsed && (
          <button
            onClick={handleToggleCollapse}
            className="w-full hidden lg:flex items-center justify-center p-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
            title="Expand sidebar"
            aria-label="Expand sidebar"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );

  return (
    <>
      {/* 1. Desktop Static Sidebar */}
      <aside
        className={`hidden lg:block shrink-0 transition-all duration-300 z-30 sticky top-0 h-screen ${
          collapsed ? 'w-20' : 'w-64'
        }`}
      >
        {sidebarContent}
      </aside>

      {/* 2. Mobile Off-Canvas Drawer */}
      {isMobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          {/* Backdrop */}
          <div
            onClick={onCloseMobile}
            className="fixed inset-0 bg-black/50 backdrop-blur-xs transition-opacity animate-in fade-in"
            aria-hidden="true"
          />

          {/* Drawer Panel */}
          <div className="relative w-72 max-w-[85vw] h-full shadow-2xl z-50 animate-in slide-in-from-left duration-200">
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
};
