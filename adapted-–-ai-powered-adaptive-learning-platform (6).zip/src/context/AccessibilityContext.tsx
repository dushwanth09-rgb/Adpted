import React, { createContext, useContext, useState, useEffect } from 'react';

export type TextSize = 'sm' | 'md' | 'lg' | 'xl';

export interface AccessibilityContextType {
  textSize: TextSize;
  setTextSize: (size: TextSize) => void;
  increaseTextSize: () => void;
  decreaseTextSize: () => void;
  largeTextMode: boolean;
  toggleLargeTextMode: () => void;
  dyslexiaFont: boolean;
  toggleDyslexiaFont: () => void;
  highContrast: boolean;
  toggleHighContrast: () => void;
  darkMode: boolean;
  toggleDarkMode: () => void;
  spacedReading: boolean;
  toggleSpacedReading: () => void;
  reducedMotion: boolean;
  toggleReducedMotion: () => void;
  speechRate: number;
  setSpeechRate: (rate: number) => void;
  simplifiedEnglish: boolean;
  toggleSimplifiedEnglish: () => void;
  audioLearning: boolean;
  toggleAudioLearning: () => void;
  textToSpeechEnabled: boolean;
  toggleTextToSpeech: () => void;
  keyboardNavigation: boolean;
  toggleKeyboardNavigation: () => void;
  screenReaderSupport: boolean;
  toggleScreenReaderSupport: () => void;
  // Browser Speech Synthesis
  isSpeaking: boolean;
  isPaused: boolean;
  speakText: (text: string) => void;
  pauseSpeech: () => void;
  resumeSpeech: () => void;
  stopSpeech: () => void;
  resetToDefaults: () => void;
}

const AccessibilityContext = createContext<AccessibilityContextType | undefined>(undefined);

export const AccessibilityProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [textSize, setTextSizeState] = useState<TextSize>(() => {
    return (localStorage.getItem('adapted_text_size') as TextSize) || 'md';
  });

  const [dyslexiaFont, setDyslexiaFont] = useState<boolean>(() => {
    return localStorage.getItem('adapted_dyslexia_font') === 'true';
  });

  const [highContrast, setHighContrast] = useState<boolean>(() => {
    return localStorage.getItem('adapted_high_contrast') === 'true';
  });

  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('adapted_dark_mode') === 'true';
  });

  const [spacedReading, setSpacedReading] = useState<boolean>(() => {
    return localStorage.getItem('adapted_spaced_reading') === 'true';
  });

  const [reducedMotion, setReducedMotion] = useState<boolean>(() => {
    return localStorage.getItem('adapted_reduced_motion') === 'true';
  });

  const [speechRate, setSpeechRateState] = useState<number>(() => {
    const val = localStorage.getItem('adapted_speech_rate');
    return val ? parseFloat(val) : 1.0;
  });

  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [isPaused, setIsPaused] = useState<boolean>(false);

  const [simplifiedEnglish, setSimplifiedEnglish] = useState<boolean>(() => {
    return localStorage.getItem('adapted_simplified_english') === 'true';
  });

  const [audioLearning, setAudioLearning] = useState<boolean>(() => {
    return localStorage.getItem('adapted_audio_learning') === 'true';
  });

  const [textToSpeechEnabled, setTextToSpeechEnabled] = useState<boolean>(() => {
    const val = localStorage.getItem('adapted_tts_enabled');
    return val !== null ? val === 'true' : true;
  });

  const [keyboardNavigation, setKeyboardNavigation] = useState<boolean>(() => {
    return localStorage.getItem('adapted_keyboard_nav') === 'true';
  });

  const [screenReaderSupport, setScreenReaderSupport] = useState<boolean>(() => {
    return localStorage.getItem('adapted_screen_reader') === 'true';
  });

  const largeTextMode = textSize === 'lg' || textSize === 'xl';

  // Apply classes to document.documentElement
  useEffect(() => {
    const root = document.documentElement;

    // Text size
    root.classList.remove('text-size-sm', 'text-size-md', 'text-size-lg', 'text-size-xl');
    root.classList.add(`text-size-${textSize}`);
    localStorage.setItem('adapted_text_size', textSize);

    // Dyslexia font
    if (dyslexiaFont) root.classList.add('font-dyslexia');
    else root.classList.remove('font-dyslexia');
    localStorage.setItem('adapted_dyslexia_font', String(dyslexiaFont));

    // High contrast
    if (highContrast) root.classList.add('high-contrast');
    else root.classList.remove('high-contrast');
    localStorage.setItem('adapted_high_contrast', String(highContrast));

    // Dark mode
    if (darkMode) root.classList.add('dark');
    else root.classList.remove('dark');
    localStorage.setItem('adapted_dark_mode', String(darkMode));

    // Spaced reading
    if (spacedReading) root.classList.add('spacing-loose');
    else root.classList.remove('spacing-loose');
    localStorage.setItem('adapted_spaced_reading', String(spacedReading));

    // Reduced motion
    if (reducedMotion) root.classList.add('reduced-motion');
    else root.classList.remove('reduced-motion');
    localStorage.setItem('adapted_reduced_motion', String(reducedMotion));

    // Simplified English
    if (simplifiedEnglish) root.classList.add('simplified-english');
    else root.classList.remove('simplified-english');
    localStorage.setItem('adapted_simplified_english', String(simplifiedEnglish));

    // Keyboard navigation focus rings
    if (keyboardNavigation) root.classList.add('keyboard-mode');
    else root.classList.remove('keyboard-mode');
    localStorage.setItem('adapted_keyboard_nav', String(keyboardNavigation));

    // Screen reader optimized ARIA helper
    if (screenReaderSupport) root.classList.add('screen-reader-optimized');
    else root.classList.remove('screen-reader-optimized');
    localStorage.setItem('adapted_screen_reader', String(screenReaderSupport));

    localStorage.setItem('adapted_audio_learning', String(audioLearning));
    localStorage.setItem('adapted_tts_enabled', String(textToSpeechEnabled));
    localStorage.setItem('adapted_speech_rate', String(speechRate));
  }, [
    textSize,
    dyslexiaFont,
    highContrast,
    darkMode,
    spacedReading,
    reducedMotion,
    speechRate,
    simplifiedEnglish,
    audioLearning,
    textToSpeechEnabled,
    keyboardNavigation,
    screenReaderSupport,
  ]);

  const setTextSize = (size: TextSize) => setTextSizeState(size);

  const toggleLargeTextMode = () => {
    if (largeTextMode) {
      setTextSizeState('md');
    } else {
      setTextSizeState('lg');
    }
  };

  const increaseTextSize = () => {
    if (textSize === 'sm') setTextSizeState('md');
    else if (textSize === 'md') setTextSizeState('lg');
    else if (textSize === 'lg') setTextSizeState('xl');
  };

  const decreaseTextSize = () => {
    if (textSize === 'xl') setTextSizeState('lg');
    else if (textSize === 'lg') setTextSizeState('md');
    else if (textSize === 'md') setTextSizeState('sm');
  };

  const toggleDyslexiaFont = () => setDyslexiaFont((prev) => !prev);
  const toggleHighContrast = () => setHighContrast((prev) => !prev);
  const toggleDarkMode = () => setDarkMode((prev) => !prev);
  const toggleSpacedReading = () => setSpacedReading((prev) => !prev);
  const toggleReducedMotion = () => setReducedMotion((prev) => !prev);
  const toggleSimplifiedEnglish = () => setSimplifiedEnglish((prev) => !prev);
  const toggleAudioLearning = () => setAudioLearning((prev) => !prev);
  const toggleTextToSpeech = () => setTextToSpeechEnabled((prev) => !prev);
  const toggleKeyboardNavigation = () => setKeyboardNavigation((prev) => !prev);
  const toggleScreenReaderSupport = () => setScreenReaderSupport((prev) => !prev);
  const setSpeechRate = (rate: number) => setSpeechRateState(rate);

  // Web Speech API functions
  const speakText = (text: string) => {
    if (!textToSpeechEnabled) return;
    if (!('speechSynthesis' in window)) {
      console.warn('Speech synthesis not supported in this browser.');
      return;
    }

    window.speechSynthesis.cancel();
    if (!text || text.trim().length === 0) return;

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = speechRate;
    utterance.pitch = 1.0;

    // Pick an English voice if available
    const voices = window.speechSynthesis.getVoices();
    const englishVoice = voices.find((v) => v.lang.startsWith('en') && !v.name.includes('Bad'));
    if (englishVoice) utterance.voice = englishVoice;

    utterance.onstart = () => {
      setIsSpeaking(true);
      setIsPaused(false);
    };

    utterance.onend = () => {
      setIsSpeaking(false);
      setIsPaused(false);
    };

    utterance.onerror = () => {
      setIsSpeaking(false);
      setIsPaused(false);
    };

    window.speechSynthesis.speak(utterance);
  };

  const pauseSpeech = () => {
    if ('speechSynthesis' in window && isSpeaking) {
      window.speechSynthesis.pause();
      setIsPaused(true);
    }
  };

  const resumeSpeech = () => {
    if ('speechSynthesis' in window && isPaused) {
      window.speechSynthesis.resume();
      setIsPaused(false);
    }
  };

  const stopSpeech = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      setIsPaused(false);
    }
  };

  const resetToDefaults = () => {
    stopSpeech();
    setTextSizeState('md');
    setDyslexiaFont(false);
    setHighContrast(false);
    setDarkMode(false);
    setSpacedReading(false);
    setReducedMotion(false);
    setSimplifiedEnglish(false);
    setAudioLearning(false);
    setTextToSpeechEnabled(true);
    setKeyboardNavigation(false);
    setScreenReaderSupport(false);
    setSpeechRateState(1.0);
  };

  return (
    <AccessibilityContext.Provider
      value={{
        textSize,
        setTextSize,
        increaseTextSize,
        decreaseTextSize,
        largeTextMode,
        toggleLargeTextMode,
        dyslexiaFont,
        toggleDyslexiaFont,
        highContrast,
        toggleHighContrast,
        darkMode,
        toggleDarkMode,
        spacedReading,
        toggleSpacedReading,
        reducedMotion,
        toggleReducedMotion,
        speechRate,
        setSpeechRate,
        simplifiedEnglish,
        toggleSimplifiedEnglish,
        audioLearning,
        toggleAudioLearning,
        textToSpeechEnabled,
        toggleTextToSpeech,
        keyboardNavigation,
        toggleKeyboardNavigation,
        screenReaderSupport,
        toggleScreenReaderSupport,
        isSpeaking,
        isPaused,
        speakText,
        pauseSpeech,
        resumeSpeech,
        stopSpeech,
        resetToDefaults,
      }}
    >
      {children}
    </AccessibilityContext.Provider>
  );
};

export const useAccessibility = () => {
  const context = useContext(AccessibilityContext);
  if (!context) throw new Error('useAccessibility must be used within an AccessibilityProvider');
  return context;
};
