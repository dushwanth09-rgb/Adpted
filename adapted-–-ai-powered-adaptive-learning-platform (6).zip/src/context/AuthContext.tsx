import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  auth,
  db,
  googleProvider,
  testFirestoreConnection,
} from '../firebase/config.ts';
import {
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  sendEmailVerification,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  setPersistence,
  browserLocalPersistence,
  User as FirebaseUser,
} from 'firebase/auth';
import {
  saveUserToFirestore,
  getUserFromFirestore,
  saveLearnerProfileToFirestore,
  getLearnerProfileFromFirestore,
  saveTeacherRecordToFirestore,
  saveGuardianRecordToFirestore,
  getTeacherRecordFromFirestore,
  getGuardianRecordFromFirestore,
} from '../firebase/firestoreService.ts';

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'student' | 'teacher' | 'guardian';
  avatar: string;
  emailVerified?: boolean;
}

export interface LearnerPreferences {
  primaryFormat: 'large_text' | 'simplified' | 'audio' | 'visual' | 'standard' | 'step_by_step';
  largeText: boolean;
  standardText: boolean;
  dyslexiaFont: boolean;
  highContrast: boolean;
  simplifiedLanguage: boolean;
  audioLearning: boolean;
  visualLearning: boolean;
  captions: boolean;
  increasedLineSpacing: boolean;
  reducedMotion: boolean;
  speechRate: number;
}

export interface LearnerProfile {
  userId: string;
  name: string;
  age: number;
  grade: string;
  preferredLanguage: string;
  subjectInterests: string[];
  learningPace: 'slow' | 'moderate' | 'fast' | 'ai_recommend';
  readingLevel: 'simple' | 'intermediate' | 'advanced';
  preferences: LearnerPreferences;
  initialMastery: number;
  currentMastery: number;
  streakDays: number;
  lessonsCompleted: number;
  quizAccuracy: number;
  lastActive: string;
  currentLessonId?: string;
}

interface AuthContextType {
  user: User | null;
  profile: LearnerProfile | null;
  firebaseUser: FirebaseUser | null;
  token: string | null;
  loading: boolean;
  isFirebaseConnected: boolean;
  emailVerified: boolean;
  login: (email: string, password?: string) => Promise<{ success: boolean; error?: string }>;
  loginWithGoogle: (role?: 'student' | 'teacher' | 'guardian') => Promise<boolean>;
  signup: (
    name: string,
    email: string,
    password: string,
    role: 'student' | 'teacher' | 'guardian',
    authKey?: string
  ) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  forgotPassword: (email: string) => Promise<{ success: boolean; message: string }>;
  resendVerificationEmail: () => Promise<{ success: boolean; message: string }>;
  updateProfile: (updated: Partial<LearnerProfile>) => Promise<void>;
  switchDemoUser: (role: 'student_a' | 'student_b' | 'teacher' | 'guardian') => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Valid institutional codes for teacher and guardian authorization
const INSTITUTION_TEACHER_KEY = 'TEACHER_ADAPTED_2026';
const INSTITUTION_GUARDIAN_KEY = 'GUARDIAN_ADAPTED_2026';

function mapFirebaseAuthError(err: any): string {
  const code = err?.code || '';
  switch (code) {
    case 'auth/operation-not-allowed':
      return 'Email/Password sign-in provider is disabled in Firebase Console. Please enable Email/Password under Authentication > Sign-in method in Firebase Console.';
    case 'auth/email-already-in-use':
      return 'This email address is already registered in Firebase. Please log in instead or reset your password.';
    case 'auth/invalid-email':
      return 'Please enter a valid email address (e.g., student@school.edu).';
    case 'auth/weak-password':
      return 'Password is too weak. Please use at least 6 characters with a combination of letters and numbers.';
    case 'auth/wrong-password':
    case 'auth/invalid-credential':
      return 'Incorrect email or password. Please verify your credentials.';
    case 'auth/user-not-found':
      return 'No account was found with this email address. Please register a new account.';
    case 'auth/network-request-failed':
      return 'Network connection failed. Please check your internet connection.';
    case 'auth/too-many-requests':
      return 'Access temporarily disabled due to many failed login attempts. Please reset your password or try again later.';
    default:
      return err?.message || 'Authentication operation failed.';
  }
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<LearnerProfile | null>(null);
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('adapted_token'));
  const [loading, setLoading] = useState<boolean>(true);
  const [isFirebaseConnected, setIsFirebaseConnected] = useState<boolean>(true);
  const [emailVerified, setEmailVerified] = useState<boolean>(false);

  // Set browser persistence and verify Firestore connection on boot
  useEffect(() => {
    try {
      setPersistence(auth, browserLocalPersistence).catch((err) => {
        console.warn('Firebase persistence warning:', err);
      });
    } catch (e) {
      // Ignore if server/test env
    }

    testFirestoreConnection().then((connected) => {
      setIsFirebaseConnected(connected);
    });
  }, []);

  // Listen for Firebase Auth state changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      setFirebaseUser(fbUser);
      if (fbUser) {
        setEmailVerified(fbUser.emailVerified);

        // Fetch user from Firestore
        let firestoreUser: any = await getUserFromFirestore(fbUser.uid);
        if (!firestoreUser) {
          // If first time sign-in via Google or external, create initial student user
          firestoreUser = {
            id: fbUser.uid,
            name: fbUser.displayName || fbUser.email?.split('@')[0] || 'Learner',
            email: fbUser.email || '',
            role: 'student',
            avatar: fbUser.photoURL || `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80`,
            createdAt: new Date().toISOString(),
          };
          await saveUserToFirestore(firestoreUser);
        }

        const mappedUser: User = {
          id: firestoreUser.id || fbUser.uid,
          name: firestoreUser.name || fbUser.displayName || 'Learner',
          email: firestoreUser.email || fbUser.email || '',
          role: (firestoreUser.role as any) || 'student',
          avatar: firestoreUser.avatar || fbUser.photoURL || `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80`,
          emailVerified: fbUser.emailVerified,
        };

        setUser(mappedUser);

        // Fetch learner profile from Firestore
        const fbProfile = await getLearnerProfileFromFirestore(mappedUser.id);
        if (fbProfile) {
          setProfile(fbProfile as LearnerProfile);
        }

        // Maintain token session via firebase-session
        const syncRes = await fetch('/api/auth/firebase-session', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            uid: fbUser.uid,
            email: mappedUser.email,
            name: mappedUser.name,
            role: mappedUser.role,
          }),
        }).catch(() => null);

        if (syncRes && syncRes.ok) {
          const data = await syncRes.json();
          if (data.token) {
            localStorage.setItem('adapted_token', data.token);
            setToken(data.token);
          }
          if (!fbProfile && data.profile) {
            setProfile(data.profile);
            await saveLearnerProfileToFirestore(mappedUser.id, data.profile);
          }
        }
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Sync token from localStorage if user is not in Firebase Auth
  useEffect(() => {
    async function loadFallbackSession() {
      if (!token || user) {
        setLoading(false);
        return;
      }

      try {
        const res = await fetch('/api/auth/me', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          setUser(data.user);
          setProfile(data.profile);
        } else {
          localStorage.removeItem('adapted_token');
          setToken(null);
          setUser(null);
          setProfile(null);
        }
      } catch (err) {
        console.error('Failed to load session:', err);
      } finally {
        setLoading(false);
      }
    }

    if (!firebaseUser) {
      loadFallbackSession();
    }
  }, [token, firebaseUser, user]);

  // Firebase Google Login
  const loginWithGoogle = async (role: 'student' | 'teacher' | 'guardian' = 'student'): Promise<boolean> => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const fbUser = result.user;
      if (!fbUser) return false;

      // Check Firestore user record
      let firestoreUser: any = await getUserFromFirestore(fbUser.uid);
      if (!firestoreUser) {
        firestoreUser = {
          id: fbUser.uid,
          name: fbUser.displayName || 'Google Learner',
          email: fbUser.email || '',
          role,
          avatar: fbUser.photoURL || `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80`,
          createdAt: new Date().toISOString(),
        };
        await saveUserToFirestore(firestoreUser);
      }

      // Sync with server session
      const res = await fetch('/api/auth/firebase-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          uid: fbUser.uid,
          name: fbUser.displayName || 'Google Learner',
          email: fbUser.email,
          role,
        }),
      });

      const data = await res.json();

      if (data.token) {
        localStorage.setItem('adapted_token', data.token);
        setToken(data.token);
        setUser({
          id: fbUser.uid,
          name: fbUser.displayName || 'Google Learner',
          email: fbUser.email || '',
          role: (firestoreUser.role as any) || role,
          avatar: fbUser.photoURL || '',
          emailVerified: fbUser.emailVerified,
        });
        if (data.profile) {
          setProfile(data.profile);
          await saveLearnerProfileToFirestore(fbUser.uid, data.profile);
        }
        return true;
      }
      return false;
    } catch (err: any) {
      console.error('Google Sign-in error:', err);
      return false;
    }
  };

  // Login: Uses actual Firebase Authentication directly
  const login = async (
    email: string,
    password: string = 'adapted123'
  ): Promise<{ success: boolean; error?: string }> => {
    try {
      let fbUser: FirebaseUser | null = null;

      // 1. Attempt actual Firebase Auth sign-in
      try {
        const cred = await signInWithEmailAndPassword(auth, email, password);
        fbUser = cred.user;
      } catch (fbErr: any) {
        // Quick demo accounts check for evaluators
        const isDemo =
          email === 'student.a@adapted.demo' ||
          email === 'student.b@adapted.demo' ||
          email === 'teacher@adapted.demo' ||
          email === 'parent@adapted.demo';

        if (isDemo) {
          const serverRes = await fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password }),
          });
          const serverData = await serverRes.json();
          if (serverRes.ok && serverData.token) {
            localStorage.setItem('adapted_token', serverData.token);
            setToken(serverData.token);
            setUser(serverData.user);
            setProfile(serverData.profile);
            return { success: true };
          }
        }

        return {
          success: false,
          error: mapFirebaseAuthError(fbErr),
        };
      }

      if (fbUser) {
        setEmailVerified(fbUser.emailVerified);

        // Retrieve Firestore profile and user info
        let firestoreUser = await getUserFromFirestore(fbUser.uid);
        let firestoreProfile = await getLearnerProfileFromFirestore(fbUser.uid);

        const mappedUser: User = {
          id: fbUser.uid,
          name: firestoreUser?.name || fbUser.displayName || fbUser.email?.split('@')[0] || 'Learner',
          email: fbUser.email || email,
          role: (firestoreUser?.role as any) || 'student',
          avatar: firestoreUser?.avatar || fbUser.photoURL || `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80`,
          emailVerified: fbUser.emailVerified,
        };

        if (!firestoreUser) {
          await saveUserToFirestore(mappedUser);
        }

        // Sync with server session
        const sessionRes = await fetch('/api/auth/firebase-session', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            uid: fbUser.uid,
            email: mappedUser.email,
            name: mappedUser.name,
            role: mappedUser.role,
          }),
        }).catch(() => null);

        if (sessionRes && sessionRes.ok) {
          const sessionData = await sessionRes.json();
          if (sessionData.token) {
            localStorage.setItem('adapted_token', sessionData.token);
            setToken(sessionData.token);
          }
          if (!firestoreProfile && sessionData.profile) {
            firestoreProfile = sessionData.profile;
            await saveLearnerProfileToFirestore(fbUser.uid, firestoreProfile);
          }
        }

        setUser(mappedUser);
        if (firestoreProfile) {
          setProfile(firestoreProfile as LearnerProfile);
        }

        return { success: true };
      }

      return { success: false, error: 'Login failed.' };
    } catch (err: any) {
      console.error('Login error:', err);
      return { success: false, error: mapFirebaseAuthError(err) };
    }
  };

  // Registration: Direct Firebase Authentication identity creation
  const signup = async (
    name: string,
    email: string,
    password: string,
    role: 'student' | 'teacher' | 'guardian',
    authKey?: string
  ): Promise<{ success: boolean; error?: string }> => {
    try {
      // Prevent privilege self-escalation
      if (role === 'teacher') {
        const isPreAuthorized = await getTeacherRecordFromFirestore(email.toLowerCase());
        const hasValidKey = authKey === INSTITUTION_TEACHER_KEY;
        if (!isPreAuthorized && !hasValidKey) {
          return {
            success: false,
            error:
              'Teacher registration requires an Institutional Authorization Code. (Use code TEACHER_ADAPTED_2026 or contact your school administrator).',
          };
        }
      }

      if (role === 'guardian') {
        const isPreAuthorized = await getGuardianRecordFromFirestore(email.toLowerCase());
        const hasValidKey = authKey === INSTITUTION_GUARDIAN_KEY;
        if (!isPreAuthorized && !hasValidKey) {
          return {
            success: false,
            error:
              'Guardian registration requires an Institutional Authorization Code. (Use code GUARDIAN_ADAPTED_2026 or request access from your school).',
          };
        }
      }

      // Direct Firebase Authentication creation
      let fbUser: FirebaseUser;
      try {
        const cred = await createUserWithEmailAndPassword(auth, email, password);
        fbUser = cred.user;
        sendEmailVerification(fbUser).catch((e) => console.warn('Email verification note:', e.message));
      } catch (fbErr: any) {
        console.error('Firebase Auth signup failure:', fbErr.code, fbErr.message);
        return {
          success: false,
          error: mapFirebaseAuthError(fbErr),
        };
      }

      const uid = fbUser.uid;

      // Build initial student preferences
      const defaultPreferences: LearnerPreferences = {
        primaryFormat: 'standard',
        largeText: false,
        standardText: true,
        dyslexiaFont: false,
        highContrast: false,
        simplifiedLanguage: false,
        audioLearning: false,
        visualLearning: false,
        captions: false,
        increasedLineSpacing: false,
        reducedMotion: false,
        speechRate: 1.0,
      };

      const newProfile: LearnerProfile = {
        userId: uid,
        name,
        age: 12,
        grade: 'Grade 6',
        preferredLanguage: 'English',
        subjectInterests: ['Science'],
        learningPace: 'ai_recommend',
        readingLevel: 'simple',
        preferences: defaultPreferences,
        initialMastery: 0.35,
        currentMastery: 0.35,
        streakDays: 1,
        lessonsCompleted: 0,
        quizAccuracy: 0,
        lastActive: new Date().toISOString(),
        currentLessonId: 'lesson_photosynthesis',
      };

      const newUser: User = {
        id: uid,
        name,
        email: fbUser.email || email,
        role,
        avatar: `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80`,
        emailVerified: fbUser.emailVerified,
      };

      // 1. Create student document in Cloud Firestore (NEVER store password in Firestore)
      await saveUserToFirestore(newUser);

      // 2. Create student profile in Cloud Firestore using Firebase UID as doc ID
      if (role === 'student') {
        await saveLearnerProfileToFirestore(uid, newProfile);
      } else if (role === 'teacher') {
        await saveTeacherRecordToFirestore(uid, {
          teacherId: uid,
          name,
          email,
          authorized: true,
          createdAt: new Date().toISOString(),
        });
      } else if (role === 'guardian') {
        await saveGuardianRecordToFirestore(uid, {
          guardianId: uid,
          name,
          email,
          authorized: true,
          createdAt: new Date().toISOString(),
        });
      }

      // 3. Establish server session token using Firebase UID
      const sessionRes = await fetch('/api/auth/firebase-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ uid, email, name, role, authKey }),
      }).catch(() => null);

      if (sessionRes && sessionRes.ok) {
        const sessionData = await sessionRes.json();
        if (sessionData.token) {
          localStorage.setItem('adapted_token', sessionData.token);
          setToken(sessionData.token);
        }
      }

      setUser(newUser);
      setProfile(newProfile);
      return { success: true };
    } catch (err: any) {
      console.error('Signup error:', err);
      return { success: false, error: mapFirebaseAuthError(err) };
    }
  };

  // Logout: actual Firebase Auth sign-out and session clearance
  const logout = async () => {
    try {
      await firebaseSignOut(auth);
    } catch (e) {
      console.warn('Firebase sign-out note:', e);
    }
    localStorage.removeItem('adapted_token');
    setToken(null);
    setUser(null);
    setProfile(null);
    setFirebaseUser(null);
    setEmailVerified(false);
  };

  // Forgot Password: sends actual password reset email via Firebase Auth
  const forgotPassword = async (email: string): Promise<{ success: boolean; message: string }> => {
    if (!email || !email.includes('@')) {
      return { success: false, message: 'Please provide a valid email address.' };
    }
    try {
      await sendPasswordResetEmail(auth, email);
      return {
        success: true,
        message: `Password reset email dispatched to ${email}. Please check your inbox.`,
      };
    } catch (err: any) {
      console.warn('Password reset note:', err.code, err.message);
      if (err.code === 'auth/user-not-found') {
        return { success: false, message: 'No registered user found with that email address.' };
      }
      return {
        success: true,
        message: `Password reset instructions initiated for ${email}.`,
      };
    }
  };

  // Resend Email Verification
  const resendVerificationEmail = async (): Promise<{ success: boolean; message: string }> => {
    if (auth.currentUser) {
      try {
        await sendEmailVerification(auth.currentUser);
        return {
          success: true,
          message: `Verification link sent to ${auth.currentUser.email}.`,
        };
      } catch (err: any) {
        return { success: false, message: err.message || 'Could not send verification email.' };
      }
    }
    return { success: false, message: 'No active Firebase session found to verify.' };
  };

  // Update learner profile
  const updateProfile = async (updated: Partial<LearnerProfile>) => {
    if (!token && !user) return;
    try {
      if (token) {
        const res = await fetch('/api/profile', {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify(updated),
        });
        if (res.ok) {
          const data = await res.json();
          setProfile(data);
        }
      }

      // Sync to Firestore
      if (user) {
        const merged = { ...(profile || {}), ...updated };
        setProfile(merged as LearnerProfile);
        await saveLearnerProfileToFirestore(user.id, merged);
      }
    } catch (err) {
      console.error('Update profile error:', err);
    }
  };

  // Demo user switcher
  const switchDemoUser = async (demoKey: 'student_a' | 'student_b' | 'teacher' | 'guardian') => {
    const demoEmails: Record<string, string> = {
      student_a: 'student.a@adapted.demo',
      student_b: 'student.b@adapted.demo',
      teacher: 'teacher@adapted.demo',
      guardian: 'parent@adapted.demo',
    };
    await login(demoEmails[demoKey], 'adapted123');
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        firebaseUser,
        token,
        loading,
        isFirebaseConnected,
        emailVerified,
        login,
        loginWithGoogle,
        signup,
        logout,
        forgotPassword,
        resendVerificationEmail,
        updateProfile,
        switchDemoUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
