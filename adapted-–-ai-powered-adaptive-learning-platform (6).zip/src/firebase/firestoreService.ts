import {
  doc,
  setDoc,
  getDoc,
  getDocs,
  collection,
  query,
  where,
  updateDoc,
} from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage, handleFirestoreError, OperationType } from './config.ts';

// ------------------------------------------------------------------
// 1. Users Collection (Student, Teacher, Guardian)
// ------------------------------------------------------------------
export async function saveUserToFirestore(user: {
  id: string;
  name: string;
  email: string;
  role: string;
  avatar?: string;
  createdAt?: string;
}) {
  const path = `users/${user.id}`;
  try {
    await setDoc(doc(db, 'users', user.id), {
      ...user,
      updatedAt: new Date().toISOString(),
    }, { merge: true });
    return true;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function getUserFromFirestore(userId: string) {
  const path = `users/${userId}`;
  try {
    const snap = await getDoc(doc(db, 'users', userId));
    return snap.exists() ? snap.data() : null;
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, path);
  }
}

// ------------------------------------------------------------------
// 2. Learner Profiles Collection
// ------------------------------------------------------------------
export async function saveLearnerProfileToFirestore(userId: string, data: any) {
  const path = `learnerProfiles/${userId}`;
  try {
    await setDoc(doc(db, 'learnerProfiles', userId), data, { merge: true });
    return true;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function getLearnerProfileFromFirestore(userId: string) {
  const path = `learnerProfiles/${userId}`;
  try {
    const snap = await getDoc(doc(db, 'learnerProfiles', userId));
    return snap.exists() ? snap.data() : null;
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, path);
  }
}

// ------------------------------------------------------------------
// 3. Lessons Collection
// ------------------------------------------------------------------
export async function saveLessonToFirestore(lesson: any) {
  const path = `lessons/${lesson.id}`;
  try {
    await setDoc(doc(db, 'lessons', lesson.id), lesson, { merge: true });
    return true;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function getLessonsFromFirestore(): Promise<any[]> {
  const path = 'lessons';
  try {
    const snap = await getDocs(collection(db, 'lessons'));
    const lessons: any[] = [];
    snap.forEach((d) => lessons.push(d.data()));
    return lessons;
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, path);
  }
}

export async function getLessonFromFirestore(lessonId: string) {
  const path = `lessons/${lessonId}`;
  try {
    const snap = await getDoc(doc(db, 'lessons', lessonId));
    return snap.exists() ? snap.data() : null;
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, path);
  }
}

// ------------------------------------------------------------------
// 4. Quiz Results & Attempts
// ------------------------------------------------------------------
export async function saveQuizResultToFirestore(quizResult: {
  id: string;
  studentId: string;
  lessonId: string;
  questionId: string;
  questionText?: string;
  selectedOption?: number;
  isCorrect: boolean;
  score?: number;
  formatUsed?: string;
  timestamp?: string;
  pMasteryBefore?: number;
  pMasteryAfter?: number;
}) {
  const resultData = {
    ...quizResult,
    timestamp: quizResult.timestamp || new Date().toISOString(),
  };

  // Write to both quizResults and attempts for full compatibility
  try {
    await setDoc(doc(db, 'quizResults', quizResult.id), resultData, { merge: true });
    await setDoc(doc(db, 'attempts', quizResult.id), resultData, { merge: true });
    return true;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `quizResults/${quizResult.id}`);
  }
}

export async function getQuizResultFromFirestore(id: string) {
  try {
    const snap = await getDoc(doc(db, 'quizResults', id));
    if (snap.exists()) return snap.data();
    const fallbackSnap = await getDoc(doc(db, 'attempts', id));
    return fallbackSnap.exists() ? fallbackSnap.data() : null;
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, `quizResults/${id}`);
  }
}

export async function saveAttemptToFirestore(attempt: any) {
  return saveQuizResultToFirestore(attempt);
}

export async function getAttemptsForStudent(studentId: string): Promise<any[]> {
  const path = 'quizResults';
  try {
    const q = query(collection(db, 'quizResults'), where('studentId', '==', studentId));
    const snap = await getDocs(q);
    const results: any[] = [];
    snap.forEach((d) => results.push(d.data()));
    if (results.length > 0) return results;

    // Fallback to attempts collection
    const attemptsSnap = await getDocs(query(collection(db, 'attempts'), where('studentId', '==', studentId)));
    attemptsSnap.forEach((d) => results.push(d.data()));
    return results;
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, path);
  }
}

// ------------------------------------------------------------------
// 5. Learning Progress & BKT Bayesian Knowledge Tracing Mastery
// ------------------------------------------------------------------
export async function saveLearningProgressToFirestore(
  studentId: string,
  topic: string,
  progress: {
    studentId: string;
    topic: string;
    pMastery: number;
    attemptsCount: number;
    correctCount: number;
    lastUpdated?: string;
    history?: any[];
  }
) {
  const progressDocId = `${studentId}_${topic}`;
  const data = {
    ...progress,
    lastUpdated: progress.lastUpdated || new Date().toISOString(),
  };

  try {
    // Write to both learningProgress and masteryStates sub-collection
    await setDoc(doc(db, 'learningProgress', progressDocId), data, { merge: true });
    await setDoc(doc(db, 'masteryStates', studentId, 'topics', topic), data, { merge: true });
    return true;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `learningProgress/${progressDocId}`);
  }
}

export async function getLearningProgressFromFirestore(studentId: string, topic: string) {
  const progressDocId = `${studentId}_${topic}`;
  try {
    const snap = await getDoc(doc(db, 'learningProgress', progressDocId));
    if (snap.exists()) return snap.data();
    const fallbackSnap = await getDoc(doc(db, 'masteryStates', studentId, 'topics', topic));
    return fallbackSnap.exists() ? fallbackSnap.data() : null;
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, `learningProgress/${progressDocId}`);
  }
}

export async function saveMasteryToFirestore(studentId: string, topic: string, record: any) {
  return saveLearningProgressToFirestore(studentId, topic, { studentId, topic, ...record });
}

export async function getMasteryFromFirestore(studentId: string, topic: string) {
  return getLearningProgressFromFirestore(studentId, topic);
}

// ------------------------------------------------------------------
// 6. Teacher and Guardian Records
// ------------------------------------------------------------------
export async function saveTeacherRecordToFirestore(teacherId: string, record: any) {
  try {
    await setDoc(doc(db, 'teacherRecords', teacherId), record, { merge: true });
    await setDoc(doc(db, 'teachers', teacherId), record, { merge: true });
    return true;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `teacherRecords/${teacherId}`);
  }
}

export async function getTeacherRecordFromFirestore(teacherId: string) {
  try {
    const snap = await getDoc(doc(db, 'teacherRecords', teacherId));
    if (snap.exists()) return snap.data();
    const fallbackSnap = await getDoc(doc(db, 'teachers', teacherId));
    return fallbackSnap.exists() ? fallbackSnap.data() : null;
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, `teacherRecords/${teacherId}`);
  }
}

export async function saveGuardianRecordToFirestore(guardianId: string, record: any) {
  try {
    await setDoc(doc(db, 'guardianRecords', guardianId), record, { merge: true });
    await setDoc(doc(db, 'guardians', guardianId), record, { merge: true });
    return true;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `guardianRecords/${guardianId}`);
  }
}

export async function getGuardianRecordFromFirestore(guardianId: string) {
  try {
    const snap = await getDoc(doc(db, 'guardianRecords', guardianId));
    if (snap.exists()) return snap.data();
    const fallbackSnap = await getDoc(doc(db, 'guardians', guardianId));
    return fallbackSnap.exists() ? fallbackSnap.data() : null;
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, `guardianRecords/${guardianId}`);
  }
}

// ------------------------------------------------------------------
// 7. Firebase Storage Uploads (PDF, Image, Audio) & Metadata
// ------------------------------------------------------------------
export async function saveAssetMetadataToFirestore(asset: {
  id: string;
  filename: string;
  storagePath: string;
  url: string;
  contentType: string;
  size?: number;
  uploadedAt?: string;
  uploaderId?: string;
}) {
  const path = `uploadedAssets/${asset.id}`;
  try {
    await setDoc(
      doc(db, 'uploadedAssets', asset.id),
      {
        ...asset,
        uploadedAt: asset.uploadedAt || new Date().toISOString(),
      },
      { merge: true }
    );
    return true;
  } catch (err) {
    console.warn('Firestore asset metadata note:', err);
    return false;
  }
}

export async function getUploadedAssetsFromFirestore(): Promise<any[]> {
  const path = 'uploadedAssets';
  try {
    const snap = await getDocs(collection(db, 'uploadedAssets'));
    const assets: any[] = [];
    snap.forEach((d) => assets.push(d.data()));
    return assets;
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, path);
  }
}

export async function uploadMediaAssetToStorage(
  storagePath: string,
  file: File | Blob | Uint8Array | Buffer,
  contentType?: string
): Promise<string> {
  let finalUrl = '';
  let detectedType = contentType || 'application/octet-stream';
  let filename = storagePath.split('/').pop() || 'upload.bin';
  let fileSize = 0;

  try {
    const storageRef = ref(storage, storagePath);
    const metadata = contentType ? { contentType } : undefined;
    const uploadSnap = await uploadBytes(storageRef, file as any, metadata);
    finalUrl = await getDownloadURL(storageRef);
    fileSize = uploadSnap.metadata?.size || 0;
  } catch (err: any) {
    console.warn('Firebase Storage direct upload note (fallback activating):', err?.message);
    // Resilient server fallback while Firebase Storage bucket awaits 1-click activation
    try {
      let base64 = '';

      if (typeof File !== 'undefined' && file instanceof File) {
        detectedType = file.type || detectedType;
        filename = file.name;
        fileSize = file.size;
        base64 = await new Promise((resolve) => {
          const reader = new FileReader();
          reader.onload = () => {
            const res = reader.result as string;
            resolve(res.split(',')[1] || res);
          };
          reader.readAsDataURL(file);
        });
      } else if (typeof Blob !== 'undefined' && file instanceof Blob) {
        detectedType = file.type || detectedType;
        fileSize = file.size;
        base64 = await new Promise((resolve) => {
          const reader = new FileReader();
          reader.onload = () => {
            const res = reader.result as string;
            resolve(res.split(',')[1] || res);
          };
          reader.readAsDataURL(file);
        });
      } else if (typeof Buffer !== 'undefined' && Buffer.isBuffer(file)) {
        base64 = file.toString('base64');
        fileSize = file.length;
      } else if (file instanceof Uint8Array) {
        fileSize = file.byteLength;
        base64 = Buffer.from(file).toString('base64');
      }

      if (base64) {
        const fallbackRes = await fetch('/api/storage/upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            filename,
            contentType: detectedType,
            dataBase64: base64,
          }),
        });

        if (fallbackRes.ok) {
          const data = await fallbackRes.json();
          finalUrl = data.url;
        }
      }
    } catch (fallbackErr) {
      console.warn('Resilient fallback storage error:', fallbackErr);
    }
  }

  if (finalUrl) {
    // Record file metadata in Cloud Firestore
    const assetId = `asset_${Date.now()}`;
    saveAssetMetadataToFirestore({
      id: assetId,
      filename,
      storagePath,
      url: finalUrl,
      contentType: detectedType,
      size: fileSize,
      uploadedAt: new Date().toISOString(),
    }).catch((e) => console.warn('Asset metadata firestore logging note:', e));

    return finalUrl;
  }

  throw new Error('Upload failed: Storage service unavailable and fallback was unreachable.');
}

