import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import {
  GraduationCap,
  Users,
  Shield,
  ArrowRight,
  Sparkles,
  Lock,
  Mail,
  User as UserIcon,
  AlertCircle,
  KeyRound,
  CheckCircle2,
  HelpCircle,
} from 'lucide-react';

interface AuthPageProps {
  onNavigate: (view: string) => void;
}

export const AuthPage: React.FC<AuthPageProps> = ({ onNavigate }) => {
  const { login, signup, switchDemoUser, loginWithGoogle, forgotPassword } = useAuth();

  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [role, setRole] = useState<'student' | 'teacher' | 'guardian'>('student');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('adapted123');
  const [authKey, setAuthKey] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [loading, setLoading] = useState(false);
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotMsg, setForgotMsg] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    setLoading(true);

    try {
      if (mode === 'login') {
        const res = await login(email, password);
        if (res.success) {
          if (email.includes('teacher')) onNavigate('teacher_dashboard');
          else if (email.includes('parent')) onNavigate('guardian_dashboard');
          else onNavigate('student_dashboard');
        } else {
          setErrorMsg(res.error || 'Invalid email or password. You can also click any Quick Demo Account below.');
        }
      } else {
        if (!name.trim()) {
          setErrorMsg('Please enter your full name');
          setLoading(false);
          return;
        }
        const res = await signup(name, email, password, role, authKey);
        if (res.success) {
          if (role === 'student') {
            onNavigate('onboarding');
          } else if (role === 'teacher') {
            onNavigate('teacher_dashboard');
          } else {
            onNavigate('guardian_dashboard');
          }
        } else {
          setErrorMsg(res.error || 'Registration failed. Please check your credentials.');
        }
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'An error occurred during authentication.');
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotMsg('');
    setLoading(true);
    const res = await forgotPassword(forgotEmail);
    setLoading(false);
    setForgotMsg(res.message);
  };

  const handleQuickLogin = async (key: 'student_a' | 'student_b' | 'teacher' | 'guardian') => {
    setLoading(true);
    await switchDemoUser(key);
    setLoading(false);
    if (key === 'teacher') onNavigate('teacher_dashboard');
    else if (key === 'guardian') onNavigate('guardian_dashboard');
    else onNavigate('student_dashboard');
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 bg-[#F7F9FC] dark:bg-slate-950 transition-colors">
      <div className="max-w-md w-full space-y-8 bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl">
        {/* Header */}
        <div className="text-center">
          <img
            src="/assets/aistudio/image_7f43828e.png"
            alt="AdaptEd - Learn • Adapt • Achieve"
            className="mx-auto h-20 w-auto object-contain bg-white rounded-2xl p-1.5 shadow-md border border-slate-100"
          />
          <h2 className="mt-4 text-2xl font-extrabold text-slate-900 dark:text-white">
            {mode === 'login' ? 'Sign in to AdaptEd' : 'Create your account'}
          </h2>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            {mode === 'login'
              ? 'Enter your credentials or choose a pre-configured demo account below.'
              : 'Empowering accessible, adaptive learning for every student.'}
          </p>
        </div>

        {/* Quick Demo Accounts Fast Bar */}
        <div className="bg-blue-50/80 dark:bg-slate-800/80 p-3.5 rounded-2xl border border-blue-100 dark:border-slate-700">
          <span className="block text-[11px] font-bold uppercase tracking-wider text-[#1F4E79] dark:text-blue-300 mb-2 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-blue-500" />
            1-Click Demo Profiles for Evaluators
          </span>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <button
              type="button"
              onClick={() => handleQuickLogin('student_a')}
              className="p-2 bg-white dark:bg-slate-700 hover:bg-blue-50 rounded-xl border border-blue-200 dark:border-slate-600 text-left transition-all"
            >
              <strong className="block text-slate-900 dark:text-white text-[11px]">Learner A (Aarav)</strong>
              <span className="text-[10px] text-slate-500 dark:text-slate-300">Large Text & Audio</span>
            </button>

            <button
              type="button"
              onClick={() => handleQuickLogin('student_b')}
              className="p-2 bg-white dark:bg-slate-700 hover:bg-blue-50 rounded-xl border border-blue-200 dark:border-slate-600 text-left transition-all"
            >
              <strong className="block text-slate-900 dark:text-white text-[11px]">Learner B (Meera)</strong>
              <span className="text-[10px] text-slate-500 dark:text-slate-300">Simplified & Visual</span>
            </button>

            <button
              type="button"
              onClick={() => handleQuickLogin('teacher')}
              className="p-2 bg-white dark:bg-slate-700 hover:bg-blue-50 rounded-xl border border-blue-200 dark:border-slate-600 text-left transition-all"
            >
              <strong className="block text-slate-900 dark:text-white text-[11px]">Teacher (Elena)</strong>
              <span className="text-[10px] text-slate-500 dark:text-slate-300">Class & Lesson Upload</span>
            </button>

            <button
              type="button"
              onClick={() => handleQuickLogin('guardian')}
              className="p-2 bg-white dark:bg-slate-700 hover:bg-blue-50 rounded-xl border border-blue-200 dark:border-slate-600 text-left transition-all"
            >
              <strong className="block text-slate-900 dark:text-white text-[11px]">Parent (Rajesh)</strong>
              <span className="text-[10px] text-slate-500 dark:text-slate-300">Guardian Portal</span>
            </button>
          </div>
        </div>

        {/* Mode Selector Tabs */}
        <div className="flex p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
          <button
            type="button"
            onClick={() => {
              setMode('login');
              setShowForgotPassword(false);
              setErrorMsg('');
            }}
            className={`w-1/2 py-2 text-xs font-semibold rounded-lg transition-all ${
              mode === 'login' && !showForgotPassword
                ? 'bg-white dark:bg-slate-700 text-[#1F4E79] dark:text-blue-300 shadow-xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('signup');
              setShowForgotPassword(false);
              setErrorMsg('');
            }}
            className={`w-1/2 py-2 text-xs font-semibold rounded-lg transition-all ${
              mode === 'signup' && !showForgotPassword
                ? 'bg-white dark:bg-slate-700 text-[#1F4E79] dark:text-blue-300 shadow-xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Register New Account
          </button>
        </div>

        {errorMsg && (
          <div className="p-3 bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-xs rounded-xl flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="p-3 bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-900 text-emerald-700 dark:text-emerald-300 text-xs rounded-xl flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Forgot Password Section */}
        {showForgotPassword ? (
          <div className="space-y-4">
            <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-1 flex items-center gap-1.5">
                <KeyRound className="w-4 h-4 text-[#1F4E79] dark:text-blue-400" />
                Reset Password (Firebase Auth)
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">
                Enter your account email. Firebase will send a secure password reset link.
              </p>
              <form onSubmit={handleForgotPassword} className="space-y-3">
                <input
                  type="email"
                  required
                  value={forgotEmail}
                  onChange={(e) => setForgotEmail(e.target.value)}
                  placeholder="your-email@domain.com"
                  className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-[#1F4E79]"
                />
                {forgotMsg && (
                  <p className="text-xs text-blue-600 dark:text-blue-400 font-medium">{forgotMsg}</p>
                )}
                <div className="flex gap-2">
                  <button
                    type="submit"
                    disabled={loading}
                    className="flex-1 py-2 bg-[#1F4E79] hover:bg-[#163a5c] text-white text-xs font-bold rounded-xl transition-colors disabled:opacity-50"
                  >
                    Send Reset Link
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowForgotPassword(false)}
                    className="px-3 py-2 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold rounded-xl hover:bg-slate-300"
                  >
                    Back to Login
                  </button>
                </div>
              </form>
            </div>
          </div>
        ) : (
          <>
            {/* Google Firebase Auth Sign-In */}
            <div>
              <button
                type="button"
                disabled={loading}
                onClick={async () => {
                  setLoading(true);
                  setErrorMsg('');
                  const ok = await loginWithGoogle(role);
                  setLoading(false);
                  if (ok) {
                    if (role === 'teacher') onNavigate('teacher_dashboard');
                    else if (role === 'guardian') onNavigate('guardian_dashboard');
                    else onNavigate('student_dashboard');
                  } else {
                    setErrorMsg('Google sign-in was cancelled or encountered an error.');
                  }
                }}
                className="w-full py-2.5 px-4 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-700 rounded-xl font-semibold text-xs transition-colors flex items-center justify-center gap-2 shadow-xs"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.8-2.4 3.66v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.15z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.27v3.15C3.25 21.36 7.31 24 12 24z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.27C.46 8.2.01 10.04.01 12s.45 3.8 1.26 5.42l4.01-3.15z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.25 2.64 1.27 6.58l4.01 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                  />
                </svg>
                <span>Continue with Google (Firebase Auth)</span>
              </button>

              <div className="relative my-4">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-slate-200 dark:border-slate-800" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-white dark:bg-slate-900 px-2 text-slate-400">
                    Or continue with email / demo
                  </span>
                </div>
              </div>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              {mode === 'signup' && (
                <>
                  {/* Role Selection */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase mb-1">
                      Select Role
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { id: 'student', label: 'Student', icon: GraduationCap },
                        { id: 'teacher', label: 'Teacher', icon: Users },
                        { id: 'guardian', label: 'Parent', icon: Shield },
                      ].map((r) => {
                        const Icon = r.icon;
                        return (
                          <button
                            key={r.id}
                            type="button"
                            onClick={() => {
                              setRole(r.id as any);
                              setErrorMsg('');
                            }}
                            className={`p-2.5 rounded-xl border text-center transition-all ${
                              role === r.id
                                ? 'border-[#1F4E79] bg-blue-50/50 dark:bg-slate-800 text-[#1F4E79] dark:text-blue-300 font-bold'
                                : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                            }`}
                          >
                            <Icon className="w-4 h-4 mx-auto mb-1" />
                            <span className="text-xs block">{r.label}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Institutional Key requirement for Teacher/Guardian roles to prevent privilege self-escalation */}
                  {role !== 'student' && (
                    <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 rounded-xl space-y-1.5">
                      <div className="flex items-center gap-1.5 text-amber-800 dark:text-amber-300 text-xs font-bold">
                        <KeyRound className="w-3.5 h-3.5 text-amber-600" />
                        <span>Institutional Verification Code Required</span>
                      </div>
                      <p className="text-[11px] text-amber-700 dark:text-amber-400">
                        {role === 'teacher'
                          ? 'Educator accounts require institutional credentials. Use key TEACHER_ADAPTED_2026 or contact your school admin.'
                          : 'Guardian accounts require linkage code. Use key GUARDIAN_ADAPTED_2026 or request access from your school.'}
                      </p>
                      <input
                        type="text"
                        required
                        value={authKey}
                        onChange={(e) => setAuthKey(e.target.value)}
                        placeholder={role === 'teacher' ? 'TEACHER_ADAPTED_2026' : 'GUARDIAN_ADAPTED_2026'}
                        className="w-full px-3 py-1.5 text-xs bg-white dark:bg-slate-900 border border-amber-300 dark:border-amber-700 rounded-lg focus:ring-1 focus:ring-amber-500 font-mono"
                      />
                    </div>
                  )}

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase mb-1">
                      Full Name
                    </label>
                    <div className="relative">
                      <UserIcon className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="e.g. Alex Johnson"
                        className="w-full pl-9 pr-3 py-2 text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-[#1F4E79]"
                      />
                    </div>
                  </div>
                </>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase mb-1">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="student.a@adapted.demo"
                    className="w-full pl-9 pr-3 py-2 text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-[#1F4E79]"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase">
                    Password
                  </label>
                  {mode === 'login' && (
                    <button
                      type="button"
                      onClick={() => {
                        setShowForgotPassword(true);
                        setForgotEmail(email);
                      }}
                      className="text-[11px] text-[#1F4E79] dark:text-blue-400 hover:underline font-semibold"
                    >
                      Forgot password?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-3 py-2 text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-[#1F4E79]"
                  />
                </div>
                {mode === 'login' && (
                  <span className="text-[11px] text-slate-500 mt-1 block">
                    Demo accounts password is <strong>adapted123</strong>
                  </span>
                )}
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 px-4 bg-[#1F4E79] hover:bg-[#163a5c] text-white font-bold rounded-xl shadow-md transition-colors flex items-center justify-center gap-2 mt-2 disabled:opacity-50"
              >
                <span>{loading ? 'Please wait...' : mode === 'login' ? 'Sign In' : 'Create Account'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
};
