import React, { useState, useEffect } from 'react';
import { useAccessibility } from '../context/AccessibilityContext.tsx';
import { InteractiveDiagram } from '../components/InteractiveDiagram.tsx';
import {
  Sparkles,
  Play,
  Volume2,
  TrendingUp,
  Brain,
  CheckCircle2,
  ArrowRight,
  Layers,
  Cpu,
  RefreshCw,
  Sliders,
  Type,
  Eye,
} from 'lucide-react';

export const CompareDemoPage: React.FC = () => {
  const { speakText } = useAccessibility();

  const [loading, setLoading] = useState(false);
  const [pipelineActiveStep, setPipelineActiveStep] = useState<number>(4);
  const [demoData, setDemoData] = useState<any>(null);

  // Custom text input for live adaptation test
  const [customText, setCustomText] = useState(
    'Photosynthesis is the process through which green plants convert sunlight, carbon dioxide and water into glucose and oxygen.'
  );
  const [customTitle, setCustomTitle] = useState('Photosynthesis: How Plants Make Food');
  const [customSubject, setCustomSubject] = useState('Biology & Life Science');

  // Preset curriculum choices
  const presets = [
    {
      title: 'Photosynthesis: How Plants Make Food',
      subject: 'Biology & Life Science',
      text: 'Photosynthesis is the process through which green plants convert sunlight, carbon dioxide and water into glucose and oxygen.',
    },
    {
      title: 'The Water Cycle: Atmospheric Circulation',
      subject: 'Earth Science',
      text: 'The water cycle describes how water evaporates from the surface of the earth, rises into the atmosphere, cools and condenses into rain or snow in clouds, and falls again to the surface as precipitation.',
    },
    {
      title: "Newton's First Law: Inertia and Motion",
      subject: 'Physics',
      text: 'An object at rest remains at rest, and an object in motion continues in motion with the same velocity, unless acted upon by a net external force.',
    },
  ];

  useEffect(() => {
    async function loadInitial() {
      try {
        const res = await fetch('/api/demo/data');
        if (res.ok) {
          const data = await res.json();
          setDemoData(data);
        }
      } catch (err) {
        console.error('Failed to load demo data:', err);
      }
    }
    loadInitial();
  }, []);

  const handleRunLiveAdaptation = async () => {
    setLoading(true);

    // Animate through pipeline stages
    for (let i = 1; i <= 6; i++) {
      setPipelineActiveStep(i);
      await new Promise((r) => setTimeout(r, 220));
    }

    try {
      const res = await fetch('/api/demo/run-adaptation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: customTitle,
          subject: customSubject,
          text: customText,
        }),
      });

      if (res.ok) {
        const adaptedResult = await res.json();
        setDemoData((prev: any) => ({
          ...prev,
          originalLesson: {
            title: customTitle,
            subject: customSubject,
            content: customText,
          },
          learnerA: {
            ...prev.learnerA,
            adaptedVariant: {
              largeText: adaptedResult.learnerAView.largeText,
              audioScript: adaptedResult.learnerAView.audioScript,
              stepByStep: adaptedResult.learnerAView.stepByStep,
            },
            mastery: adaptedResult.learnerAView.simulatedMasteryAfter,
          },
          learnerB: {
            ...prev.learnerB,
            adaptedVariant: {
              simplified: adaptedResult.learnerBView.simplified,
              visual: adaptedResult.learnerBView.visual,
            },
            mastery: adaptedResult.learnerBView.simulatedMasteryAfter,
          },
        }));
      }
    } catch (err) {
      console.error('Live adaptation error:', err);
    } finally {
      setLoading(false);
    }
  };

  const learnerA = demoData?.learnerA;
  const learnerB = demoData?.learnerB;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      {/* 1. TOP HEADER & HACKATHON BADGE */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-50 dark:bg-indigo-950/80 border border-indigo-200 dark:border-indigo-800 text-xs font-bold text-[#4F46E5] dark:text-indigo-300 uppercase tracking-wider">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Flagship Hackathon Feature: Side-by-Side Live Adaptation</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
          One Lesson. Two Learners. Infinite Adaptability.
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed text-balance">
          Observe how the exact same curriculum text is transformed simultaneously for Learner A (Aarav:
          Large Text + Audio narration) and Learner B (Meera: Simplified English + Interactive Visuals)
          without altering underlying scientific meaning.
        </p>
      </div>

      {/* 2. LIVE ADAPTATION CONTROLLER & PRESET SELECTOR */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-lg space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Cpu className="w-4 h-4 text-[#1F4E79] dark:text-blue-400" />
              Adaptation Engine Live Input
            </h2>
            <span className="text-xs text-slate-500">
              Select a benchmark curriculum standard or type custom text below:
            </span>
          </div>

          <button
            disabled={loading}
            onClick={handleRunLiveAdaptation}
            className="px-6 py-3 bg-[#4F46E5] hover:bg-indigo-600 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 disabled:opacity-50 shrink-0"
          >
            {loading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Running Bayesian Pipeline...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Run Live Adaptation Engine</span>
              </>
            )}
          </button>
        </div>

        {/* Preset choices buttons */}
        <div className="flex flex-wrap gap-2 text-xs">
          <span className="self-center text-slate-400 font-semibold mr-1">Presets:</span>
          {presets.map((p) => (
            <button
              key={p.title}
              onClick={() => {
                setCustomTitle(p.title);
                setCustomSubject(p.subject);
                setCustomText(p.text);
              }}
              className={`px-3 py-1.5 rounded-xl border font-medium transition-colors ${
                customTitle === p.title
                  ? 'bg-[#1F4E79] text-white border-[#1F4E79]'
                  : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100'
              }`}
            >
              {p.title.split(':')[0]}
            </button>
          ))}
        </div>

        {/* Textarea */}
        <div>
          <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase mb-1">
            Original Curriculum Content
          </label>
          <textarea
            rows={2}
            value={customText}
            onChange={(e) => setCustomText(e.target.value)}
            className="w-full p-3 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl leading-relaxed text-slate-900 dark:text-white"
          />
        </div>
      </div>

      {/* 3. ANIMATED 6-STAGE PIPELINE */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-slate-800">
        <h3 className="text-xs font-bold uppercase tracking-wider text-blue-400 mb-6 flex items-center gap-2">
          <Layers className="w-4 h-4" />
          End-to-End Adaptive Intelligence Pipeline
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {[
            { step: 1, name: 'Original Lesson', desc: 'Curriculum text input' },
            { step: 2, name: 'Learner Profile', desc: 'Sensory preferences' },
            { step: 3, name: 'Knowledge Model', desc: 'BKT prior P(L0)' },
            { step: 4, name: 'AI Adaptation', desc: 'Gemini 3.8 Multi-Variant' },
            { step: 5, name: 'Personalized Delivery', desc: 'Audio / Visual formats' },
            { step: 6, name: 'Feedback Loop', desc: 'Bandit reward update' },
          ].map((st) => (
            <div
              key={st.step}
              className={`p-3.5 rounded-2xl border transition-all ${
                pipelineActiveStep >= st.step
                  ? 'bg-blue-950/80 border-blue-500 shadow-md ring-1 ring-blue-400/40'
                  : 'bg-slate-800/40 border-slate-800 opacity-60'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="w-5 h-5 rounded-md bg-blue-600 text-white flex items-center justify-center font-bold text-[10px]">
                  {st.step}
                </span>
                {pipelineActiveStep >= st.step && (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                )}
              </div>
              <h4 className="text-xs font-bold text-white leading-tight">{st.name}</h4>
              <p className="text-[10px] text-slate-400 mt-0.5">{st.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* 4. SIDE-BY-SIDE LEARNER EXPERIENCE COMPARISON */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        {/* ================= LEFT SIDE: LEARNER A (AARAV) ================= */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border-2 border-[#1F4E79] dark:border-blue-500 p-6 sm:p-8 shadow-xl space-y-6">
          {/* Learner A Profile Header */}
          <div className="flex items-start justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-md text-[11px] font-bold bg-blue-100 dark:bg-blue-950 text-[#1F4E79] dark:text-blue-300 uppercase">
                  Learner A
                </span>
                <span className="text-xs text-slate-400">Grade 6</span>
              </div>
              <h2 className="text-2xl font-black text-slate-900 dark:text-white mt-1">
                Aarav Sharma
              </h2>
              <div className="flex flex-wrap gap-2 text-xs text-slate-600 dark:text-slate-300 mt-1.5 font-medium">
                <span>Pace: Slow / Guided</span>
                <span>·</span>
                <span>Reading: Simple</span>
                <span>·</span>
                <span className="text-[#1F4E79] dark:text-blue-400 font-bold">
                  Format: Large Text + Audio
                </span>
              </div>
            </div>

            {/* BKT Initial & Current Mastery Indicator */}
            <div className="text-right">
              <span className="text-[11px] text-slate-400 uppercase font-semibold block">
                BKT Mastery P(L)
              </span>
              <span className="text-2xl font-black text-[#1F4E79] dark:text-blue-400 font-mono">
                {Math.round((learnerA?.mastery || 0.35) * 100)}%
              </span>
              <span className="text-[10px] text-emerald-600 font-semibold block">P(T) = 0.15</span>
            </div>
          </div>

          {/* AI Adaptation Explanation Note */}
          <div className="p-3 bg-blue-50 dark:bg-blue-950/40 rounded-xl border border-blue-200 dark:border-blue-900 text-xs text-blue-950 dark:text-blue-200 space-y-1">
            <strong>AI Adaptation Strategy for Aarav:</strong>
            <p className="text-[11px] opacity-90">
              Content is transformed into high-contrast uppercase chunks with audio narration cadence
              and linear step-by-step milestones to prevent visual fatigue.
            </p>
          </div>

          {/* Audio Lesson Player Button */}
          <div className="p-4 bg-slate-900 text-white rounded-2xl flex items-center justify-between gap-3 shadow-md">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-600/30 text-blue-300 flex items-center justify-center">
                <Volume2 className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[11px] text-blue-300 font-bold uppercase block">
                  Synchronized Audio Player
                </span>
                <span className="text-xs text-slate-200">
                  {learnerA?.adaptedVariant?.audioScript?.spokenSections?.[0]?.cue || 'Introduction'}
                </span>
              </div>
            </div>

            <button
              onClick={() =>
                speakText(
                  learnerA?.adaptedVariant?.largeText?.chunkedParagraphs?.join(' ') ||
                    'Plants make their own food using sunlight from the sky and water from soil.'
                )
              }
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Listen</span>
            </button>
          </div>

          {/* Adapted View 1: Large Readable Text Chunks */}
          <div className="space-y-3">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
              1. Chunked Large Text Presentation
            </span>
            <div className="space-y-2.5">
              {(learnerA?.adaptedVariant?.largeText?.chunkedParagraphs || [
                'PLANTS ARE NATURAL FOOD FACTORIES.',
                'THEY CATCH SUNLIGHT USING GREEN LEAVES.',
                'ROOTS DRINK WATER FROM THE SOIL.',
                'SWEET GLUCOSE SUGAR GIVES ENERGY.',
                'CLEAN OXYGEN IS GIVEN OFF TO BREATHE.',
              ]).map((chunk: string, idx: number) => (
                <div
                  key={idx}
                  className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold text-base text-slate-900 dark:text-white"
                >
                  {chunk}
                </div>
              ))}
            </div>
          </div>

          {/* Adapted View 2: Step-by-Step Breakdown */}
          <div className="space-y-3 pt-3 border-t border-slate-100 dark:border-slate-800">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
              2. Step-by-Step Linear Path
            </span>
            <div className="space-y-2 text-xs">
              {(learnerA?.adaptedVariant?.stepByStep?.steps || []).slice(0, 3).map((st: any) => (
                <div
                  key={st.stepNumber}
                  className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 flex items-start gap-2.5"
                >
                  <span className="w-5 h-5 rounded-full bg-[#1F4E79] text-white flex items-center justify-center font-bold text-[10px] shrink-0">
                    {st.stepNumber}
                  </span>
                  <div>
                    <strong className="text-slate-900 dark:text-white block font-bold">
                      {st.title}
                    </strong>
                    <span className="text-slate-600 dark:text-slate-300 text-[11px]">
                      {st.explanation}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* ================= RIGHT SIDE: LEARNER B (MEERA) ================= */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border-2 border-[#4F46E5] dark:border-indigo-500 p-6 sm:p-8 shadow-xl space-y-6">
          {/* Learner B Profile Header */}
          <div className="flex items-start justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-md text-[11px] font-bold bg-indigo-100 dark:bg-indigo-950 text-[#4F46E5] dark:text-indigo-300 uppercase">
                  Learner B
                </span>
                <span className="text-xs text-slate-400">Grade 6</span>
              </div>
              <h2 className="text-2xl font-black text-slate-900 dark:text-white mt-1">
                Meera Rao
              </h2>
              <div className="flex flex-wrap gap-2 text-xs text-slate-600 dark:text-slate-300 mt-1.5 font-medium">
                <span>Pace: Moderate</span>
                <span>·</span>
                <span>Reading: Intermediate</span>
                <span>·</span>
                <span className="text-[#4F46E5] dark:text-indigo-400 font-bold">
                  Format: Simplified + Visuals
                </span>
              </div>
            </div>

            {/* BKT Initial & Current Mastery Indicator */}
            <div className="text-right">
              <span className="text-[11px] text-slate-400 uppercase font-semibold block">
                BKT Mastery P(L)
              </span>
              <span className="text-2xl font-black text-[#4F46E5] dark:text-indigo-400 font-mono">
                {Math.round((learnerB?.mastery || 0.60) * 100)}%
              </span>
              <span className="text-[10px] text-emerald-600 font-semibold block">P(T) = 0.18</span>
            </div>
          </div>

          {/* AI Adaptation Explanation Note */}
          <div className="p-3 bg-indigo-50 dark:bg-indigo-950/40 rounded-xl border border-indigo-200 dark:border-indigo-900 text-xs text-indigo-950 dark:text-indigo-200 space-y-1">
            <strong>AI Adaptation Strategy for Meera:</strong>
            <p className="text-[11px] opacity-90">
              Content is translated into everyday English with interactive biological diagrams, concept cards,
              and inline vocabulary definitions to maximize conceptual retention.
            </p>
          </div>

          {/* Adapted View 1: Simplified Concept Cards & Vocabulary */}
          <div className="space-y-3">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
              1. Simplified Text with Vocabulary Cards
            </span>
            <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-800 dark:text-slate-200 leading-relaxed">
              {learnerB?.adaptedVariant?.simplified?.content ||
                'Plants make their own food! They catch sunshine in green leaves, drink water from the soil, and breathe carbon dioxide from the air. Together, they bake sweet plant sugar called glucose.'}
            </div>

            {/* Vocabulary Glossary Strip */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              {(
                learnerB?.adaptedVariant?.simplified?.simplifiedWords || [
                  { complex: 'Chlorophyll', simple: 'Green leaf helper' },
                  { complex: 'Glucose', simple: 'Plant sugar energy' },
                ]
              ).map((w: any, idx: number) => (
                <div
                  key={idx}
                  className="p-2.5 bg-white dark:bg-slate-800 rounded-xl border border-indigo-100 dark:border-slate-700 shadow-xs"
                >
                  <strong className="text-indigo-600 dark:text-indigo-400 block font-bold text-[11px]">
                    {w.complex}
                  </strong>
                  <span className="text-[11px] text-slate-500">means {w.simple}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Adapted View 2: Interactive Concept Diagram */}
          <div className="space-y-3 pt-3 border-t border-slate-100 dark:border-slate-800">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
              2. Interactive Visual Diagram
            </span>
            <InteractiveDiagram title="Meera's Interactive Photosynthesis Map" />
          </div>
        </div>
      </div>

      {/* 5. SUMMARY COMPARISON METRICS FOOTER */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm">
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-800 dark:text-slate-200 mb-4 flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-emerald-600" />
          Comparative Pedagogical Evaluation
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1">
            <strong className="text-slate-900 dark:text-white block font-bold">
              Cognitive Load Parity
            </strong>
            <p className="text-slate-600 dark:text-slate-300">
              Both learners achieve full understanding of inputs (Light, H₂O, CO₂) and outputs
              (Glucose, O₂) within standard working memory limits.
            </p>
          </div>

          <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1">
            <strong className="text-slate-900 dark:text-white block font-bold">
              Autonomous Agency
            </strong>
            <p className="text-slate-600 dark:text-slate-300">
              Aarav and Meera can switch between formats at any point if reading fatigue or sensory
              overload occurs.
            </p>
          </div>

          <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1">
            <strong className="text-slate-900 dark:text-white block font-bold">
              BKT Convergence
            </strong>
            <p className="text-slate-600 dark:text-slate-300">
              Bayesian modeling accounts for guess P(G) and slip P(S) rates independently for each
              learner, guaranteeing fair mastery certification.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
