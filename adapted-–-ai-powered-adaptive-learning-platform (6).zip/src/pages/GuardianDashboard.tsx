import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import {
  Shield,
  Heart,
  TrendingUp,
  Award,
  CheckCircle2,
  AlertCircle,
  MessageSquare,
  BookOpen,
} from 'lucide-react';

interface GuardianDashboardProps {
  onNavigate: (view: string) => void;
}

export const GuardianDashboard: React.FC<GuardianDashboardProps> = ({ onNavigate }) => {
  const { user, token } = useAuth();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadGuardianData() {
      try {
        const res = await fetch('/api/guardian/overview', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const resData = await res.json();
          setData(resData);
        }
      } catch (err) {
        console.error('Failed to load guardian overview:', err);
      } finally {
        setLoading(false);
      }
    }
    loadGuardianData();
  }, [token]);

  const student = data?.student || {
    name: 'Aarav Sharma',
    grade: 'Grade 6',
    progressPercent: 48,
    lessonsCompleted: 3,
    streakDays: 4,
    accuracy: 72,
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#1F4E79] to-[#2B6CB0] text-white rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex items-center gap-2 text-xs font-semibold text-blue-200 uppercase tracking-wider mb-1">
          <Shield className="w-4 h-4 text-emerald-400" />
          <span>Authorized Guardian Portal</span>
          <span>·</span>
          <span>Family Access</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
          {student.name}'s Learning Journey
        </h1>
        <p className="text-xs sm:text-sm text-blue-100 max-w-xl mt-1">
          Stay informed about Aarav’s educational growth, lesson comfort, and teacher feedback.
        </p>

        {/* Quick Stats */}
        <div className="mt-6 pt-6 border-t border-white/20 grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
          <div className="p-3 bg-white/10 rounded-2xl">
            <span className="text-[11px] text-blue-200 block">Overall Progress</span>
            <span className="text-xl font-bold">{student.progressPercent}%</span>
          </div>
          <div className="p-3 bg-white/10 rounded-2xl">
            <span className="text-[11px] text-blue-200 block">Lessons Completed</span>
            <span className="text-xl font-bold">{student.lessonsCompleted}</span>
          </div>
          <div className="p-3 bg-white/10 rounded-2xl">
            <span className="text-[11px] text-blue-200 block">Learning Streak</span>
            <span className="text-xl font-bold text-amber-300">{student.streakDays} Days</span>
          </div>
          <div className="p-3 bg-white/10 rounded-2xl">
            <span className="text-[11px] text-blue-200 block">Quiz Accuracy</span>
            <span className="text-xl font-bold text-emerald-300">{student.accuracy}%</span>
          </div>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Topic Strengths */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-4">
          <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            Topic Strengths
          </h3>
          <div className="space-y-3">
            {(data?.topicStrengths || [
              { topic: 'Photosynthesis', status: 'In Progress (48%)', note: 'Showing steady improvement with audio pacing' },
              { topic: 'Water Cycle', status: 'Mastered (55%)', note: 'Completed quiz with 4/5 on first attempt' },
            ]).map((s: any, idx: number) => (
              <div key={idx} className="p-3.5 bg-emerald-50/50 dark:bg-emerald-950/40 rounded-2xl border border-emerald-100 dark:border-emerald-900 text-xs">
                <div className="flex justify-between font-bold text-slate-900 dark:text-white">
                  <span>{s.topic}</span>
                  <span className="text-emerald-700 dark:text-emerald-400">{s.status}</span>
                </div>
                <p className="text-slate-600 dark:text-slate-300 mt-1">{s.note}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Growth Areas & Recommendations */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-4">
          <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Heart className="w-5 h-5 text-rose-500" />
            Support & Growth Areas
          </h3>
          <div className="space-y-3">
            {(data?.growthAreas || [
              { area: 'Stomata Leaf Biology', tip: 'Reviewing leaf diagram with large-font step breakdown' },
            ]).map((g: any, idx: number) => (
              <div key={idx} className="p-3.5 bg-blue-50/50 dark:bg-blue-950/40 rounded-2xl border border-blue-100 dark:border-blue-900 text-xs">
                <span className="font-bold text-slate-900 dark:text-white block">{g.area}</span>
                <p className="text-slate-600 dark:text-slate-300 mt-1">{g.tip}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Teacher Notes */}
        <div className="md:col-span-2 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-4">
          <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-[#1F4E79] dark:text-blue-400" />
            Teacher Observations & Feedback
          </h3>

          <div className="space-y-3">
            {(data?.teacherNotes || [
              {
                teacher: 'Ms. Elena Sharma',
                date: 'Yesterday',
                message:
                  'Aarav is doing great this week! The audio lessons and large-text cards have noticeably boosted his confidence during group quizzes.',
              },
            ]).map((n: any, idx: number) => (
              <div key={idx} className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 text-xs space-y-1">
                <div className="flex justify-between font-bold text-slate-900 dark:text-white">
                  <span>{n.teacher}</span>
                  <span className="text-slate-400 font-normal">{n.date}</span>
                </div>
                <p className="text-slate-700 dark:text-slate-300 leading-relaxed">{n.message}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
