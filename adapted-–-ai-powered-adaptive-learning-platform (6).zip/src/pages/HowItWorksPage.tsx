import React from 'react';
import {
  Brain,
  Sliders,
  Sparkles,
  TrendingUp,
  ShieldCheck,
  CheckCircle2,
  ArrowRight,
  BookOpen,
} from 'lucide-react';

interface HowItWorksPageProps {
  onNavigate: (view: string) => void;
}

export const HowItWorksPage: React.FC<HowItWorksPageProps> = ({ onNavigate }) => {
  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <span className="text-xs uppercase font-bold text-[#1F4E79] dark:text-blue-400 tracking-wider">
          Scientific Architecture
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
          How AdaptEd's AI Engine Operates
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed text-balance">
          We combine Bayesian Knowledge Tracing (BKT), Contextual Multi-Armed Bandits, and modern LLM
          multi-variant adaptation to build an equitable, personalized learning environment.
        </p>
      </div>

      {/* 1. BAYESIAN KNOWLEDGE TRACING */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 shadow-sm space-y-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-blue-50 dark:bg-blue-950 text-[#1F4E79] dark:text-blue-400 flex items-center justify-center font-bold">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">
              1. Bayesian Knowledge Tracing (BKT) Model
            </h2>
            <span className="text-xs text-slate-400">Probabilistic cognitive mastery tracking</span>
          </div>
        </div>

        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
          Standard testing assumes an incorrect answer implies zero knowledge, or a correct answer proves
          complete comprehension. BKT separates lucky guesses from true understanding using four parameters:
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
          <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700">
            <span className="font-mono font-bold text-[#1F4E79] dark:text-blue-400 text-sm block">
              P(L₀)
            </span>
            <strong className="text-slate-900 dark:text-white block mt-1">Initial Knowledge</strong>
            <p className="text-slate-500 mt-0.5 text-[11px]">
              Baseline probability that the student already understands the topic before practice.
            </p>
          </div>

          <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700">
            <span className="font-mono font-bold text-emerald-600 text-sm block">P(T)</span>
            <strong className="text-slate-900 dark:text-white block mt-1">Learning Transition</strong>
            <p className="text-slate-500 mt-0.5 text-[11px]">
              Probability the student masters the concept as a direct result of each opportunity.
            </p>
          </div>

          <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700">
            <span className="font-mono font-bold text-amber-600 text-sm block">P(G)</span>
            <strong className="text-slate-900 dark:text-white block mt-1">Guess Probability</strong>
            <p className="text-slate-500 mt-0.5 text-[11px]">
              Probability of answering correctly despite not yet possessing latent mastery.
            </p>
          </div>

          <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700">
            <span className="font-mono font-bold text-rose-600 text-sm block">P(S)</span>
            <strong className="text-slate-900 dark:text-white block mt-1">Slip Probability</strong>
            <p className="text-slate-500 mt-0.5 text-[11px]">
              Probability of making an unintended mistake despite possessing true mastery.
            </p>
          </div>
        </div>

        <div className="p-4 bg-blue-50/60 dark:bg-blue-950/40 rounded-2xl border border-blue-200 dark:border-blue-900 text-xs text-blue-900 dark:text-blue-200 font-mono">
          P(L_t | Correct) = [P(L_prev) · (1 - P(S))] / [P(L_prev) · (1 - P(S)) + (1 - P(L_prev)) · P(G)]
        </div>
      </div>

      {/* 2. CONTEXTUAL MULTI-ARMED BANDIT */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 shadow-sm space-y-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-indigo-50 dark:bg-indigo-950 text-[#4F46E5] dark:text-indigo-400 flex items-center justify-center font-bold">
            <Brain className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">
              2. Contextual Multi-Armed Bandit Format Recommendation
            </h2>
            <span className="text-xs text-slate-400">
              Balancing exploration & exploitation with learner autonomy constraints
            </span>
          </div>
        </div>

        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
          The engine treats each format pairing (e.g. <em>Large Text + Medium</em>, <em>Simplified + Easy</em>,{' '}
          <em>Audio + Easy</em>) as an arm in a bandit problem. However, explicit learner accessibility
          preferences strictly override AI optimization, ensuring student agency is never subverted.
        </p>

        <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 text-xs space-y-2">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <strong className="text-slate-900 dark:text-white">Autonomy Constraint:</strong>
            <span className="text-slate-600 dark:text-slate-300">
              If a student chooses "Large Text" or "Dyslexia Font", that preference is mandatory.
            </span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <strong className="text-slate-900 dark:text-white">Reward Signal:</strong>
            <span className="text-slate-600 dark:text-slate-300">
              Derived from quiz accuracy, completion rate, and "Was this lesson comfortable?" ratings.
            </span>
          </div>
        </div>
      </div>

      {/* Action CTA */}
      <div className="p-8 bg-[#1F4E79] text-white rounded-3xl text-center space-y-4 shadow-xl">
        <h3 className="text-2xl font-bold">Experience the System in Action</h3>
        <p className="text-xs sm:text-sm text-blue-100 max-w-xl mx-auto">
          Explore the live side-by-side comparison demo showing Aarav and Meera receiving their tailored
          lessons.
        </p>
        <button
          onClick={() => onNavigate('demo')}
          className="px-8 py-3 bg-white text-[#1F4E79] hover:bg-slate-100 text-xs font-bold rounded-xl shadow-md transition-colors inline-flex items-center gap-2"
        >
          <Sparkles className="w-4 h-4 text-[#4F46E5]" />
          <span>Launch Live Comparison Demo</span>
        </button>
      </div>
    </div>
  );
};
