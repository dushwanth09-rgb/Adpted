import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { useAccessibility } from '../context/AccessibilityContext.tsx';
import {
  Sparkles,
  ArrowRight,
  BookOpen,
  Volume2,
  Eye,
  Brain,
  Sliders,
  CheckCircle,
  Users,
  ShieldCheck,
  Zap,
  TrendingUp,
  Award,
} from 'lucide-react';

interface LandingPageProps {
  onNavigate: (view: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const { speakText } = useAccessibility();
  const [activeFormatPreview, setActiveFormatPreview] = useState<'large' | 'simple' | 'audio'>('large');

  return (
    <div className="min-h-screen bg-[#F7F9FC] dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors">
      {/* 1. HERO SECTION */}
      <section className="relative pt-12 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto overflow-hidden">
        <div className="text-center max-w-3xl mx-auto">
          {/* Official Brand Logo Badge */}
          <div className="flex justify-center mb-6">
            <img
              src="/assets/aistudio/image_7f43828e.png"
              alt="AdaptEd - Learn • Adapt • Achieve"
              className="h-24 sm:h-28 w-auto object-contain bg-white rounded-2xl p-2 shadow-md border border-slate-200/80 dark:border-slate-800"
            />
          </div>

          {/* Unboxed Metadata Kicker */}
          <div className="flex items-center justify-center gap-2 text-xs font-semibold text-[#1F4E79] dark:text-blue-400 mb-4 tracking-wide uppercase">
            <span>Adaptive AI EdTech</span>
            <span aria-hidden="true">·</span>
            <span>WCAG 2.1 AA Compliant</span>
            <span aria-hidden="true">·</span>
            <span>Project HI-03</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 dark:text-white text-balance leading-tight">
            Learning Without Limits. <br className="hidden sm:inline" />
            <span className="text-[#1F4E79] dark:text-blue-400">Education for Everyone.</span>
          </h1>

          <p className="mt-6 text-lg sm:text-xl text-slate-600 dark:text-slate-300 leading-relaxed text-balance">
            An intelligent learning platform that understands every learner and adapts lessons to their
            individual needs, sensory preferences, and knowledge mastery in real time.
          </p>

          {/* Action CTAs */}
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={() => onNavigate(user ? 'student_dashboard' : 'auth')}
              className="w-full sm:w-auto px-7 py-3.5 text-base font-semibold text-white bg-[#1F4E79] hover:bg-[#163a5c] rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
            >
              <span>Start Learning</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => onNavigate('demo')}
              className="w-full sm:w-auto px-7 py-3.5 text-base font-semibold text-slate-800 dark:text-slate-100 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 rounded-xl border border-slate-300 dark:border-slate-700 shadow-xs transition-all flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-[#4F46E5] dark:text-indigo-400" />
              <span>Explore Live Demo</span>
            </button>
          </div>

          {/* Demo Login Fast-Track */}
          <div className="mt-6 flex flex-wrap items-center justify-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            <span>Fast test credentials:</span>
            <button
              onClick={() => onNavigate('auth')}
              className="underline hover:text-[#1F4E79] dark:hover:text-blue-400"
            >
              student.a@adapted.demo
            </button>
            <span aria-hidden="true">·</span>
            <button
              onClick={() => onNavigate('auth')}
              className="underline hover:text-[#1F4E79] dark:hover:text-blue-400"
            >
              teacher@adapted.demo
            </button>
            <span aria-hidden="true">·</span>
            <span>Password: <strong>adapted123</strong></span>
          </div>
        </div>

        {/* 2. ONE LESSON → MULTIPLE LEARNING EXPERIENCES */}
        <div className="mt-16 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl p-6 sm:p-10">
          <div className="text-center max-w-2xl mx-auto mb-8">
            <span className="text-xs uppercase font-bold tracking-wider text-[#1F4E79] dark:text-blue-400">
              One Lesson → Multiple Learning Experiences
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white mt-1">
              Same factual meaning, personalized format.
            </h2>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
              Original curriculum: <em>"Photosynthesis is the process through which green plants convert sunlight, carbon dioxide and water into glucose and oxygen."</em>
            </p>

            {/* Format Selector Pills/Buttons */}
            <div className="mt-5 inline-flex p-1 bg-slate-100 dark:bg-slate-800 rounded-xl gap-1">
              <button
                onClick={() => setActiveFormatPreview('large')}
                className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all ${
                  activeFormatPreview === 'large'
                    ? 'bg-white dark:bg-slate-700 text-[#1F4E79] dark:text-blue-300 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                1. Large Text Learning
              </button>
              <button
                onClick={() => setActiveFormatPreview('simple')}
                className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all ${
                  activeFormatPreview === 'simple'
                    ? 'bg-white dark:bg-slate-700 text-[#1F4E79] dark:text-blue-300 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                2. Simplified English
              </button>
              <button
                onClick={() => setActiveFormatPreview('audio')}
                className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all ${
                  activeFormatPreview === 'audio'
                    ? 'bg-white dark:bg-slate-700 text-[#1F4E79] dark:text-blue-300 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                3. Audio-Based Learning
              </button>
            </div>
          </div>

          {/* Three Interactive Cards Container */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Card 1: Large Text */}
            <div
              className={`p-6 rounded-2xl border transition-all flex flex-col justify-between h-full ${
                activeFormatPreview === 'large'
                  ? 'border-[#1F4E79] dark:border-blue-500 ring-2 ring-[#1F4E79]/20 bg-blue-50/30 dark:bg-slate-800/80 shadow-md'
                  : 'border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30'
              }`}
            >
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 rounded-lg bg-blue-100 dark:bg-blue-900/50 text-[#1F4E79] dark:text-blue-300 flex items-center justify-center font-bold text-sm">
                  Aa
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Large Text Learning
                  </h3>
                  <span className="text-[11px] text-slate-500">For low vision & focus</span>
                </div>
              </div>
              <div className="text-base font-bold text-slate-800 dark:text-slate-100 space-y-2 leading-relaxed">
                <p>1. PLANTS CATCH SUNLIGHT WITH GREEN LEAVES.</p>
                <p>2. ROOTS DRINK WATER FROM SOIL.</p>
                <p>3. SWEET GLUCOSE FOOD IS CREATED.</p>
                <p>4. FRESH OXYGEN IS RELEASED TO BREATHE.</p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-700 text-xs text-slate-500 flex items-center justify-between">
                <span>Reading ease: +40%</span>
                <span className="text-emerald-600 dark:text-emerald-400 font-semibold">18px Crisp</span>
              </div>
            </div>

            {/* Card 2: Simplified Learning */}
            <div
              className={`p-6 rounded-2xl border transition-all flex flex-col justify-between h-full ${
                activeFormatPreview === 'simple'
                  ? 'border-[#4F46E5] dark:border-indigo-500 ring-2 ring-[#4F46E5]/20 bg-indigo-50/30 dark:bg-slate-800/80 shadow-md'
                  : 'border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30'
              }`}
            >
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 rounded-lg bg-indigo-100 dark:bg-indigo-900/50 text-[#4F46E5] dark:text-indigo-300 flex items-center justify-center font-bold text-sm">
                  <Brain className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Simplified English
                  </h3>
                  <span className="text-[11px] text-slate-500">Direct sentences & vocabulary</span>
                </div>
              </div>
              <div className="text-sm text-slate-700 dark:text-slate-200 space-y-2 leading-normal">
                <p>
                  Green leaves work like a sunny kitchen. They mix water from the dirt and air from the sky.
                </p>
                <div className="p-2.5 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 text-xs">
                  <strong className="text-indigo-600 dark:text-indigo-400">Glucose:</strong> Natural plant sugar that provides energy.
                </div>
                <p>
                  When plants make their sugar, they blow out clean oxygen for humans to breathe.
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-700 text-xs text-slate-500 flex items-center justify-between">
                <span>Cognitive load: -35%</span>
                <span className="text-indigo-600 dark:text-indigo-400 font-semibold">Active Voice</span>
              </div>
            </div>

            {/* Card 3: Audio Learning */}
            <div
              className={`p-6 rounded-2xl border transition-all flex flex-col justify-between h-full ${
                activeFormatPreview === 'audio'
                  ? 'border-emerald-600 dark:border-emerald-500 ring-2 ring-emerald-600/20 bg-emerald-50/30 dark:bg-slate-800/80 shadow-md'
                  : 'border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30'
              }`}
            >
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-900/50 text-emerald-700 dark:text-emerald-300 flex items-center justify-center font-bold text-sm">
                  <Volume2 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Audio-Based Learning
                  </h3>
                  <span className="text-[11px] text-slate-500">Narration, speech pace & captions</span>
                </div>
              </div>
              <div className="text-xs text-slate-700 dark:text-slate-300 space-y-2">
                <div className="p-3 bg-slate-900 text-white rounded-xl">
                  <span className="text-[11px] text-emerald-400 block font-semibold">
                    Live Audio Script:
                  </span>
                  <p className="mt-1 italic text-xs leading-relaxed">
                    "Have you ever wondered how trees feed themselves without moving? Listen closely: leaves absorb sunlight and release pure air..."
                  </p>
                </div>
                <button
                  onClick={() =>
                    speakText(
                      'Have you ever wondered how trees feed themselves without moving? Leaves absorb sunlight and release pure air.'
                    )
                  }
                  className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-semibold text-xs transition-colors flex items-center justify-center gap-1.5"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                  Listen Sample Narration
                </button>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-700 text-xs text-slate-500 flex items-center justify-between">
                <span>Auditory Retention: +28%</span>
                <span className="text-emerald-600 dark:text-emerald-400 font-semibold">0.9x Paced</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. OUR MISSION & PHILOSOPHY */}
      <section className="py-16 bg-white dark:bg-slate-900 border-y border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <span className="text-xs uppercase font-bold tracking-wider text-[#1F4E79] dark:text-blue-400">
                Our Educational Philosophy
              </span>
              <h2 className="text-3xl font-extrabold text-slate-900 dark:text-white mt-2 leading-tight">
                No Two Learners Are Identical. <br />
                We Never Stereotype Disabilities.
              </h2>
              <p className="mt-4 text-base text-slate-600 dark:text-slate-300 leading-relaxed">
                Traditional educational software labels a student under a rigid category and locks them
                into a one-size-fits-all accommodation. AdaptEd challenges this paradigm:
              </p>

              <div className="mt-6 space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-600 flex items-center justify-center shrink-0 mt-0.5">
                    <CheckCircle className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                      Learner-Driven Preferences Over Labels
                    </h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      Students choose the text size, spacing, audio narration, and visual aids they
                      actually need, with full autonomy to change formats anytime.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-600 flex items-center justify-center shrink-0 mt-0.5">
                    <CheckCircle className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                      Dynamic Knowledge Tracing (BKT)
                    </h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      Bayesian Knowledge Tracing continuously observes responses to separate lucky
                      guesses and slip errors from genuine topic mastery.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-600 flex items-center justify-center shrink-0 mt-0.5">
                    <CheckCircle className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                      Preserved Curricular Integrity
                    </h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      Simplifying does not mean dumbing down. Scientific facts, definitions, and
                      educational standards remain intact across all formats.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right: Architecture Visual Diagram */}
            <div className="bg-slate-50 dark:bg-slate-800/60 p-8 rounded-3xl border border-slate-200 dark:border-slate-700">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-4 flex items-center gap-2">
                <Zap className="w-4 h-4 text-amber-500" />
                Adaptive Learning Feedback Loop
              </h3>

              <div className="space-y-3">
                {[
                  { step: '01', title: 'Sensory Profile', desc: 'Font size, dyslexia typeface, contrast, audio toggles' },
                  { step: '02', title: 'BKT Knowledge Model', desc: 'Tracks P(Mastery) after every single quiz interaction' },
                  { step: '03', title: 'Contextual Bandit Engine', desc: 'Selects optimal format arm (Standard, Audio, Visual, Simplified)' },
                  { step: '04', title: 'Multi-Variant AI Adapter', desc: 'Gemini 3.8 Flash transforms text into 8 accessible representations' },
                  { step: '05', title: 'Feedback Reinforcement', desc: 'Student comfort rating updates reward weights in real-time' },
                ].map((item) => (
                  <div
                    key={item.step}
                    className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 flex items-start gap-3 shadow-xs"
                  >
                    <span className="text-xs font-mono font-bold text-[#1F4E79] dark:text-blue-400">
                      {item.step}
                    </span>
                    <div>
                      <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                        {item.title}
                      </h4>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. KEY PLATFORM FEATURES */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-xs uppercase font-bold tracking-wider text-[#1F4E79] dark:text-blue-400">
            Intelligent Capabilities
          </span>
          <h2 className="text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
            Engineered for Accessibility, Built on Real Science
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
            Every feature is designed to reduce cognitive friction and empower autonomous learning.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Feature 1 */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950 text-[#1F4E79] dark:text-blue-400 flex items-center justify-center mb-4">
              <Sliders className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Instant Format Switching
            </h3>
            <p className="mt-2 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Switch on the fly between Large Text, Simplified English, Audio narration, Step-by-Step
              cards, and Interactive diagrams whenever fatigue sets in.
            </p>
          </div>

          {/* Feature 2 */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950 text-[#4F46E5] dark:text-indigo-400 flex items-center justify-center mb-4">
              <TrendingUp className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Bayesian Knowledge Tracing
            </h3>
            <p className="mt-2 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Calculates statistical probability of mastery using slip and guess probabilities,
              calibrating next lessons to the learner’s actual developmental frontier.
            </p>
          </div>

          {/* Feature 3 */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-4">
              <Volume2 className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Bimodal Audio & Voice Input
            </h3>
            <p className="mt-2 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Web Speech API provides synchronized speech narration and allows learners to submit
              quiz responses via speech recognition without stress.
            </p>
          </div>

          {/* Feature 4 */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950 text-amber-600 dark:text-amber-400 flex items-center justify-center mb-4">
              <Users className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Pedagogical Teacher Console
            </h3>
            <p className="mt-2 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Educators monitor class-wide BKT mastery, receive proactive alerts for struggling students,
              and upload curriculum for instant AI adaptation.
            </p>
          </div>

          {/* Feature 5 */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-10 h-10 rounded-xl bg-rose-50 dark:bg-rose-950 text-rose-600 dark:text-rose-400 flex items-center justify-center mb-4">
              <Eye className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Global Accessibility Toolbar
            </h3>
            <p className="mt-2 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Lexend dyslexia typeface, text size scaling up to XL, high contrast ratio, loose line
              spacing, and reduced motion toggles available on every view.
            </p>
          </div>

          {/* Feature 6 */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-10 h-10 rounded-xl bg-purple-50 dark:bg-purple-950 text-purple-600 dark:text-purple-400 flex items-center justify-center mb-4">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Privacy-First & Non-Intrusive
            </h3>
            <p className="mt-2 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              We never collect sensitive medical or diagnostic records. Learners configure sensory
              preferences directly with secure role-based isolation.
            </p>
          </div>
        </div>
      </section>

      {/* 5. DEDICATED CALL TO ACTION */}
      <section className="py-16 bg-[#1F4E79] text-white">
        <div className="max-w-5xl mx-auto px-4 text-center">
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
            Witness the Power of Side-by-Side Adaptation
          </h2>
          <p className="mt-4 text-base text-blue-100 max-w-2xl mx-auto">
            Experience our Hackathon flagship demonstration: See how Aarav and Meera learn the exact
            same photosynthesis lesson through two radically personalized formats.
          </p>

          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={() => onNavigate('demo')}
              className="w-full sm:w-auto px-8 py-3.5 bg-white text-[#1F4E79] hover:bg-slate-100 font-bold rounded-xl shadow-lg transition-colors flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-[#4F46E5]" />
              <span>Launch Live Comparison Demo</span>
            </button>
            <button
              onClick={() => onNavigate('auth')}
              className="w-full sm:w-auto px-8 py-3.5 bg-[#163a5c] text-white hover:bg-[#122e49] font-bold rounded-xl border border-blue-400/30 transition-colors"
            >
              Sign In With Demo Accounts
            </button>
          </div>
        </div>
      </section>

      {/* 6. ACCESSIBLE FOOTER */}
      <footer className="bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 py-10 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 dark:text-slate-400">
          <div className="flex items-center gap-3">
            <img
              src="/assets/aistudio/image_7f43828e.png"
              alt="AdaptEd Logo"
              className="h-8 w-auto object-contain bg-white rounded-md p-0.5 shadow-2xs"
            />
            <span className="font-bold text-[#1F4E79] dark:text-blue-400 text-sm">AdaptEd</span>
            <span>·</span>
            <span>Project HI-03: Adaptive Learning for Students with Disabilities</span>
          </div>

          <div className="flex items-center gap-6">
            <button onClick={() => onNavigate('demo')} className="hover:text-slate-900 dark:hover:text-white">
              Live Compare Demo
            </button>
            <button onClick={() => onNavigate('lessons')} className="hover:text-slate-900 dark:hover:text-white">
              Sample Lessons
            </button>
            <button onClick={() => onNavigate('auth')} className="hover:text-slate-900 dark:hover:text-white">
              Demo Credentials
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
};
