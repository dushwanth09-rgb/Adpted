import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { useAccessibility } from '../context/AccessibilityContext.tsx';
import { AudioPlayerBar } from '../components/AudioPlayerBar.tsx';
import { InteractiveDiagram } from '../components/InteractiveDiagram.tsx';
import { saveAttemptToFirestore, saveMasteryToFirestore } from '../firebase/firestoreService.ts';
import {
  BookOpen,
  ArrowLeft,
  ArrowRight,
  Sliders,
  Sparkles,
  Volume2,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  ThumbsUp,
  MessageSquare,
  RefreshCw,
  Eye,
  Type,
} from 'lucide-react';

interface LessonPlayerProps {
  lessonId?: string;
  onNavigate: (view: string, payload?: any) => void;
  onOpenAccessibility: () => void;
}

export const LessonPlayer: React.FC<LessonPlayerProps> = ({
  lessonId = 'lesson_photosynthesis',
  onNavigate,
  onOpenAccessibility,
}) => {
  const { user, profile, token } = useAuth();
  const {
    textSize,
    setTextSize,
    dyslexiaFont,
    toggleDyslexiaFont,
    highContrast,
    toggleHighContrast,
    spacedReading,
    toggleSpacedReading,
    speakText,
  } = useAccessibility();

  const [lesson, setLesson] = useState<any>(null);
  const [activeFormat, setActiveFormat] = useState<string>(
    profile?.preferences.primaryFormat || 'large_text'
  );
  const [currentSectionIndex, setCurrentSectionIndex] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(true);

  // Ask AI helper modal
  const [showAskAi, setShowAskAi] = useState<boolean>(false);
  const [aiConceptInput, setAiConceptInput] = useState<string>('Stomata');
  const [aiExplanation, setAiExplanation] = useState<string | null>(null);
  const [aiLoading, setAiLoading] = useState<boolean>(false);

  // Lesson Feedback
  const [feedbackSent, setFeedbackSent] = useState<boolean>(false);
  const [selectedRating, setSelectedRating] = useState<string | null>(null);

  // Mini quiz state
  const [activeQuestionIndex, setActiveQuestionIndex] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [quizResult, setQuizResult] = useState<any | null>(null);
  const [submittingQuiz, setSubmittingQuiz] = useState<boolean>(false);

  useEffect(() => {
    async function fetchLesson() {
      try {
        const res = await fetch(`/api/lessons/${lessonId}`);
        if (res.ok) {
          const data = await res.json();
          setLesson(data);
        }
      } catch (err) {
        console.error('Failed to load lesson:', err);
      } finally {
        setLoading(false);
      }
    }
    fetchLesson();
  }, [lessonId]);

  if (loading || !lesson) {
    return (
      <div className="max-w-4xl mx-auto py-20 px-4 text-center">
        <RefreshCw className="w-8 h-8 text-[#1F4E79] animate-spin mx-auto mb-3" />
        <h3 className="text-base font-bold text-slate-800 dark:text-slate-200">
          Loading Adaptive Lesson...
        </h3>
      </div>
    );
  }

  const variants = lesson.adaptation?.variants || {};
  const standardSections = variants.standard?.sections || [];
  const currentSection = standardSections[currentSectionIndex] || {
    title: lesson.title,
    body: lesson.content,
  };

  const currentTextForAudio =
    activeFormat === 'audio'
      ? variants.audioScript?.intro + ' ' + (variants.audioScript?.spokenSections?.[0]?.text || '')
      : activeFormat === 'simplified'
      ? variants.simplified?.content
      : activeFormat === 'large_text'
      ? variants.largeText?.content
      : currentSection.body;

  // Ask AI Concept handler
  const handleAskAi = async () => {
    if (!aiConceptInput.trim()) return;
    setAiLoading(true);
    setAiExplanation(null);
    try {
      const res = await fetch('/api/ai/explain', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ concept: aiConceptInput, context: lesson.title }),
      });
      if (res.ok) {
        const data = await res.json();
        setAiExplanation(data.simpleExplanation);
      }
    } catch (err) {
      console.error('AI Explain error:', err);
    } finally {
      setAiLoading(false);
    }
  };

  // Submit Feedback
  const handleFeedback = async (rating: string) => {
    setSelectedRating(rating);
    try {
      await fetch(`/api/lessons/${lesson.id}/feedback`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          rating,
          formatUsed: activeFormat,
        }),
      });
      setFeedbackSent(true);
    } catch (err) {
      console.error('Failed to record feedback:', err);
    }
  };

  // Submit Quiz Question Answer
  const handleAnswerSubmit = async () => {
    if (selectedOption === null) return;
    setSubmittingQuiz(true);
    const questions = lesson.adaptation?.quizQuestions || [];
    const question = questions[activeQuestionIndex];

    try {
      const res = await fetch('/api/quiz/answer', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          lessonId: lesson.id,
          questionId: question.id,
          selectedOption,
          topic: lesson.topic,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setQuizResult(data);

        // Sync to Cloud Firestore
        if (user) {
          saveAttemptToFirestore({
            id: `att_${Date.now()}`,
            studentId: user.id,
            lessonId: lesson.id,
            questionId: question.id,
            questionText: question.question,
            selectedOption,
            isCorrect: data.isCorrect,
            timestamp: new Date().toISOString(),
            pMasteryBefore: data.bkt.pMasteryBefore,
            pMasteryAfter: data.bkt.pMasteryAfter,
          }).catch((err) => console.warn('Firestore attempt sync note:', err));

          saveMasteryToFirestore(user.id, lesson.topic, {
            studentId: user.id,
            topic: lesson.topic,
            pMastery: data.bkt.pMasteryAfter,
            lastUpdated: new Date().toISOString(),
          }).catch((err) => console.warn('Firestore mastery sync note:', err));
        }
      }
    } catch (err) {
      console.error('Failed to submit answer:', err);
    } finally {
      setSubmittingQuiz(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* 1. TOP NAV & QUICK FORMAT CONTROLS */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800 gap-4">
        <button
          onClick={() => onNavigate('student_dashboard')}
          className="flex items-center gap-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-[#1F4E79] dark:hover:text-blue-400 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Dashboard</span>
        </button>

        {/* Fast Sensory Quick Toggles */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs gap-1">
            <button
              onClick={() => setTextSize('md')}
              className={`px-2.5 py-1 rounded-lg font-medium transition-all ${
                textSize === 'md' ? 'bg-white dark:bg-slate-700 font-bold shadow-xs' : 'text-slate-500'
              }`}
            >
              16px
            </button>
            <button
              onClick={() => setTextSize('lg')}
              className={`px-2.5 py-1 rounded-lg font-medium transition-all ${
                textSize === 'lg' ? 'bg-white dark:bg-slate-700 font-bold shadow-xs' : 'text-slate-500'
              }`}
            >
              18px
            </button>
            <button
              onClick={() => setTextSize('xl')}
              className={`px-2.5 py-1 rounded-lg font-medium transition-all ${
                textSize === 'xl' ? 'bg-white dark:bg-slate-700 font-bold shadow-xs' : 'text-slate-500'
              }`}
            >
              20px
            </button>
          </div>

          <button
            onClick={toggleDyslexiaFont}
            className={`px-2.5 py-1.5 text-xs font-semibold rounded-xl border transition-all ${
              dyslexiaFont
                ? 'bg-emerald-50 text-emerald-700 border-emerald-300 dark:bg-emerald-950/60 dark:text-emerald-300'
                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700'
            }`}
          >
            Dyslexia Font
          </button>

          <button
            onClick={toggleSpacedReading}
            className={`px-2.5 py-1.5 text-xs font-semibold rounded-xl border transition-all ${
              spacedReading
                ? 'bg-blue-50 text-blue-700 border-blue-300 dark:bg-blue-950/60 dark:text-blue-300'
                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700'
            }`}
          >
            Spaced Lines
          </button>

          <button
            onClick={onOpenAccessibility}
            className="p-1.5 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-slate-900 rounded-xl"
            title="All Accessibility Options"
          >
            <Sliders className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 2. LESSON HEADER & FORMAT SWITCHER */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-[#1F4E79] dark:text-blue-400 uppercase tracking-wider">
              <span>{lesson.subject}</span>
              <span>·</span>
              <span>{lesson.gradeLevel}</span>
              <span>·</span>
              <span>{lesson.durationMinutes} min lesson</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
              {lesson.title}
            </h1>
          </div>

          {/* Ask AI helper button */}
          <button
            onClick={() => setShowAskAi(true)}
            className="px-3.5 py-2 bg-indigo-50 dark:bg-indigo-950/60 text-[#4F46E5] dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 rounded-xl text-xs font-bold hover:bg-indigo-100 transition-colors flex items-center gap-1.5 shrink-0"
          >
            <Sparkles className="w-4 h-4" />
            <span>Ask AI to Explain</span>
          </button>
        </div>

        {/* FORMAT SWITCHER TABS - CRITICAL ADAPTIVE FUNCTIONALITY */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
          <span className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">
            Switch Presentation Format (Choose what feels best):
          </span>
          <div className="flex flex-wrap gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
            {[
              { id: 'large_text', label: 'Large Text (Chunked)' },
              { id: 'simplified', label: 'Simplified English' },
              { id: 'step_by_step', label: 'Step-by-Step' },
              { id: 'visual', label: 'Visual Diagram' },
              { id: 'audio', label: 'Audio Narration Script' },
              { id: 'standard', label: 'Standard Text' },
            ].map((fmt) => (
              <button
                key={fmt.id}
                onClick={() => setActiveFormat(fmt.id)}
                className={`px-3.5 py-2 text-xs rounded-lg font-semibold transition-all ${
                  activeFormat === fmt.id
                    ? 'bg-[#1F4E79] text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                {fmt.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 3. PERSISTENT AUDIO NARRATOR BAR */}
      <AudioPlayerBar
        title={`${lesson.title} (${activeFormat.replace('_', ' ')})`}
        textToSpeak={currentTextForAudio}
      />

      {/* 4. ADAPTIVE CONTENT DISPLAY STAGE */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 shadow-sm">
        {/* VARIANT A: LARGE TEXT */}
        {activeFormat === 'large_text' && (
          <div className="space-y-6">
            <div className="p-3 bg-blue-50/60 dark:bg-blue-950/40 rounded-xl border border-blue-100 dark:border-blue-900 text-xs text-[#1F4E79] dark:text-blue-300 font-semibold flex items-center gap-2">
              <Type className="w-4 h-4" />
              <span>Large Text Format: Designed with clear high-legibility sentences and chunked concepts.</span>
            </div>

            <div className="space-y-6 text-lg sm:text-xl font-bold text-slate-800 dark:text-slate-100 leading-relaxed">
              {(variants.largeText?.chunkedParagraphs || [lesson.content]).map((chunk: string, idx: number) => (
                <div
                  key={idx}
                  className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex items-start gap-4"
                >
                  <span className="w-8 h-8 rounded-full bg-[#1F4E79] text-white flex items-center justify-center font-bold text-sm shrink-0">
                    {idx + 1}
                  </span>
                  <p className="pt-0.5">{chunk}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* VARIANT B: SIMPLIFIED ENGLISH */}
        {activeFormat === 'simplified' && (
          <div className="space-y-6">
            <div className="p-3 bg-indigo-50/60 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-900 text-xs text-indigo-700 dark:text-indigo-300 font-semibold flex items-center gap-2">
              <Sparkles className="w-4 h-4" />
              <span>Simplified English: Active voice, everyday vocabulary, and contextual definition cards.</span>
            </div>

            {/* Simplified Words Vocabulary Glossary Deck */}
            {variants.simplified?.simplifiedWords && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
                {variants.simplified.simplifiedWords.map((w: any, idx: number) => (
                  <div
                    key={idx}
                    className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-indigo-200 dark:border-slate-700 shadow-xs text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-indigo-700 dark:text-indigo-400">
                        {w.complex}
                      </span>
                      <span className="text-[11px] text-slate-500">→ means "{w.simple}"</span>
                    </div>
                    <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-1">
                      {w.definition}
                    </p>
                  </div>
                ))}
              </div>
            )}

            <div className="space-y-4">
              {(variants.simplified?.sections || [
                { title: 'Overview', body: variants.simplified?.content || lesson.content },
              ]).map((sec: any, idx: number) => (
                <div
                  key={idx}
                  className="p-5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2"
                >
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    {sec.title}
                  </h3>
                  <p className="text-sm sm:text-base text-slate-700 dark:text-slate-200 leading-relaxed">
                    {sec.body}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* VARIANT C: STEP-BY-STEP */}
        {activeFormat === 'step_by_step' && (
          <div className="space-y-6">
            <div className="p-3 bg-emerald-50/60 dark:bg-emerald-950/40 rounded-xl border border-emerald-100 dark:border-emerald-900 text-xs text-emerald-700 dark:text-emerald-300 font-semibold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              <span>Step-by-Step Breakdown: Linear stages with action tips.</span>
            </div>

            <div className="space-y-4">
              {(variants.stepByStep?.steps || []).map((stepItem: any) => (
                <div
                  key={stepItem.stepNumber}
                  className="p-5 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xs space-y-2"
                >
                  <div className="flex items-center gap-3">
                    <span className="w-7 h-7 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-xs">
                      {stepItem.stepNumber}
                    </span>
                    <h3 className="text-base font-bold text-slate-900 dark:text-white">
                      {stepItem.title}
                    </h3>
                  </div>
                  <p className="text-sm text-slate-700 dark:text-slate-300 pl-10 leading-relaxed">
                    {stepItem.explanation}
                  </p>
                  {stepItem.actionTip && (
                    <div className="ml-10 p-2.5 bg-amber-50 dark:bg-amber-950/40 rounded-xl border border-amber-200 dark:border-amber-900 text-xs text-amber-800 dark:text-amber-200">
                      💡 <strong>Tip:</strong> {stepItem.actionTip}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* VARIANT D: VISUAL DIAGRAM */}
        {activeFormat === 'visual' && (
          <div className="space-y-6">
            <InteractiveDiagram title={variants.visual?.diagramTitle || 'Interactive Cellular Diagram'} />

            {/* Visual Flow Checklist */}
            <div className="p-5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-3">
                Diagram Process Sequence:
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {(variants.visual?.flowDescription || []).map((stepText: string, idx: number) => (
                  <div
                    key={idx}
                    className="p-2.5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center gap-2"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span className="text-slate-700 dark:text-slate-200">{stepText}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* VARIANT E: AUDIO SCRIPT */}
        {activeFormat === 'audio' && (
          <div className="space-y-6">
            <div className="p-4 bg-slate-900 text-white rounded-2xl border border-slate-800 space-y-3">
              <span className="text-xs text-emerald-400 font-bold uppercase tracking-wider block">
                Auditory Master Script:
              </span>
              <p className="text-sm leading-relaxed italic text-slate-200">
                "{variants.audioScript?.intro}"
              </p>
            </div>

            <div className="space-y-4">
              {(variants.audioScript?.spokenSections || []).map((sec: any, idx: number) => (
                <div
                  key={idx}
                  className="p-5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1.5"
                >
                  <span className="text-xs font-bold text-[#1F4E79] dark:text-blue-400">
                    Audio Cue: {sec.cue}
                  </span>
                  <p className="text-sm text-slate-800 dark:text-slate-200 leading-relaxed">
                    {sec.text}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* VARIANT F: STANDARD TEXT */}
        {activeFormat === 'standard' && (
          <div className="space-y-6">
            <p className="text-sm sm:text-base text-slate-700 dark:text-slate-200 leading-relaxed">
              {variants.standard?.content || lesson.content}
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-slate-200 dark:border-slate-700">
              {(variants.standard?.sections || []).map((sec: any, idx: number) => (
                <div key={idx} className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white">{sec.title}</h4>
                  <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">{sec.body}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* 5. MINI QUIZ & INSTANT BKT MASTERY UPDATE */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm space-y-6">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
          <div>
            <span className="text-xs uppercase font-bold text-[#1F4E79] dark:text-blue-400">
              Interactive Section Check
            </span>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white mt-0.5">
              Concept Understanding Check
            </h2>
          </div>
          <span className="text-xs text-slate-500">
            Question {activeQuestionIndex + 1} of {(lesson.adaptation?.quizQuestions || []).length}
          </span>
        </div>

        {lesson.adaptation?.quizQuestions?.[activeQuestionIndex] && (
          <div className="space-y-5">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              {lesson.adaptation.quizQuestions[activeQuestionIndex].question}
            </h3>

            {/* Answer Option Buttons */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {lesson.adaptation.quizQuestions[activeQuestionIndex].options.map(
                (opt: string, optIdx: number) => (
                  <button
                    key={opt}
                    onClick={() => {
                      setSelectedOption(optIdx);
                      setQuizResult(null);
                    }}
                    className={`p-4 rounded-2xl border text-left text-sm font-semibold transition-all ${
                      selectedOption === optIdx
                        ? 'border-[#1F4E79] bg-blue-50/60 dark:bg-slate-800 text-[#1F4E79] dark:text-blue-300 ring-2 ring-[#1F4E79]/30'
                        : 'border-slate-200 dark:border-slate-700 bg-slate-50/40 dark:bg-slate-800/40 text-slate-700 dark:text-slate-300 hover:bg-slate-100'
                    }`}
                  >
                    <span className="text-xs text-slate-400 block font-normal mb-1">
                      Option {String.fromCharCode(65 + optIdx)}
                    </span>
                    {opt}
                  </button>
                )
              )}
            </div>

            {/* Immediate BKT Feedback Result Box */}
            {quizResult && (
              <div
                className={`p-5 rounded-2xl border animate-in fade-in duration-200 ${
                  quizResult.isCorrect
                    ? 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-100'
                    : 'bg-amber-50 dark:bg-amber-950/50 border-amber-300 dark:border-amber-800 text-amber-900 dark:text-amber-100'
                }`}
              >
                <div className="flex items-center gap-2 font-bold text-sm">
                  {quizResult.isCorrect ? (
                    <>
                      <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                      <span>Terrific job! Correct answer.</span>
                    </>
                  ) : (
                    <>
                      <AlertCircle className="w-5 h-5 text-amber-600" />
                      <span>Not quite, but every try builds knowledge!</span>
                    </>
                  )}
                </div>

                <p className="mt-2 text-xs leading-relaxed opacity-90">
                  {quizResult.explanation}
                </p>

                {/* Real-time BKT updates badge */}
                <div className="mt-3 pt-3 border-t border-black/10 dark:border-white/10 flex flex-wrap items-center justify-between text-xs font-semibold gap-2">
                  <span>
                    BKT Knowledge Mastery: {Math.round(quizResult.bkt.pMasteryBefore * 100)}% →{' '}
                    <strong className="underline">
                      {Math.round(quizResult.bkt.pMasteryAfter * 100)}%
                    </strong>
                  </span>
                  <span className="text-emerald-700 dark:text-emerald-300">
                    Expected Next Accuracy: {Math.round(quizResult.bkt.expectedAccuracy * 100)}%
                  </span>
                </div>
              </div>
            )}

            {/* Action Bar */}
            <div className="flex items-center justify-between pt-2">
              <button
                onClick={() =>
                  speakText(
                    lesson.adaptation.quizQuestions[activeQuestionIndex].hint ||
                      'Think about the green leaves on a sunny day.'
                  )
                }
                className="text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 flex items-center gap-1.5"
              >
                <HelpCircle className="w-4 h-4" />
                <span>Hear Hint</span>
              </button>

              <div className="flex items-center gap-2">
                {!quizResult ? (
                  <button
                    disabled={selectedOption === null || submittingQuiz}
                    onClick={handleAnswerSubmit}
                    className="px-6 py-2.5 bg-[#1F4E79] hover:bg-[#163a5c] text-white text-xs font-bold rounded-xl shadow-sm transition-colors disabled:opacity-40"
                  >
                    <span>{submittingQuiz ? 'Calculating BKT...' : 'Check Answer'}</span>
                  </button>
                ) : (
                  <button
                    onClick={() => {
                      setSelectedOption(null);
                      setQuizResult(null);
                      const totalQ = (lesson.adaptation?.quizQuestions || []).length;
                      setActiveQuestionIndex((prev) => (prev + 1) % totalQ);
                    }}
                    className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow-sm transition-colors flex items-center gap-1.5"
                  >
                    <span>Next Question</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 6. LESSON COMFORT FEEDBACK WIDGET */}
      <div className="bg-slate-50 dark:bg-slate-800/60 rounded-3xl border border-slate-200 dark:border-slate-700 p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <ThumbsUp className="w-4 h-4 text-[#1F4E79] dark:text-blue-400" />
              Was this lesson comfortable?
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Your feedback immediately trains the Multi-Armed Bandit recommendation engine.
            </p>
          </div>

          {feedbackSent ? (
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/50 px-3 py-1.5 rounded-xl border border-emerald-200">
              <CheckCircle2 className="w-4 h-4" />
              <span>Feedback saved! Bandit reward updated.</span>
            </div>
          ) : (
            <div className="flex flex-wrap gap-2 text-xs">
              {[
                { id: 'too_easy', label: 'Too Easy' },
                { id: 'just_right', label: 'Just Right' },
                { id: 'too_difficult', label: 'Too Difficult' },
                { id: 'need_another_format', label: 'Need Another Format' },
              ].map((fb) => (
                <button
                  key={fb.id}
                  onClick={() => handleFeedback(fb.id)}
                  className="px-3 py-1.5 bg-white dark:bg-slate-800 hover:bg-slate-100 rounded-xl border border-slate-200 dark:border-slate-700 font-medium transition-colors"
                >
                  {fb.label}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ASK AI MODAL */}
      {showAskAi && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 max-w-lg w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-[#4F46E5]" />
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  Ask AI Helper
                </h3>
              </div>
              <button
                onClick={() => setShowAskAi(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-500">
              Type any word or concept that felt confusing, and AdaptEd AI will simplify it into a clear, everyday metaphor.
            </p>

            <div className="flex gap-2">
              <input
                type="text"
                value={aiConceptInput}
                onChange={(e) => setAiConceptInput(e.target.value)}
                placeholder="e.g. Chloroplast, Stomata, Glucose..."
                className="flex-1 p-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
              />
              <button
                disabled={aiLoading}
                onClick={handleAskAi}
                className="px-4 py-2.5 bg-[#4F46E5] hover:bg-indigo-600 text-white rounded-xl text-xs font-bold transition-colors"
              >
                {aiLoading ? 'Thinking...' : 'Explain Simply'}
              </button>
            </div>

            {aiExplanation && (
              <div className="p-4 bg-indigo-50/60 dark:bg-indigo-950/50 rounded-2xl border border-indigo-200 dark:border-indigo-800 text-xs text-indigo-950 dark:text-indigo-100 leading-relaxed">
                {aiExplanation}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
