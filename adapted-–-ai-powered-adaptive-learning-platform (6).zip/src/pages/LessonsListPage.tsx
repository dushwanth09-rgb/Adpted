import React, { useState, useEffect } from 'react';
import { BookOpen, Clock, ArrowRight, Play, Sparkles, Search, CheckCircle2, Calculator, Atom, Globe, Code, ChevronRight, Layers } from 'lucide-react';

interface LessonsListPageProps {
  onNavigate: (view: string, payload?: any) => void;
}

export const LessonsListPage: React.FC<LessonsListPageProps> = ({ onNavigate }) => {
  const [lessons, setLessons] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [selectedSubject, setSelectedSubject] = useState<string>('All');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch('/api/lessons');
        if (res.ok) {
          const data = await res.json();
          setLessons(data);
        }
      } catch (err) {
        console.error('Failed to load lessons list:', err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  const subjectsConfig = [
    { name: 'English', icon: BookOpen, color: 'from-blue-500 to-cyan-500', desc: 'Grammar, reading comprehension, vocabulary and spelling.' },
    { name: 'Mathematics', icon: Calculator, color: 'from-indigo-500 to-blue-600', desc: 'Arithmetic, fractions, geometry and measurements.' },
    { name: 'Science', icon: Atom, color: 'from-cyan-500 to-teal-500', desc: 'Life science, Earth & space science, and physical science.' },
    { name: 'Social Studies', icon: Globe, color: 'from-sky-500 to-blue-500', desc: 'History, civilizations, geography, and civics.' },
    { name: 'Computer Science', icon: Code, color: 'from-blue-600 to-indigo-600', desc: 'Programming basics, digital safety, hardware and web.' },
  ];

  const getSubjectStats = (subjectName: string) => {
    const subLessons = lessons.filter(l => l.subject === subjectName);
    const available = subLessons.length;
    // Simulated completed count and progress for demo
    const completed = Math.min(Math.floor(available * 0.35), available);
    const progress = available > 0 ? Math.round((completed / available) * 100) : 0;
    return { available, completed, progress };
  };

  const filtered = lessons.filter((l) => {
    const matchesSearch =
      l.title.toLowerCase().includes(search.toLowerCase()) ||
      l.subject.toLowerCase().includes(search.toLowerCase()) ||
      (l.summary && l.summary.toLowerCase().includes(search.toLowerCase()));
    const matchesSubject = selectedSubject === 'All' || l.subject === selectedSubject;
    return matchesSearch && matchesSubject;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs uppercase font-bold text-[#1F4E79] dark:text-blue-400 tracking-wider">
            Comprehensive Curriculum Library
          </span>
          <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
            Subject-Wise Adaptive Lessons
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-2xl">
            Explore over 100 structured lessons across English, Mathematics, Science, Social Studies, and Computer Science. Every lesson adapts instantly to your reading level, audio preferences, and learning pace.
          </p>
        </div>

        <div className="relative max-w-xs w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search all lessons or topics..."
            className="w-full pl-9 pr-3 py-2 text-xs bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl shadow-2xs focus:outline-hidden focus:ring-2 focus:ring-[#1F4E79]"
          />
        </div>
      </div>

      {/* Subject Selection Cards (Displayed when viewing All or as a quick switcher) */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Layers className="w-4 h-4 text-[#1F4E79] dark:text-blue-400" />
            Select Subject Category
          </h2>
          {selectedSubject !== 'All' && (
            <button
              onClick={() => setSelectedSubject('All')}
              className="text-xs font-bold text-[#1F4E79] dark:text-blue-400 hover:underline flex items-center gap-1"
            >
              View All Subjects ({lessons.length} lessons)
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          <button
            onClick={() => setSelectedSubject('All')}
            className={`text-left p-5 rounded-3xl border transition-all flex flex-col justify-between ${
              selectedSubject === 'All'
                ? 'bg-[#1F4E79] text-white border-[#1F4E79] shadow-md ring-2 ring-[#1F4E79]/30'
                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-blue-300 dark:hover:border-slate-700 shadow-2xs'
            }`}
          >
            <div className="space-y-2">
              <div className={`w-10 h-10 rounded-2xl flex items-center justify-center ${selectedSubject === 'All' ? 'bg-white/20 text-white' : 'bg-blue-50 dark:bg-slate-800 text-[#1F4E79] dark:text-blue-400'}`}>
                <Sparkles className="w-5 h-5" />
              </div>
              <h3 className="font-extrabold text-sm">All Subjects</h3>
              <p className={`text-[11px] line-clamp-2 ${selectedSubject === 'All' ? 'text-blue-100' : 'text-slate-500 dark:text-slate-400'}`}>
                Browse the complete catalog of all curriculum lessons.
              </p>
            </div>
            <div className={`mt-4 pt-3 border-t flex items-center justify-between text-xs font-bold ${selectedSubject === 'All' ? 'border-white/20 text-white' : 'border-slate-100 dark:border-slate-800 text-[#1F4E79] dark:text-blue-400'}`}>
              <span>{lessons.length} Lessons</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </div>
          </button>

          {subjectsConfig.map((sub) => {
            const stats = getSubjectStats(sub.name);
            const Icon = sub.icon;
            const isSelected = selectedSubject === sub.name;
            return (
              <button
                key={sub.name}
                onClick={() => setSelectedSubject(sub.name)}
                className={`text-left p-5 rounded-3xl border transition-all flex flex-col justify-between ${
                  isSelected
                    ? 'bg-[#1F4E79] text-white border-[#1F4E79] shadow-md ring-2 ring-[#1F4E79]/30'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-blue-300 dark:hover:border-slate-700 shadow-2xs'
                }`}
              >
                <div className="space-y-2">
                  <div className={`w-10 h-10 rounded-2xl flex items-center justify-center ${isSelected ? 'bg-white/20 text-white' : 'bg-blue-50 dark:bg-slate-800 text-[#1F4E79] dark:text-blue-400'}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="font-extrabold text-sm">{sub.name}</h3>
                  <p className={`text-[11px] line-clamp-2 ${isSelected ? 'text-blue-100' : 'text-slate-500 dark:text-slate-400'}`}>
                    {sub.desc}
                  </p>
                </div>

                <div className="space-y-2 mt-4 pt-3 border-t border-slate-100 dark:border-slate-800">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className={isSelected ? 'text-blue-100' : 'text-slate-500'}>Progress</span>
                    <span className="font-bold">{stats.progress}%</span>
                  </div>
                  <div className="w-full bg-slate-100 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${isSelected ? 'bg-amber-400' : 'bg-[#1F4E79]'}`}
                      style={{ width: `${stats.progress}%` }}
                    />
                  </div>
                  <div className={`flex items-center justify-between text-xs font-bold pt-1 ${isSelected ? 'text-white' : 'text-[#1F4E79] dark:text-blue-400'}`}>
                    <span>{stats.available} Lessons</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Lesson Catalog Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-[#1F4E79] dark:text-blue-400" />
            {selectedSubject === 'All' ? 'All Lessons Catalog' : `${selectedSubject} Lessons`} ({filtered.length})
          </h2>
        </div>

        {loading ? (
          <div className="text-center py-16 text-slate-400">Loading curriculum lessons...</div>
        ) : filtered.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-12 text-center space-y-3">
            <BookOpen className="w-10 h-10 text-slate-300 mx-auto" />
            <h3 className="font-bold text-slate-800 dark:text-slate-200">No lessons found</h3>
            <p className="text-xs text-slate-500">Try adjusting your search query or selecting another subject.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {filtered.map((lesson) => (
              <div
                key={lesson.id}
                className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-2xs hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs text-[#1F4E79] dark:text-blue-400 font-semibold">
                    <span className="px-2.5 py-0.5 bg-blue-50 dark:bg-blue-950/50 rounded-lg">{lesson.subject}</span>
                    <span className="text-slate-500">{lesson.gradeLevel || 'Grade 6'}</span>
                  </div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white leading-snug">
                    {lesson.title}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-3 leading-relaxed">
                    {lesson.summary}
                  </p>

                  {/* Formats Pills */}
                  <div className="pt-2 flex flex-wrap gap-1.5 text-[10px] text-slate-600 dark:text-slate-300">
                    <span className="px-2 py-0.5 bg-slate-100 dark:bg-slate-800 rounded-md font-medium">Large Text</span>
                    <span className="px-2 py-0.5 bg-slate-100 dark:bg-slate-800 rounded-md font-medium">Simplified</span>
                    <span className="px-2 py-0.5 bg-slate-100 dark:bg-slate-800 rounded-md font-medium">Audio Script</span>
                    <span className="px-2 py-0.5 bg-slate-100 dark:bg-slate-800 rounded-md font-medium">Interactive Visual</span>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  <span className="text-xs text-slate-400 flex items-center gap-1 font-medium">
                    <Clock className="w-3.5 h-3.5" />
                    {lesson.durationMinutes || 15} mins
                  </span>

                  <button
                    onClick={() => onNavigate('lesson_player', { lessonId: lesson.id })}
                    className="px-4 py-2 bg-[#1F4E79] hover:bg-[#163a5c] text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors shadow-xs"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Open Lesson</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
