import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import {
  CheckCircle2,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  BookOpen,
  Volume2,
  Type,
  Eye,
  AlignJustify,
  Clock,
  HelpCircle,
} from 'lucide-react';

interface OnboardingPageProps {
  onComplete: () => void;
}

export const OnboardingPage: React.FC<OnboardingPageProps> = ({ onComplete }) => {
  const { user, token } = useAuth();
  const [step, setStep] = useState<number>(1);
  const [saving, setSaving] = useState<boolean>(false);

  // Step 1: Basic profile
  const [name, setName] = useState(user?.name || '');
  const [age, setAge] = useState<number>(12);
  const [grade, setGrade] = useState('Grade 6');
  const [preferredLanguage, setPreferredLanguage] = useState('English');
  const [subjectInterests, setSubjectInterests] = useState<string[]>(['Science', 'Biology']);

  // Step 2: Learning Preferences (NO forced disability categories)
  const [preferences, setPreferences] = useState({
    primaryFormat: 'large_text',
    largeText: true,
    standardText: false,
    dyslexiaFont: true,
    highContrast: false,
    simplifiedLanguage: true,
    audioLearning: true,
    visualLearning: false,
    captions: true,
    increasedLineSpacing: true,
    reducedMotion: false,
    speechRate: 0.9,
  });

  // Step 3: Learning pace
  const [learningPace, setLearningPace] = useState<'slow' | 'moderate' | 'fast' | 'ai_recommend'>('slow');

  // Step 4: Diagnostic Quiz
  const diagnosticQuestions = [
    {
      id: 'q1',
      question: 'What is the main source of light and natural energy for Earth?',
      options: ['The Sun', 'The Moon', 'Wind turbines', 'Ocean waves'],
      correctIndex: 0,
    },
    {
      id: 'q2',
      question: 'What do green plants take in from the air to make their food?',
      options: ['Carbon Dioxide (CO2)', 'Helium', 'Gold dust', 'Neon'],
      correctIndex: 0,
    },
    {
      id: 'q3',
      question: 'When water on a lake turns into vapor that rises into clouds, this is called:',
      options: ['Evaporation', 'Freezing', 'Melting', 'Sedimentation'],
      correctIndex: 0,
    },
    {
      id: 'q4',
      question: 'Which of the following is the largest planet in our solar system?',
      options: ['Jupiter', 'Mars', 'Mercury', 'Venus'],
      correctIndex: 0,
    },
    {
      id: 'q5',
      question: 'If you divide an apple into 4 equal slices and eat 1 slice, what fraction was eaten?',
      options: ['1/4 (one quarter)', '1/2 (one half)', '4/1', '3/4'],
      correctIndex: 0,
    },
  ];

  const [quizAnswers, setQuizAnswers] = useState<Record<number, number>>({});

  const toggleInterest = (interest: string) => {
    setSubjectInterests((prev) =>
      prev.includes(interest) ? prev.filter((i) => i !== interest) : [...prev, interest]
    );
  };

  const handlePreferenceToggle = (key: keyof typeof preferences) => {
    setPreferences((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  const handleAnswerSelect = (qIdx: number, optIdx: number) => {
    setQuizAnswers((prev) => ({ ...prev, [qIdx]: optIdx }));
  };

  const calculateScore = () => {
    let correct = 0;
    diagnosticQuestions.forEach((q, idx) => {
      if (quizAnswers[idx] === q.correctIndex) correct++;
    });
    return correct;
  };

  const handleFinishOnboarding = async () => {
    setSaving(true);
    const score = calculateScore();

    try {
      const res = await fetch('/api/profile/onboard', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          name,
          age,
          grade,
          preferredLanguage,
          subjectInterests,
          preferences,
          learningPace,
          quizScore: score,
        }),
      });

      if (res.ok) {
        onComplete();
      }
    } catch (err) {
      console.error('Failed to complete onboarding:', err);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto py-12 px-4 sm:px-6">
      {/* Stepper Progress */}
      <div className="mb-8">
        <div className="flex items-center justify-between text-xs font-semibold text-slate-500 mb-2">
          <span>Step {step} of 5</span>
          <span>{step === 5 ? 'Ready to Learn!' : 'Personalizing your learning engine'}</span>
        </div>
        <div className="w-full bg-slate-200 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
          <div
            className="bg-[#1F4E79] dark:bg-blue-500 h-full transition-all duration-300"
            style={{ width: `${(step / 5) * 100}%` }}
          />
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 shadow-xl">
        {/* STEP 1: Basic Profile */}
        {step === 1 && (
          <div className="space-y-6">
            <div>
              <span className="text-xs uppercase font-bold text-[#1F4E79] dark:text-blue-400">
                Step 1: Basic Profile
              </span>
              <h2 className="text-2xl font-bold text-slate-900 dark:text-white mt-1">
                Tell us a little about yourself
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                This helps us calibrate appropriate grade-level educational vocabulary.
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase mb-1">
                  Your Name
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full p-2.5 text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
                  placeholder="e.g. Aarav"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase mb-1">
                    Age
                  </label>
                  <input
                    type="number"
                    value={age}
                    onChange={(e) => setAge(parseInt(e.target.value) || 12)}
                    className="w-full p-2.5 text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase mb-1">
                    Current Grade
                  </label>
                  <select
                    value={grade}
                    onChange={(e) => setGrade(e.target.value)}
                    className="w-full p-2.5 text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
                  >
                    <option>Grade 4</option>
                    <option>Grade 5</option>
                    <option>Grade 6</option>
                    <option>Grade 7</option>
                    <option>Grade 8</option>
                    <option>High School</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase mb-1">
                  Subjects You Enjoy
                </label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {['Science', 'Biology', 'Earth & Climate', 'Solar System', 'Math Basics', 'Story Reading'].map(
                    (subj) => (
                      <button
                        key={subj}
                        type="button"
                        onClick={() => toggleInterest(subj)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-medium border transition-colors ${
                          subjectInterests.includes(subj)
                            ? 'bg-[#1F4E79] text-white border-[#1F4E79]'
                            : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                        }`}
                      >
                        {subj}
                      </button>
                    )
                  )}
                </div>
              </div>
            </div>

            <div className="pt-4 flex justify-end">
              <button
                type="button"
                onClick={() => setStep(2)}
                className="px-6 py-2.5 bg-[#1F4E79] hover:bg-[#163a5c] text-white text-xs font-bold rounded-xl flex items-center gap-2"
              >
                <span>Continue to Preferences</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: Learning Preferences */}
        {step === 2 && (
          <div className="space-y-6">
            <div>
              <span className="text-xs uppercase font-bold text-[#1F4E79] dark:text-blue-400">
                Step 2: Accessibility & Formats
              </span>
              <h2 className="text-2xl font-bold text-slate-900 dark:text-white mt-1">
                How do you learn best?
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Select the tools you find helpful. We never force labels or categories.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {[
                { key: 'largeText', label: 'Large Text', desc: 'Larger font size and short text chunks', icon: Type },
                { key: 'dyslexiaFont', label: 'Dyslexia-Friendly Font', desc: 'Distinct bottom-weighted letterforms (Lexend)', icon: BookOpen },
                { key: 'simplifiedLanguage', label: 'Simplified English', desc: 'Direct sentences & contextual word definitions', icon: HelpCircle },
                { key: 'audioLearning', label: 'Audio Narration', desc: 'Listen to lessons read aloud with speech controls', icon: Volume2 },
                { key: 'visualLearning', label: 'Visual Explanations', desc: 'Interactive concept diagrams and visual models', icon: Eye },
                { key: 'increasedLineSpacing', label: 'Comfortable Line Spacing', desc: 'More vertical space between sentences', icon: AlignJustify },
                { key: 'highContrast', label: 'High Contrast Mode', desc: 'Strong visual distinction between text and cards', icon: Eye },
                { key: 'reducedMotion', label: 'Reduced Motion', desc: 'Removes slide transitions and animation effects', icon: Clock },
              ].map((item) => {
                const Icon = item.icon;
                const isChecked = (preferences as any)[item.key];
                return (
                  <button
                    key={item.key}
                    type="button"
                    onClick={() => handlePreferenceToggle(item.key as any)}
                    className={`p-3.5 rounded-2xl border text-left flex items-start gap-3 transition-all ${
                      isChecked
                        ? 'border-[#1F4E79] dark:border-blue-500 bg-blue-50/40 dark:bg-slate-800 ring-2 ring-[#1F4E79]/20'
                        : 'border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/40'
                    }`}
                  >
                    <div
                      className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5 ${
                        isChecked
                          ? 'bg-[#1F4E79] text-white'
                          : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-xs font-bold text-slate-900 dark:text-white block">
                        {item.label}
                      </span>
                      <span className="text-[11px] text-slate-500 dark:text-slate-400">
                        {item.desc}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>

            <div className="pt-4 flex justify-between">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="px-4 py-2 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 rounded-xl text-xs font-semibold flex items-center gap-1.5"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back</span>
              </button>
              <button
                type="button"
                onClick={() => setStep(3)}
                className="px-6 py-2.5 bg-[#1F4E79] hover:bg-[#163a5c] text-white text-xs font-bold rounded-xl flex items-center gap-2"
              >
                <span>Continue to Pacing</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: Learning Pace */}
        {step === 3 && (
          <div className="space-y-6">
            <div>
              <span className="text-xs uppercase font-bold text-[#1F4E79] dark:text-blue-400">
                Step 3: Learning Pace
              </span>
              <h2 className="text-2xl font-bold text-slate-900 dark:text-white mt-1">
                What learning pace feels comfortable?
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                You can adjust this anytime, or let the Bayesian algorithm calibrate based on quiz accuracy.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[
                {
                  id: 'slow',
                  title: 'Slow & Guided',
                  desc: 'Bite-sized sections, frequent review steps, and relaxed audio pace (0.8x-0.9x).',
                },
                {
                  id: 'moderate',
                  title: 'Moderate Pace',
                  desc: 'Balanced progression with regular concept checks and standard audio cadence (1.0x).',
                },
                {
                  id: 'fast',
                  title: 'Fast Pace',
                  desc: 'Quick comprehensive overviews and direct concept summaries.',
                },
                {
                  id: 'ai_recommend',
                  title: 'Let AI Recommend',
                  desc: 'Adaptive multi-armed bandit dynamically selects based on real-time quiz performance.',
                },
              ].map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setLearningPace(p.id as any)}
                  className={`p-4 rounded-2xl border text-left transition-all ${
                    learningPace === p.id
                      ? 'border-[#1F4E79] dark:border-blue-500 bg-blue-50/50 dark:bg-slate-800 ring-2 ring-[#1F4E79]/20 shadow-sm'
                      : 'border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/40'
                  }`}
                >
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white">{p.title}</h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">{p.desc}</p>
                </button>
              ))}
            </div>

            <div className="pt-4 flex justify-between">
              <button
                type="button"
                onClick={() => setStep(2)}
                className="px-4 py-2 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 rounded-xl text-xs font-semibold flex items-center gap-1.5"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back</span>
              </button>
              <button
                type="button"
                onClick={() => setStep(4)}
                className="px-6 py-2.5 bg-[#1F4E79] hover:bg-[#163a5c] text-white text-xs font-bold rounded-xl flex items-center gap-2"
              >
                <span>Diagnostic Quiz</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 4: Initial Knowledge Quiz */}
        {step === 4 && (
          <div className="space-y-6">
            <div>
              <span className="text-xs uppercase font-bold text-[#1F4E79] dark:text-blue-400">
                Step 4: Initial Knowledge Check
              </span>
              <h2 className="text-2xl font-bold text-slate-900 dark:text-white mt-1">
                Quick 5-Question Check
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                No countdown timers or stress. This simply initializes your baseline BKT prior P(L0).
              </p>
            </div>

            <div className="space-y-6">
              {diagnosticQuestions.map((q, qIdx) => (
                <div key={q.id} className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700">
                  <span className="text-[11px] font-bold text-[#1F4E79] dark:text-blue-400 uppercase">
                    Question {qIdx + 1} of 5
                  </span>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white mt-0.5">
                    {q.question}
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-3">
                    {q.options.map((opt, optIdx) => (
                      <button
                        key={opt}
                        type="button"
                        onClick={() => handleAnswerSelect(qIdx, optIdx)}
                        className={`p-3 rounded-xl border text-left text-xs font-medium transition-all ${
                          quizAnswers[qIdx] === optIdx
                            ? 'bg-[#1F4E79] text-white border-[#1F4E79] shadow-xs'
                            : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100'
                        }`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-4 flex justify-between">
              <button
                type="button"
                onClick={() => setStep(3)}
                className="px-4 py-2 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 rounded-xl text-xs font-semibold flex items-center gap-1.5"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back</span>
              </button>
              <button
                type="button"
                onClick={() => setStep(5)}
                className="px-6 py-2.5 bg-[#1F4E79] hover:bg-[#163a5c] text-white text-xs font-bold rounded-xl flex items-center gap-2"
              >
                <span>Review & Finish</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 5: Save & Confirmation */}
        {step === 5 && (
          <div className="text-center py-6 space-y-6">
            <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div>
              <span className="text-xs uppercase font-bold text-emerald-600 dark:text-emerald-400">
                Profile Configured
              </span>
              <h2 className="text-2xl font-bold text-slate-900 dark:text-white mt-1">
                Welcome to AdaptEd, {name || 'Learner'}!
              </h2>
              <p className="text-sm text-slate-600 dark:text-slate-300 max-w-md mx-auto mt-2">
                Your initial knowledge model (BKT prior P(L0) = {((calculateScore() / 5) * 100).toFixed(0)}%) and
                sensory preferences have been initialized.
              </p>
            </div>

            <div className="p-4 bg-slate-50 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700 max-w-md mx-auto text-left text-xs space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-500">Learner Name:</span>
                <span className="font-bold text-slate-900 dark:text-white">{name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Selected Pace:</span>
                <span className="font-bold text-slate-900 dark:text-white capitalize">{learningPace}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Diagnostic Score:</span>
                <span className="font-bold text-emerald-600">{calculateScore()} / 5 Correct</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">First Recommended Lesson:</span>
                <span className="font-bold text-[#1F4E79] dark:text-blue-400">Photosynthesis</span>
              </div>
            </div>

            <button
              type="button"
              disabled={saving}
              onClick={handleFinishOnboarding}
              className="px-8 py-3.5 bg-[#1F4E79] hover:bg-[#163a5c] text-white font-bold rounded-xl shadow-lg transition-colors inline-flex items-center gap-2 text-sm disabled:opacity-50"
            >
              <span>{saving ? 'Configuring Profile...' : 'Open My Student Dashboard'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
