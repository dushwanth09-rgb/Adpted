import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { useAuth } from '../context/AuthContext.tsx';
import { useAccessibility } from '../context/AccessibilityContext.tsx';
import { saveAttemptToFirestore, saveMasteryToFirestore } from '../firebase/firestoreService.ts';
import {
  HelpCircle,
  Volume2,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  Award,
  Mic,
  MicOff,
} from 'lucide-react';

interface PracticeQuizProps {
  onNavigate: (view: string, payload?: any) => void;
}

export const PracticeQuiz: React.FC<PracticeQuizProps> = ({ onNavigate }) => {
  const { user, token } = useAuth();
  const { speakText } = useAccessibility();

  const [questions, setQuestions] = useState<any[]>([]);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [result, setResult] = useState<any | null>(null);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);
  const [bktHistory, setBktHistory] = useState<number[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // Voice input state
  const [isListening, setIsListening] = useState<boolean>(false);
  const [speechTranscript, setSpeechTranscript] = useState<string>('');

  useEffect(() => {
    async function loadQuestions() {
      try {
        const res = await fetch('/api/lessons/lesson_photosynthesis');
        if (res.ok) {
          const data = await res.json();
          const qList = data.adaptation?.quizQuestions || [];
          setQuestions(qList);
        }
      } catch (err) {
        console.error('Failed to load questions:', err);
      } finally {
        setLoading(false);
      }
    }
    loadQuestions();
  }, []);

  const handleVoiceInput = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert('Speech recognition is not supported in this browser. Please select an answer by clicking or tapping.');
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = 'en-US';
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;

      recognition.onstart = () => {
        setIsListening(true);
        setSpeechTranscript('Listening...');
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript.toLowerCase();
        setSpeechTranscript(`Heard: "${transcript}"`);

        // Check if voice matches option A, B, C, D or keywords
        const currentQ = questions[currentIndex];
        let matchedIndex = -1;

        if (transcript.includes('option a') || transcript.includes('first')) matchedIndex = 0;
        else if (transcript.includes('option b') || transcript.includes('second')) matchedIndex = 1;
        else if (transcript.includes('option c') || transcript.includes('third')) matchedIndex = 2;
        else if (transcript.includes('option d') || transcript.includes('fourth')) matchedIndex = 3;
        else {
          currentQ.options.forEach((opt: string, idx: number) => {
            if (transcript.includes(opt.toLowerCase().slice(0, 5))) {
              matchedIndex = idx;
            }
          });
        }

        if (matchedIndex !== -1) {
          setSelectedOption(matchedIndex);
        }
      };

      recognition.onerror = () => {
        setIsListening(false);
        setSpeechTranscript('');
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
    } catch (err) {
      console.error('Speech recognition error:', err);
      setIsListening(false);
    }
  };

  const handleCheckAnswer = async () => {
    if (selectedOption === null) return;
    setSubmitting(true);
    const q = questions[currentIndex];

    try {
      const res = await fetch('/api/quiz/answer', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          lessonId: 'lesson_photosynthesis',
          questionId: q.id,
          selectedOption,
          topic: 'photosynthesis',
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setResult(data);
        setBktHistory((prev) => [...prev, data.bkt.pMasteryAfter]);

        if (data.isCorrect) {
          try {
            confetti({
              particleCount: 50,
              spread: 60,
              origin: { y: 0.8 },
            });
          } catch (e) {}
        }

        // Sync attempt and BKT progress to Cloud Firestore
        if (user) {
          saveAttemptToFirestore({
            id: `att_${Date.now()}`,
            studentId: user.id,
            lessonId: 'lesson_photosynthesis',
            questionId: q.id,
            questionText: q.question,
            selectedOption,
            isCorrect: data.isCorrect,
            timestamp: new Date().toISOString(),
            pMasteryBefore: data.bkt.pMasteryBefore,
            pMasteryAfter: data.bkt.pMasteryAfter,
          }).catch((err) => console.warn('Firestore attempt sync note:', err));

          saveMasteryToFirestore(user.id, 'photosynthesis', {
            studentId: user.id,
            topic: 'photosynthesis',
            pMastery: data.bkt.pMasteryAfter,
            lastUpdated: new Date().toISOString(),
          }).catch((err) => console.warn('Firestore mastery sync note:', err));
        }
      }
    } catch (err) {
      console.error('Failed to submit answer:', err);
    } finally {
      setSubmitting(false);
    }
  };

  const handleNext = () => {
    setSelectedOption(null);
    setResult(null);
    setSpeechTranscript('');

    if (currentIndex + 1 < questions.length) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      setIsCompleted(true);
      try {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch (e) {}
    }
  };

  if (loading) {
    return (
      <div className="max-w-2xl mx-auto py-20 px-4 text-center">
        <Sparkles className="w-8 h-8 text-[#1F4E79] animate-spin mx-auto mb-2" />
        <h3 className="text-base font-bold text-slate-800 dark:text-slate-200">
          Preparing Practice Session...
        </h3>
      </div>
    );
  }

  const currentQ = questions[currentIndex];

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => onNavigate('student_dashboard')}
          className="flex items-center gap-2 text-xs font-semibold text-slate-500 hover:text-slate-900 dark:hover:text-white"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Exit to Dashboard</span>
        </button>
        <span className="text-xs font-semibold text-[#1F4E79] dark:text-blue-400 uppercase tracking-wider">
          Untimed Knowledge Practice
        </span>
      </div>

      {!isCompleted ? (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-10 shadow-xl space-y-6">
          {/* Progress Bar */}
          <div>
            <div className="flex justify-between text-xs font-semibold text-slate-500 mb-2">
              <span>
                Question {currentIndex + 1} of {questions.length}
              </span>
              <span>{Math.round(((currentIndex + 1) / questions.length) * 100)}% Complete</span>
            </div>
            <div className="w-full bg-slate-100 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
              <div
                className="bg-[#1F4E79] dark:bg-blue-500 h-full transition-all duration-300"
                style={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
              />
            </div>
          </div>

          {/* Question Text */}
          <div className="space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Concept: {currentQ?.concept || 'Photosynthesis'}
            </span>
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white leading-snug">
              {currentQ?.question}
            </h2>
          </div>

          {/* Answer Buttons (Large, Touch-Friendly >=44px) */}
          <div className="space-y-3">
            {currentQ?.options.map((opt: string, optIdx: number) => (
              <button
                key={opt}
                onClick={() => {
                  setSelectedOption(optIdx);
                  setResult(null);
                }}
                className={`w-full p-4 sm:p-5 rounded-2xl border text-left text-sm sm:text-base font-semibold transition-all flex items-center justify-between ${
                  selectedOption === optIdx
                    ? 'border-[#1F4E79] bg-blue-50/60 dark:bg-slate-800 text-[#1F4E79] dark:text-blue-300 ring-2 ring-[#1F4E79]/30 shadow-xs'
                    : 'border-slate-200 dark:border-slate-700 bg-slate-50/40 dark:bg-slate-800/40 text-slate-800 dark:text-slate-200 hover:bg-slate-100'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className="w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center justify-center font-bold text-xs shrink-0">
                    {String.fromCharCode(65 + optIdx)}
                  </span>
                  <span>{opt}</span>
                </div>
                {selectedOption === optIdx && (
                  <CheckCircle2 className="w-5 h-5 text-[#1F4E79] dark:text-blue-400 shrink-0" />
                )}
              </button>
            ))}
          </div>

          {/* Voice input indicator */}
          {speechTranscript && (
            <div className="p-3 bg-blue-50 dark:bg-blue-950/50 text-[#1F4E79] dark:text-blue-300 text-xs rounded-xl font-medium">
              🎤 {speechTranscript}
            </div>
          )}

          {/* Instant BKT Feedback */}
          {result && (
            <div
              className={`p-5 rounded-2xl border ${
                result.isCorrect
                  ? 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-100'
                  : 'bg-amber-50 dark:bg-amber-950/50 border-amber-300 dark:border-amber-800 text-amber-900 dark:text-amber-100'
              }`}
            >
              <div className="flex items-center gap-2 font-bold text-sm">
                {result.isCorrect ? (
                  <>
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    <span>Correct! Wonderful thinking.</span>
                  </>
                ) : (
                  <>
                    <AlertCircle className="w-5 h-5 text-amber-600" />
                    <span>Good try! Review the explanation below:</span>
                  </>
                )}
              </div>
              <p className="mt-2 text-xs leading-relaxed opacity-95">
                {result.explanation}
              </p>
              <div className="mt-3 pt-3 border-t border-black/10 dark:border-white/10 flex items-center justify-between text-xs font-semibold">
                <span>
                  BKT Mastery Update: {Math.round(result.bkt.pMasteryBefore * 100)}% →{' '}
                  <strong className="underline font-bold">
                    {Math.round(result.bkt.pMasteryAfter * 100)}%
                  </strong>
                </span>
                <span className="text-emerald-700 dark:text-emerald-300">
                  Learned Rate: P(T) = 0.18
                </span>
              </div>
            </div>
          )}

          {/* Action Footer */}
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => speakText(currentQ?.hint || 'Review what plants breathe from the air.')}
                className="px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 text-xs font-medium rounded-xl flex items-center gap-1.5 transition-colors"
              >
                <HelpCircle className="w-4 h-4 text-amber-500" />
                <span>Hear Hint</span>
              </button>

              <button
                type="button"
                onClick={handleVoiceInput}
                className={`px-3 py-2 text-xs font-medium rounded-xl flex items-center gap-1.5 transition-colors ${
                  isListening
                    ? 'bg-rose-100 text-rose-700 animate-pulse'
                    : 'bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300'
                }`}
              >
                {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4 text-blue-500" />}
                <span>{isListening ? 'Listening...' : 'Answer by Voice'}</span>
              </button>
            </div>

            {!result ? (
              <button
                disabled={selectedOption === null || submitting}
                onClick={handleCheckAnswer}
                className="px-8 py-3 bg-[#1F4E79] hover:bg-[#163a5c] text-white text-xs font-bold rounded-xl shadow-md transition-colors disabled:opacity-40"
              >
                <span>{submitting ? 'Updating BKT...' : 'Submit Answer'}</span>
              </button>
            ) : (
              <button
                onClick={handleNext}
                className="px-8 py-3 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow-md transition-colors flex items-center gap-1.5"
              >
                <span>{currentIndex + 1 === questions.length ? 'Finish Quiz' : 'Next Question'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      ) : (
        /* Completion Card */
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 sm:p-12 shadow-xl text-center space-y-6">
          <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-600 flex items-center justify-center mx-auto text-2xl">
            🏆
          </div>

          <div>
            <span className="text-xs uppercase font-bold text-emerald-600 dark:text-emerald-400">
              Session Complete
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
              Outstanding Work, {user?.name.split(' ')[0] || 'Learner'}!
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-300 max-w-md mx-auto mt-2">
              You practiced {questions.length} questions. Your Bayesian knowledge model has recorded your
              progress and updated your mastery profile.
            </p>
          </div>

          {/* Summary Metric Strip */}
          <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 max-w-md mx-auto grid grid-cols-2 gap-4 text-center">
            <div>
              <span className="text-xs text-slate-500 block">Final Mastery</span>
              <span className="text-xl font-bold text-emerald-600">
                {Math.round((bktHistory[bktHistory.length - 1] || 0.65) * 100)}%
              </span>
            </div>
            <div>
              <span className="text-xs text-slate-500 block">Streak Bonus</span>
              <span className="text-xl font-bold text-amber-500">+1 Day</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <button
              onClick={() => onNavigate('student_dashboard')}
              className="w-full sm:w-auto px-7 py-3 bg-[#1F4E79] hover:bg-[#163a5c] text-white text-xs font-bold rounded-xl shadow-md transition-colors"
            >
              Return to Student Dashboard
            </button>
            <button
              onClick={() => {
                setIsCompleted(false);
                setCurrentIndex(0);
                setSelectedOption(null);
                setResult(null);
              }}
              className="w-full sm:w-auto px-7 py-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-xl transition-colors"
            >
              Practice Again
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
