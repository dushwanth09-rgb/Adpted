import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { useAccessibility } from '../context/AccessibilityContext.tsx';
import {
  Flame,
  Award,
  CheckCircle2,
  TrendingUp,
  BookOpen,
  ArrowRight,
  Play,
  Clock,
  Sparkles,
  Volume2,
  Sliders,
  Calendar,
  Layers,
  ChevronRight,
} from 'lucide-react';

interface StudentDashboardProps {
  onNavigate: (view: string, payload?: any) => void;
  onOpenAccessibility: () => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({
  onNavigate,
  onOpenAccessibility,
}) => {
  const { user, profile, token, logout } = useAuth();
  const [lessons, setLessons] = useState<any[]>([]);
  const [nextStep, setNextStep] = useState<any>(null);
  const [progressData, setProgressData] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    async function loadDashboardData() {
      try {
        const headers: Record<string, string> = token ? { Authorization: `Bearer ${token}` } : {};

        const [lessonsRes, nextStepRes, progressRes] = await Promise.all([
          fetch('/api/lessons'),
          fetch('/api/next-step', { headers }),
          fetch('/api/analytics/progress', { headers }),
        ]);

        if (lessonsRes.ok) {
          const lData = await lessonsRes.json();
          setLessons(lData);
        }
        if (nextStepRes.ok) {
          const nData = await nextStepRes.json();
          setNextStep(nData);
        }
        if (progressRes.ok) {
          const pData = await progressRes.json();
          setProgressData(pData);
        }
      } catch (err) {
        console.error('Failed to load student dashboard:', err);
      } finally {
        setLoading(false);
      }
    }

    loadDashboardData();
  }, []);

  const studentName = profile?.name || user?.name || 'Aarav';
  const streak = profile?.streakDays || 4;
  const masteryPercent = Math.round((profile?.currentMastery || 0.48) * 100);
  const accuracy = profile?.quizAccuracy || 72;
  const completed = profile?.lessonsCompleted || 3;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* 1. WELCOME BANNER & STATS STRIP */}
      <div className="bg-gradient-to-r from-[#1F4E79] to-[#2B6CB0] text-white rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-blue-200 uppercase tracking-wider mb-1">
              <span>Learner Dashboard</span>
              <span>·</span>
              <span>{profile?.grade || 'Grade 6'}</span>
              <span>·</span>
              <span className="capitalize">{profile?.learningPace || 'Guided'} Pace</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Welcome back, {studentName}!
            </h1>
            <p className="text-sm text-blue-100 max-w-xl mt-1.5">
              Your personalized learning engine has adapted today's lessons to your preferred{' '}
              <strong className="underline capitalize">
                {profile?.preferences.primaryFormat.replace('_', ' ') || 'Large Text & Audio'}
              </strong>{' '}
              format.
            </p>
          </div>

          {/* Quick Action Button */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => onNavigate('lesson_player', { lessonId: 'lesson_photosynthesis' })}
              className="px-5 py-3 bg-white text-[#1F4E79] hover:bg-blue-50 font-bold text-xs rounded-xl shadow-md transition-colors flex items-center gap-2"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Resume Photosynthesis</span>
            </button>
            <button
              onClick={onOpenAccessibility}
              className="p-3 bg-white/10 hover:bg-white/20 text-white rounded-xl border border-white/20 transition-colors"
              title="Adjust sensory and font settings"
            >
              <Sliders className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Floating Stat Metrics Strip */}
        <div className="mt-8 pt-6 border-t border-white/15 grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center shrink-0">
              <TrendingUp className="w-5 h-5 text-emerald-300" />
            </div>
            <div>
              <span className="text-xs text-blue-200 block">Overall Mastery</span>
              <span className="text-xl font-bold">{masteryPercent}%</span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center shrink-0">
              <Flame className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <span className="text-xs text-blue-200 block">Learning Streak</span>
              <span className="text-xl font-bold">{streak} Days</span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-5 h-5 text-cyan-300" />
            </div>
            <div>
              <span className="text-xs text-blue-200 block">Quiz Accuracy</span>
              <span className="text-xl font-bold">{accuracy}%</span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center shrink-0">
              <BookOpen className="w-5 h-5 text-purple-300" />
            </div>
            <div>
              <span className="text-xs text-blue-200 block">Completed</span>
              <span className="text-xl font-bold">{completed} Lessons</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. MAIN 2-ZONE LAYOUT */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column (2 Cols wide): Continue Learning + Today's Plan + Progress */}
        <div className="lg:col-span-2 space-y-8">
          {/* Card 1: Continue Learning Active Card */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                <h2 className="text-base font-bold text-slate-900 dark:text-white">
                  Continue Learning
                </h2>
              </div>
              <span className="text-xs text-slate-500">Biology Unit 2</span>
            </div>

            <div className="mt-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-50 dark:bg-slate-800/50 p-5 rounded-2xl border border-slate-200 dark:border-slate-700">
              <div className="space-y-1">
                <span className="text-[11px] font-bold text-[#1F4E79] dark:text-blue-400 uppercase tracking-wider">
                  Current Lesson
                </span>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                  Photosynthesis: How Plants Make Food
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md">
                  Section 2: Leaf Chloroplast Organelles & Gas Exchange (Stomata).
                </p>

                {/* Progress bar */}
                <div className="pt-2">
                  <div className="flex justify-between text-[11px] text-slate-500 mb-1">
                    <span>Reading Progress</span>
                    <span className="font-semibold text-slate-800 dark:text-slate-200">65%</span>
                  </div>
                  <div className="w-full bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                    <div className="bg-emerald-500 h-full w-[65%]" />
                  </div>
                </div>
              </div>

              <button
                onClick={() => onNavigate('lesson_player', { lessonId: 'lesson_photosynthesis' })}
                className="px-5 py-3 bg-[#1F4E79] hover:bg-[#163a5c] text-white text-xs font-bold rounded-xl shadow-sm transition-colors flex items-center gap-1.5 shrink-0 self-end sm:self-center"
              >
                <span>Continue</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Card 2: Today's Learning Plan & Recommended Lessons */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
              <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Calendar className="w-4 h-4 text-[#1F4E79] dark:text-blue-400" />
                Today's Learning Plan
              </h2>
              <span className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold">
                2 of 3 Tasks Done
              </span>
            </div>

            <div className="mt-4 space-y-3">
              {lessons.map((lesson, idx) => (
                <div
                  key={lesson.id}
                  onClick={() => onNavigate('lesson_player', { lessonId: lesson.id })}
                  className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 hover:border-[#1F4E79] dark:hover:border-blue-500 hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-all cursor-pointer flex items-center justify-between gap-4"
                >
                  <div className="flex items-center gap-3.5">
                    <div className="w-9 h-9 rounded-xl bg-blue-50 dark:bg-blue-950 text-[#1F4E79] dark:text-blue-400 flex items-center justify-center font-bold text-xs shrink-0">
                      0{idx + 1}
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                        {lesson.title}
                      </h4>
                      <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-0.5">
                        <span>{lesson.subject}</span>
                        <span>·</span>
                        <span>{lesson.durationMinutes || 15} mins</span>
                        <span>·</span>
                        <span className="text-emerald-600 dark:text-emerald-400">
                          {lesson.questionsCount || 5} Questions
                        </span>
                      </div>
                    </div>
                  </div>

                  <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
                </div>
              ))}
            </div>
          </div>

          {/* Card 3: BKT Topic Mastery Breakdown */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
            <h2 className="text-base font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-600" />
              Bayesian Knowledge Tracing (BKT) Mastery by Topic
            </h2>

            <div className="space-y-4">
              {[
                { topic: 'Photosynthesis (Cellular Plant Food)', mastery: 0.48, delta: '+13%' },
                { topic: 'The Water Cycle (Evaporation & Clouds)', mastery: 0.55, delta: '+15%' },
                { topic: 'Solar System (Orbits & Gravitation)', mastery: 0.42, delta: '+8%' },
              ].map((t) => (
                <div key={t.topic} className="space-y-1.5">
                  <div className="flex justify-between text-xs">
                    <span className="font-semibold text-slate-800 dark:text-slate-200">
                      {t.topic}
                    </span>
                    <div className="flex items-center gap-2">
                      <span className="text-emerald-600 font-bold">{t.delta}</span>
                      <span className="font-bold text-slate-900 dark:text-white">
                        {Math.round(t.mastery * 100)}%
                      </span>
                    </div>
                  </div>
                  <div className="w-full bg-slate-100 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
                    <div
                      className="bg-[#1F4E79] dark:bg-blue-500 h-full rounded-full transition-all duration-500"
                      style={{ width: `${t.mastery * 100}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column (1 Col): AI Recommendation & Badges & Settings */}
        <div className="space-y-8">
          {/* AI Recommendation Engine Card */}
          <div className="bg-gradient-to-b from-indigo-50 to-white dark:from-slate-900 dark:to-slate-800/80 rounded-3xl border border-indigo-100 dark:border-slate-700 p-6 shadow-sm">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-700 dark:text-indigo-400 block">
                  Bandit Recommendation
                </span>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Next Step Advice
                </h3>
              </div>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed bg-white dark:bg-slate-800 p-3.5 rounded-xl border border-indigo-100/60 dark:border-slate-700">
              {nextStep?.recommendation?.explanation ||
                'Based on your preference for Large Text and your 48% Photosynthesis mastery, we recommend completing the step-by-step leaf anatomy card next.'}
            </p>

            <button
              onClick={() => onNavigate('practice')}
              className="mt-4 w-full py-2.5 px-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-2"
            >
              <span>Launch Recommended Practice Quiz</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Achievement Badges */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-4 flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-500" />
              Achievements Earned
            </h3>

            <div className="grid grid-cols-2 gap-3 text-center">
              <div className="p-3 bg-amber-50 dark:bg-amber-950/40 rounded-2xl border border-amber-200 dark:border-amber-800">
                <div className="text-xl">🔥</div>
                <strong className="block text-xs text-slate-900 dark:text-white mt-1">4-Day Streak</strong>
                <span className="text-[10px] text-slate-500">Consistent learner</span>
              </div>

              <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl border border-emerald-200 dark:border-emerald-800">
                <div className="text-xl">🌿</div>
                <strong className="block text-xs text-slate-900 dark:text-white mt-1">Plant Explorer</strong>
                <span className="text-[10px] text-slate-500">Photosynthesis hero</span>
              </div>

              <div className="p-3 bg-blue-50 dark:bg-blue-950/40 rounded-2xl border border-blue-200 dark:border-blue-800">
                <div className="text-xl">🎧</div>
                <strong className="block text-xs text-slate-900 dark:text-white mt-1">Audio Master</strong>
                <span className="text-[10px] text-slate-500">3 lessons heard</span>
              </div>

              <div className="p-3 bg-purple-50 dark:bg-purple-950/40 rounded-2xl border border-purple-200 dark:border-purple-800">
                <div className="text-xl">🎯</div>
                <strong className="block text-xs text-slate-900 dark:text-white mt-1">Accurate Thinker</strong>
                <span className="text-[10px] text-slate-500">&gt;70% Accuracy</span>
              </div>
            </div>
          </div>

          {/* Quick Sensory Profile Summary */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                My Sensory Configuration
              </h3>
              <button
                onClick={onOpenAccessibility}
                className="text-xs text-[#1F4E79] dark:text-blue-400 font-semibold hover:underline"
              >
                Edit
              </button>
            </div>

            <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300">
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span>Reading Format:</span>
                <span className="font-semibold capitalize">
                  {profile?.preferences.primaryFormat.replace('_', ' ') || 'Large Text'}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span>Dyslexia Font:</span>
                <span className="font-semibold text-emerald-600">
                  {profile?.preferences.dyslexiaFont ? 'Lexend Active' : 'Standard'}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span>Audio Narration:</span>
                <span className="font-semibold text-emerald-600">
                  {profile?.preferences.audioLearning ? 'Enabled (0.9x)' : 'Disabled'}
                </span>
              </div>
              <div className="flex justify-between py-1">
                <span>Line Spacing:</span>
                <span className="font-semibold">
                  {profile?.preferences.increasedLineSpacing ? 'Comfortable (1.8)' : 'Standard'}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
