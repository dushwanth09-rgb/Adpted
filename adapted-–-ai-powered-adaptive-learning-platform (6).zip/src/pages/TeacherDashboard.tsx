import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { uploadMediaAssetToStorage, saveLessonToFirestore } from '../firebase/firestoreService.ts';
import {
  Users,
  TrendingUp,
  AlertTriangle,
  Upload,
  BookOpen,
  CheckCircle2,
  ChevronRight,
  Sparkles,
  BarChart3,
  Sliders,
  Bell,
  Eye,
  FileText,
  Search,
} from 'lucide-react';

interface TeacherDashboardProps {
  onNavigate: (view: string, payload?: any) => void;
}

export const TeacherDashboard: React.FC<TeacherDashboardProps> = ({ onNavigate }) => {
  const { user, token } = useAuth();
  const [activeTab, setActiveTab] = useState<'overview' | 'students' | 'upload' | 'alerts'>('overview');
  const [overviewData, setOverviewData] = useState<any>(null);
  const [studentsList, setStudentsList] = useState<any[]>([]);
  const [selectedStudentDetail, setSelectedStudentDetail] = useState<any | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  // Lesson Upload state
  const [uploadTitle, setUploadTitle] = useState('');
  const [uploadSubject, setUploadSubject] = useState('Biology & Life Science');
  const [uploadContent, setUploadContent] = useState('');
  const [attachedFile, setAttachedFile] = useState<File | null>(null);
  const [storageUrl, setStorageUrl] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadingStorage, setUploadingStorage] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState<any | null>(null);

  useEffect(() => {
    async function loadTeacherData() {
      try {
        const headers: Record<string, string> = token ? { Authorization: `Bearer ${token}` } : {};
        const [ovRes, stRes] = await Promise.all([
          fetch('/api/teacher/overview', { headers }),
          fetch('/api/teacher/students', { headers }),
        ]);

        if (ovRes.ok) {
          const ov = await ovRes.json();
          setOverviewData(ov);
        }
        if (stRes.ok) {
          const st = await stRes.json();
          setStudentsList(st.students || []);
        }
      } catch (err) {
        console.error('Failed to load teacher dashboard data:', err);
      } finally {
        setLoading(false);
      }
    }

    loadTeacherData();
  }, [token]);

  const handleOpenStudent = async (studentId: string) => {
    try {
      const res = await fetch(`/api/teacher/student/${studentId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setSelectedStudentDetail(data);
      }
    } catch (err) {
      console.error('Failed to load student detail:', err);
    }
  };

  const handleLoadDemoFile = (type: 'pdf' | 'audio' | 'diagram') => {
    if (type === 'pdf') {
      setStorageUrl('/uploads/1793795018744_curriculum_guide.pdf');
      setUploadTitle('Plant Cell Biology & Organelles');
      setUploadSubject('Biology & Life Science');
      setUploadContent('Plant cells are eukaryotic cells that contain chloroplasts for photosynthesis, a cell wall made of cellulose for structural rigidity, and a large central vacuole that regulates turgor pressure.');
    } else if (type === 'audio') {
      setStorageUrl('/uploads/1793795018768_lesson_narration.wav');
      setUploadTitle('Water Cycle & Evaporation Audio Guide');
      setUploadSubject('Earth & Planetary Science');
      setUploadContent('The hydrological cycle describes the continuous movement of water on, above and below the surface of the Earth. Solar radiation drives evaporation from oceans and lakes into atmospheric vapor.');
    } else if (type === 'diagram') {
      setStorageUrl('/uploads/1793795018763_photosynthesis_leaf_diagram.svg');
      setUploadTitle('Leaf Cross-Section & Stomata Mechanics');
      setUploadSubject('Biology & Life Science');
      setUploadContent('Stomata are microscopic pores on the underside of leaves flanked by guard cells. They regulate gas exchange by taking in carbon dioxide and releasing water vapor and oxygen.');
    }
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // File size check: 25MB max
    if (file.size > 25 * 1024 * 1024) {
      alert('File exceeds the 25MB maximum size limit.');
      return;
    }

    setAttachedFile(file);

    // If text file, read text directly into editor
    if (file.name.endsWith('.txt') || file.name.endsWith('.md')) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        if (text) {
          setUploadContent(text);
          if (!uploadTitle) {
            setUploadTitle(file.name.replace(/\.[^/.]+$/, ''));
          }
        }
      };
      reader.readAsText(file);
    }

    // Upload asset directly to Firebase Storage with resilient server fallback
    setUploadingStorage(true);
    try {
      const cleanName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
      const storagePath = `lessons/${Date.now()}_${cleanName}`;
      const downloadUrl = await uploadMediaAssetToStorage(storagePath, file);
      setStorageUrl(downloadUrl);
      if (!uploadContent) {
        setUploadContent(`[Lesson resource attached: ${file.name}]\nResource URL: ${downloadUrl}\n\nContent overview: This lesson covers ${file.name.replace(/\.[^/.]+$/, '')}.`);
      }
      if (!uploadTitle) {
        setUploadTitle(file.name.replace(/\.[^/.]+$/, ''));
      }
    } catch (err) {
      console.error('File upload failed:', err);
    } finally {
      setUploadingStorage(false);
    }
  };

  const handleUploadLesson = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadTitle.trim() || !uploadContent.trim()) return;
    setUploading(true);
    setUploadSuccess(null);

    try {
      const res = await fetch('/api/lessons', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          title: uploadTitle,
          subject: uploadSubject,
          content: uploadContent,
          storageUrl,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setUploadSuccess(data.lesson);
        // Persist lesson to Cloud Firestore
        saveLessonToFirestore(data.lesson).catch((err) =>
          console.warn('Firestore lesson sync note:', err)
        );
        setUploadTitle('');
        setUploadContent('');
        setAttachedFile(null);
        setStorageUrl(null);
      }
    } catch (err) {
      console.error('Upload failed:', err);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* 1. TEACHER HEADER */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-6 border-b border-slate-200 dark:border-slate-800 gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-[#1F4E79] dark:text-blue-400 uppercase tracking-wider">
            <span>Educator Portal</span>
            <span>·</span>
            <span>Grade 6 Science Section A</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
            Teacher Analytics Console
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Monitor Bayesian Knowledge Tracing (BKT) trajectory, sensory formats, and AI pedagogical alerts.
          </p>
        </div>

        {/* Tab Controls */}
        <div className="flex p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs gap-1">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-3.5 py-2 rounded-lg font-semibold transition-all ${
              activeTab === 'overview'
                ? 'bg-white dark:bg-slate-700 text-[#1F4E79] dark:text-blue-300 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('students')}
            className={`px-3.5 py-2 rounded-lg font-semibold transition-all ${
              activeTab === 'students'
                ? 'bg-white dark:bg-slate-700 text-[#1F4E79] dark:text-blue-300 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            Student Roster
          </button>
          <button
            onClick={() => setActiveTab('upload')}
            className={`px-3.5 py-2 rounded-lg font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'upload'
                ? 'bg-white dark:bg-slate-700 text-[#1F4E79] dark:text-blue-300 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Upload Content</span>
          </button>
          <button
            onClick={() => setActiveTab('alerts')}
            className={`px-3.5 py-2 rounded-lg font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'alerts'
                ? 'bg-white dark:bg-slate-700 text-[#1F4E79] dark:text-blue-300 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Bell className="w-3.5 h-3.5" />
            <span>Pedagogical Alerts</span>
          </button>
        </div>
      </div>

      {/* 2. STATS STRIP */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
        <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 block">Total Students</span>
          <span className="text-2xl font-bold text-slate-900 dark:text-white mt-1 block">
            {overviewData?.stats?.totalStudents || 18}
          </span>
          <span className="text-[11px] text-emerald-600 font-medium">100% Enrolled</span>
        </div>

        <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 block">Active This Week</span>
          <span className="text-2xl font-bold text-slate-900 dark:text-white mt-1 block">
            {overviewData?.stats?.activeStudents || 16}
          </span>
          <span className="text-[11px] text-slate-400">Regular logins</span>
        </div>

        <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 block">Average Class Mastery</span>
          <span className="text-2xl font-bold text-[#1F4E79] dark:text-blue-400 mt-1 block">
            {Math.round((overviewData?.stats?.avgClassMastery || 0.68) * 100)}%
          </span>
          <span className="text-[11px] text-emerald-600 font-medium">+12% vs Month 1</span>
        </div>

        <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 block">Adapted Lessons Read</span>
          <span className="text-2xl font-bold text-slate-900 dark:text-white mt-1 block">
            {overviewData?.stats?.lessonsCompleted || 45}
          </span>
          <span className="text-[11px] text-slate-400">Multi-variant completions</span>
        </div>

        <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 block">Needing Support</span>
          <span className="text-2xl font-bold text-amber-600 mt-1 block">
            {overviewData?.stats?.needingSupportCount || 1}
          </span>
          <span className="text-[11px] text-amber-600 font-medium">1 format recommendation</span>
        </div>
      </div>

      {/* 3. TAB 1: OVERVIEW & ANALYTICS */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Table Preview (2 Cols) */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
              <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
                <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Users className="w-4 h-4 text-[#1F4E79] dark:text-blue-400" />
                  Active Students Overview
                </h3>
                <button
                  onClick={() => setActiveTab('students')}
                  className="text-xs text-[#1F4E79] dark:text-blue-400 font-semibold hover:underline"
                >
                  View All Students
                </button>
              </div>

              <div className="mt-4 overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 uppercase tracking-wider font-semibold">
                      <th className="pb-3">Student</th>
                      <th className="pb-3">Mastery</th>
                      <th className="pb-3">Accuracy</th>
                      <th className="pb-3">Learning Format</th>
                      <th className="pb-3">Status</th>
                      <th className="pb-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {studentsList.map((st) => (
                      <tr key={st.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                        <td className="py-3.5 pr-3 font-semibold text-slate-900 dark:text-white">
                          <div className="flex items-center gap-2.5">
                            <img
                              src={st.avatar}
                              alt={st.name}
                              className="w-7 h-7 rounded-full object-cover"
                            />
                            <span>{st.name}</span>
                          </div>
                        </td>
                        <td className="py-3.5 pr-3 font-mono font-bold text-[#1F4E79] dark:text-blue-400">
                          {Math.round(st.mastery * 100)}%
                        </td>
                        <td className="py-3.5 pr-3 font-mono">{st.accuracy}%</td>
                        <td className="py-3.5 pr-3">
                          <span className="capitalize text-slate-600 dark:text-slate-300 font-medium">
                            {st.preferredFormat?.replace('_', ' ') || 'Large Text'}
                          </span>
                        </td>
                        <td className="py-3.5 pr-3">
                          <span
                            className={`px-2 py-0.5 rounded-md text-[11px] font-semibold ${
                              st.status === 'Excelling'
                                ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                                : st.status === 'On Track'
                                ? 'bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300'
                                : 'bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                            }`}
                          >
                            {st.status}
                          </span>
                        </td>
                        <td className="py-3.5 text-right">
                          <button
                            onClick={() => handleOpenStudent(st.id)}
                            className="text-xs font-semibold text-[#1F4E79] dark:text-blue-400 hover:underline"
                          >
                            Inspect Profile
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* BKT Curriculum Health */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-4">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-[#1F4E79] dark:text-blue-400" />
                Curriculum Topic Mastery (Class Aggregates)
              </h3>
              <div className="space-y-3">
                {[
                  { topic: 'Photosynthesis (Cellular Biology)', score: 68, target: '70% Target' },
                  { topic: 'The Water Cycle & Atmosphere', score: 76, target: '70% Target' },
                  { topic: 'Planetary Orbits & Gravity', score: 58, target: '70% Target' },
                ].map((item) => (
                  <div key={item.topic} className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-semibold text-slate-800 dark:text-slate-200">
                        {item.topic}
                      </span>
                      <span className="font-bold text-slate-900 dark:text-white">{item.score}%</span>
                    </div>
                    <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-[#1F4E79] dark:bg-blue-500 h-full rounded-full"
                        style={{ width: `${item.score}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Format Preference Breakdown + Recent Alerts */}
          <div className="space-y-6">
            {/* Preferred Format Distribution */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">
                Preferred Learning Formats
              </h3>
              <p className="text-xs text-slate-500 mb-4">
                Distribution of accessibility preferences selected across your class:
              </p>

              <div className="space-y-2.5 text-xs">
                {[
                  { label: 'Large Text & Short Chunks', count: 6, pct: '33%' },
                  { label: 'Simplified English & Vocabulary', count: 5, pct: '28%' },
                  { label: 'Audio Narration First', count: 4, pct: '22%' },
                  { label: 'Visual Interactive Diagrams', count: 3, pct: '17%' },
                ].map((f) => (
                  <div key={f.label} className="p-2.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl flex items-center justify-between">
                    <span className="font-medium text-slate-700 dark:text-slate-200">{f.label}</span>
                    <span className="font-bold text-[#1F4E79] dark:text-blue-400 font-mono">
                      {f.count} ({f.pct})
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* AI Pedagogical Alerts */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                  <Bell className="w-4 h-4 text-amber-500" />
                  Live Teacher Alerts
                </h3>
              </div>

              {(overviewData?.recentAlerts || []).map((alert: any) => (
                <div
                  key={alert.id}
                  className="p-3 bg-amber-50/60 dark:bg-amber-950/40 rounded-xl border border-amber-200 dark:border-amber-900 text-xs space-y-1"
                >
                  <strong className="text-slate-900 dark:text-white block font-bold">
                    {alert.title}
                  </strong>
                  <p className="text-slate-600 dark:text-slate-300 leading-normal">
                    {alert.message}
                  </p>
                  <span className="text-[11px] font-semibold text-amber-800 dark:text-amber-300 block pt-1">
                    Action: {alert.suggestedAction}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 4. TAB 2: DETAILED STUDENT ROSTER */}
      {activeTab === 'students' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                Grade 6 Class Roster
              </h2>
              <p className="text-xs text-slate-500">
                Detailed individual cognitive profiles and format adaptations.
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 uppercase tracking-wider font-semibold">
                  <th className="pb-3">Student Name</th>
                  <th className="pb-3">Grade</th>
                  <th className="pb-3">Learning Pace</th>
                  <th className="pb-3">BKT Mastery</th>
                  <th className="pb-3">Quiz Accuracy</th>
                  <th className="pb-3">Active Sensory Format</th>
                  <th className="pb-3">Status</th>
                  <th className="pb-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {studentsList.map((st) => (
                  <tr key={st.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="py-4 pr-3 font-bold text-slate-900 dark:text-white">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={st.avatar}
                          alt={st.name}
                          className="w-8 h-8 rounded-full object-cover"
                        />
                        <div>
                          <span>{st.name}</span>
                          <span className="block text-[11px] text-slate-400 font-normal">
                            {st.email}
                          </span>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 pr-3 text-slate-600 dark:text-slate-300">{st.grade}</td>
                    <td className="py-4 pr-3 capitalize font-medium">{st.pace}</td>
                    <td className="py-4 pr-3 font-mono font-bold text-[#1F4E79] dark:text-blue-400 text-sm">
                      {Math.round(st.mastery * 100)}%
                    </td>
                    <td className="py-4 pr-3 font-mono text-sm">{st.accuracy}%</td>
                    <td className="py-4 pr-3">
                      <span className="capitalize font-medium text-slate-700 dark:text-slate-200">
                        {st.preferredFormat?.replace('_', ' ') || 'Large Text & Audio'}
                      </span>
                    </td>
                    <td className="py-4 pr-3">
                      <span
                        className={`px-2.5 py-1 rounded-md text-[11px] font-semibold ${
                          st.status === 'Excelling'
                            ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                            : st.status === 'On Track'
                            ? 'bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300'
                            : 'bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                        }`}
                      >
                        {st.status}
                      </span>
                    </td>
                    <td className="py-4 text-right">
                      <button
                        onClick={() => handleOpenStudent(st.id)}
                        className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-800 dark:text-slate-200 text-xs font-semibold rounded-lg transition-colors"
                      >
                        Inspect Progress
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 5. TAB 3: TEACHER LESSON UPLOAD & AI ADAPTATION */}
      {activeTab === 'upload' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-10 shadow-sm space-y-6">
          <div>
            <span className="text-xs uppercase font-bold text-[#1F4E79] dark:text-blue-400">
              Curriculum Ingestion
            </span>
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white mt-1">
              Upload Educational Content for AI Adaptation
            </h2>
            <p className="text-xs text-slate-500 mt-1 max-w-2xl">
              Paste standard textbook text or curriculum materials. AdaptEd's AI engine preserves
              underlying educational meaning while automatically synthesizing Standard, Large Text,
              Simplified English, Step-by-Step, Visual Diagram, and Audio formats!
            </p>
          </div>

          <form onSubmit={handleUploadLesson} className="space-y-4 max-w-2xl">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase mb-1">
                Lesson Title
              </label>
              <input
                type="text"
                required
                value={uploadTitle}
                onChange={(e) => setUploadTitle(e.target.value)}
                placeholder="e.g. Gravity and Planetary Orbits"
                className="w-full p-2.5 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase mb-1">
                  Subject Category
                </label>
                <select
                  value={uploadSubject}
                  onChange={(e) => setUploadSubject(e.target.value)}
                  className="w-full p-2.5 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
                >
                  <option>Biology & Life Science</option>
                  <option>Earth & Planetary Science</option>
                  <option>Physics & Energy</option>
                  <option>Mathematics & Fractions</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase mb-1">
                  Target Grade
                </label>
                <input
                  type="text"
                  disabled
                  value="Grade 6 Adaptable"
                  className="w-full p-2.5 text-sm bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-500"
                />
              </div>
            </div>

            {/* Firebase Storage Diagnostic Banner & Safe Fallback Notice */}
            <div className="p-3.5 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 rounded-2xl space-y-1.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-amber-900 dark:text-amber-200 text-xs font-bold">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>Cloud Storage Status: Unprovisioned (HTTP 404 on default bucket)</span>
                </div>
                <span className="text-[10px] bg-amber-200 dark:bg-amber-900 text-amber-900 dark:text-amber-100 px-2 py-0.5 rounded-full font-mono font-medium">
                  Starter / Spark Tier
                </span>
              </div>
              <p className="text-[11px] text-amber-800 dark:text-amber-300 leading-relaxed">
                Bucket <code className="font-mono text-amber-950 dark:text-amber-100">bubbly-camera-36lcq.firebasestorage.app</code> requires 1-click initialization in Firebase Console (Storage &rarr; &apos;Get started&apos;). Uploaded curriculum PDFs, audio, and diagrams are currently safeguarded via resilient local caching with metadata tracking in Cloud Firestore.
              </p>
            </div>

            {/* Quick Demonstration Files Fast-Load Bar */}
            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700">
              <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-2 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-blue-500" />
                Quick-Load Demonstration Lesson Files:
              </span>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => handleLoadDemoFile('pdf')}
                  className="px-2.5 py-1.5 bg-white dark:bg-slate-700 hover:bg-blue-50 dark:hover:bg-slate-600 border border-slate-200 dark:border-slate-600 rounded-xl text-left text-xs transition-all shadow-2xs"
                >
                  <span className="font-bold text-[#1F4E79] dark:text-blue-300 block text-[11px]">📄 Sample PDF</span>
                  <span className="text-[10px] text-slate-500 block truncate">Plant Cell Biology</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleLoadDemoFile('audio')}
                  className="px-2.5 py-1.5 bg-white dark:bg-slate-700 hover:bg-blue-50 dark:hover:bg-slate-600 border border-slate-200 dark:border-slate-600 rounded-xl text-left text-xs transition-all shadow-2xs"
                >
                  <span className="font-bold text-[#1F4E79] dark:text-blue-300 block text-[11px]">🎧 Sample Audio</span>
                  <span className="text-[10px] text-slate-500 block truncate">Water Cycle Narration</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleLoadDemoFile('diagram')}
                  className="px-2.5 py-1.5 bg-white dark:bg-slate-700 hover:bg-blue-50 dark:hover:bg-slate-600 border border-slate-200 dark:border-slate-600 rounded-xl text-left text-xs transition-all shadow-2xs"
                >
                  <span className="font-bold text-[#1F4E79] dark:text-blue-300 block text-[11px]">🖼️ Sample Diagram</span>
                  <span className="text-[10px] text-slate-500 block truncate">Leaf Stomata Visual</span>
                </button>
              </div>
            </div>

            {/* Custom File Upload (PDF, Audio, Images) */}
            <div className="p-4 bg-blue-50/50 dark:bg-slate-800/80 rounded-2xl border border-blue-100 dark:border-slate-700 space-y-2">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase">
                Or Upload Custom File (PDF, Audio, Image, TXT &bull; Max 25MB)
              </label>
              <div className="flex items-center gap-3">
                <label className="cursor-pointer px-4 py-2 bg-white dark:bg-slate-700 hover:bg-slate-50 dark:hover:bg-slate-600 border border-slate-300 dark:border-slate-600 rounded-xl text-xs font-bold text-slate-700 dark:text-slate-200 transition-colors flex items-center gap-1.5 shadow-xs">
                  <Upload className="w-3.5 h-3.5 text-[#1F4E79] dark:text-blue-400" />
                  <span>Choose File</span>
                  <input
                    type="file"
                    accept=".pdf,.txt,.md,.mp3,.wav,.m4a,.png,.jpg,.jpeg,.svg"
                    onChange={handleFileSelect}
                    className="hidden"
                  />
                </label>
                <span className="text-xs text-slate-500 truncate max-w-[200px]">
                  {attachedFile ? attachedFile.name : storageUrl ? storageUrl.split('/').pop() : 'No file chosen yet'}
                </span>
              </div>

              {uploadingStorage && (
                <div className="text-xs text-blue-600 dark:text-blue-400 font-medium animate-pulse flex items-center gap-1.5 pt-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Uploading asset &amp; logging Firestore metadata...</span>
                </div>
              )}

              {storageUrl && (
                <div className="text-xs text-emerald-700 dark:text-emerald-300 font-medium flex items-center gap-1.5 pt-1">
                  <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                  <span className="truncate">Resource attached: {storageUrl}</span>
                </div>
              )}
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase mb-1">
                Raw Curriculum Text
              </label>
              <textarea
                required
                rows={6}
                value={uploadContent}
                onChange={(e) => setUploadContent(e.target.value)}
                placeholder="Paste paragraph or lesson text here (e.g. Newton's law of universal gravitation states that every particle attracts every other particle...)"
                className="w-full p-3 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl leading-relaxed"
              />
            </div>

            <button
              type="submit"
              disabled={uploading}
              className="px-6 py-3 bg-[#1F4E79] hover:bg-[#163a5c] text-white font-bold text-xs rounded-xl shadow-md transition-colors flex items-center gap-2 disabled:opacity-50"
            >
              <Sparkles className="w-4 h-4 text-blue-300" />
              <span>{uploading ? 'Generating Multi-Format Adaptation...' : 'Process & Adapt Lesson with AI'}</span>
            </button>
          </form>

          {/* Upload Success Card */}
          {uploadSuccess && (
            <div className="p-6 bg-emerald-50 dark:bg-emerald-950/60 rounded-3xl border border-emerald-300 dark:border-emerald-800 space-y-4">
              <div className="flex items-center gap-2 text-emerald-800 dark:text-emerald-200 font-bold text-sm">
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                <span>Lesson Successfully Adapted and Published!</span>
              </div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {uploadSuccess.title}
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-300">
                {uploadSuccess.summary}
              </p>

              <div className="pt-2 flex items-center gap-3">
                <button
                  onClick={() => onNavigate('lesson_player', { lessonId: uploadSuccess.id })}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold rounded-xl"
                >
                  Preview Lesson Player
                </button>
                <span className="text-xs text-emerald-700 dark:text-emerald-300">
                  Generated 6 accessible formats + {uploadSuccess.adaptation.quizQuestions.length} practice questions.
                </span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 6. TAB 4: PEDAGOGICAL ALERTS */}
      {activeTab === 'alerts' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm space-y-4">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-2">
            Pedagogical Recommendations & Alerts
          </h2>
          <p className="text-xs text-slate-500 mb-4">
            Generated automatically when the Bayesian model observes format-specific performance shifts.
          </p>

          <div className="space-y-3">
            {(overviewData?.recentAlerts || []).map((alert: any) => (
              <div
                key={alert.id}
                className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-200">
                      {alert.type.replace('_', ' ')}
                    </span>
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                      {alert.title}
                    </h4>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-300 max-w-xl">
                    {alert.message}
                  </p>
                  <span className="text-xs text-emerald-600 font-semibold block">
                    Suggested Action: {alert.suggestedAction}
                  </span>
                </div>

                <button
                  onClick={() => alert(`Format suggestion dispatched to ${alert.studentName}'s learning engine!`)}
                  className="px-4 py-2 bg-[#1F4E79] hover:bg-[#163a5c] text-white text-xs font-semibold rounded-xl shrink-0 transition-colors"
                >
                  Apply Recommendation
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* STUDENT INSPECTION MODAL DRAWER */}
      {selectedStudentDetail && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 max-w-2xl w-full shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <img
                  src={selectedStudentDetail.student.avatar}
                  alt={selectedStudentDetail.student.name}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div>
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                    {selectedStudentDetail.student.name}
                  </h3>
                  <span className="text-xs text-slate-500">
                    {selectedStudentDetail.student.grade} · {selectedStudentDetail.student.profile?.learningPace} pace
                  </span>
                </div>
              </div>
              <button
                onClick={() => setSelectedStudentDetail(null)}
                className="text-slate-400 hover:text-slate-700 font-bold text-sm"
              >
                ✕
              </button>
            </div>

            {/* AI Pedagogical Note */}
            <div className="p-4 bg-blue-50 dark:bg-blue-950/60 rounded-2xl border border-blue-200 dark:border-blue-800 text-xs text-blue-950 dark:text-blue-100 space-y-1">
              <span className="font-bold text-[#1F4E79] dark:text-blue-300 uppercase tracking-wider block">
                AI Pedagogical Analysis:
              </span>
              <p>{selectedStudentDetail.aiRecommendation}</p>
            </div>

            {/* BKT Mastery History */}
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                Bayesian Knowledge Tracing (BKT) Records:
              </h4>
              <div className="space-y-2">
                {Object.entries(selectedStudentDetail.mastery || {}).map(([topic, rec]: [string, any]) => (
                  <div key={topic} className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-800 dark:text-slate-200 capitalize">
                      {topic.replace('_', ' ')}
                    </span>
                    <div className="flex items-center gap-3">
                      <span className="text-slate-400">{rec.attemptsCount} attempts</span>
                      <span className="font-bold font-mono text-[#1F4E79] dark:text-blue-400">
                        {Math.round(rec.pMastery * 100)}% Mastery
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setSelectedStudentDetail(null)}
                className="px-6 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-semibold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
