import { GoogleGenAI, Type } from '@google/genai';

export interface AdaptedLessonPayload {
  title: string;
  subject: string;
  originalText: string;
  readingLevel: string;
  variants: {
    standard: {
      content: string;
      sections: Array<{ title: string; body: string }>;
    };
    simplified: {
      content: string;
      simplifiedWords: Array<{ complex: string; simple: string; definition: string }>;
      sections: Array<{ title: string; body: string }>;
    };
    largeText: {
      content: string;
      chunkedParagraphs: string[];
    };
    stepByStep: {
      steps: Array<{ stepNumber: number; title: string; explanation: string; actionTip?: string }>;
    };
    visual: {
      diagramTitle: string;
      diagramDescription: string;
      visualElements: Array<{ label: string; role: string; icon: string }>;
      flowDescription: string[];
    };
    audioScript: {
      intro: string;
      spokenSections: Array<{ cue: string; text: string }>;
      summarySpeech: string;
    };
  };
  keyTakeaways: string[];
  summary: string;
  quizQuestions: Array<{
    id: string;
    question: string;
    options: string[];
    correctAnswerIndex: number;
    explanation: string;
    hint: string;
    concept: string;
  }>;
  aiGenerated: boolean;
  modelUsed?: string;
}

let geminiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (geminiClient) return geminiClient;
  const key = process.env.GEMINI_API_KEY;
  if (!key || key.length < 20 || key.includes('MY_GEMINI_API_KEY')) return null;

  try {
    geminiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
    return geminiClient;
  } catch (err) {
    console.error('Failed to init Gemini SDK:', err);
    return null;
  }
}

/**
 * High-quality deterministic fallback adapter that guarantees rich, pedagogically sound,
 * multi-format variants for any educational topic (photosynthesis, water cycle, fractions, solar system, etc.)
 */
export function generateDeterministicAdaptation(
  title: string,
  subject: string,
  content: string
): AdaptedLessonPayload {
  const isPhotosynthesis =
    title.toLowerCase().includes('photosynthesis') ||
    content.toLowerCase().includes('photosynthesis') ||
    content.toLowerCase().includes('chlorophyll');

  if (isPhotosynthesis) {
    return {
      title: title || 'How Plants Make Food: Photosynthesis',
      subject: subject || 'Biology & Life Science',
      originalText: content,
      readingLevel: 'Grade 5-7 Adaptable',
      variants: {
        standard: {
          content: `Photosynthesis is the fundamental biological process through which green plants, algae, and certain bacteria transform radiant light energy into chemical energy stored in glucose molecules. Chlorophyll, a specialized pigment housed within cellular chloroplasts, captures sunlight. The plant takes up liquid water from its roots and absorbs carbon dioxide gas through microscopic leaf pores called stomata. Using the absorbed solar photons to split water molecules, the plant combines hydrogen with carbon dioxide to manufacture glucose, releasing molecular oxygen as a vital byproduct.`,
          sections: [
            {
              title: 'What is Photosynthesis?',
              body: 'Photosynthesis is the miraculous biochemical engine of Earth. It captures radiant solar energy and synthesizes glucose sugars that nourish nearly every food chain on our planet.',
            },
            {
              title: 'The Core Ingredients',
              body: 'Three essential raw inputs are required: Sunlight (energy source), Water (drawn through roots via capillary xylem vessels), and Carbon Dioxide (absorbed from air via stomata).',
            },
            {
              title: 'The Outputs & Byproducts',
              body: 'The plant synthesizes Glucose (sugar food for plant growth and cellular respiration) and releases clean Oxygen into the atmosphere for all breathing animals.',
            },
          ],
        },
        simplified: {
          content: `Plants make their own food! They use sunlight from the sky, water from the soil, and carbon dioxide from the air. Inside green leaves, tiny helpers called chloroplasts catch the sunlight. The plant mixes water and carbon dioxide together to make sweet sugar called glucose. When plants make their food, they also give off fresh oxygen for us to breathe!`,
          simplifiedWords: [
            { complex: 'Photosynthesis', simple: 'Plant food-making', definition: 'The way plants use light to make food' },
            { complex: 'Chlorophyll', simple: 'Green leaf helper', definition: 'The special green pigment that catches sunshine' },
            { complex: 'Stomata', simple: 'Tiny leaf breathing holes', definition: 'Small openings on leaves where gases go in and out' },
            { complex: 'Glucose', simple: 'Plant sugar', definition: 'Sweet food that gives the plant energy to grow' },
          ],
          sections: [
            {
              title: '1. What Plants Need',
              body: 'Just like we need food and water, plants need three things: Sunshine, Water from rain or soil, and Air (Carbon Dioxide).',
            },
            {
              title: '2. The Leaf Kitchen',
              body: 'Green leaves act like a warm kitchen. They mix water and air using sunlight like an oven to bake sweet plant sugar.',
            },
            {
              title: '3. A Gift for Humans',
              body: 'While making sugar, plants blow out fresh, clean oxygen. This is the air you and I breathe right now!',
            },
          ],
        },
        largeText: {
          content: `PLANTS MAKE THEIR OWN FOOD USING SUNLIGHT.

THREE KEY INGREDIENTS:
1. SUNLIGHT: Natural energy from the sun.
2. WATER: Soaked up from the soil through roots.
3. CARBON DIOXIDE: Gas absorbed from surrounding air.

THE RESULT:
• GLUCOSE: Energy-rich sugar food for the plant.
• OXYGEN: Fresh gas released into the air for humans to breathe.`,
          chunkedParagraphs: [
            'Plants are natural food factories.',
            'They catch sunlight using green leaves.',
            'Roots drink water from the soil.',
            'Leaves breathe in carbon dioxide gas.',
            'Sunlight powers the reaction into sweet glucose.',
            'Fresh oxygen is released for us to breathe.',
          ],
        },
        stepByStep: {
          steps: [
            {
              stepNumber: 1,
              title: 'Sunlight Enters the Leaves',
              explanation: 'Solar photons strike the leaf surface. Green chlorophyll pigments absorb red and blue light waves to capture energy.',
              actionTip: 'Notice how green plants turn their leaves directly toward window light.',
            },
            {
              stepNumber: 2,
              title: 'Roots Absorb Water',
              explanation: 'Microscopic root hairs absorb moisture and trace minerals from deep within the damp soil.',
              actionTip: 'Water travels upwards like drinking juice through a microscopic straw.',
            },
            {
              stepNumber: 3,
              title: 'Leaves Breathe Carbon Dioxide',
              explanation: 'Tiny pores on the underside of leaves (stomata) open up to take in carbon dioxide gas from the atmosphere.',
            },
            {
              stepNumber: 4,
              title: 'Sunlight Powers the Reaction',
              explanation: 'Inside chloroplast organelles, light energy breaks water molecules apart and recombines hydrogen with carbon dioxide to form glucose.',
            },
            {
              stepNumber: 5,
              title: 'Oxygen is Released to the Sky',
              explanation: 'Oxygen atoms that were separated from water are released back out into the air as clean breathable oxygen.',
            },
          ],
        },
        visual: {
          diagramTitle: 'Interactive Photosynthesis Diagram',
          diagramDescription: 'An interactive schematic showing sunlight beaming down on a green leaf, water ascending from the roots, carbon dioxide entering the stomata, and oxygen + glucose emerging.',
          visualElements: [
            { label: 'Sunlight', role: 'Radiant energy input', icon: 'sun' },
            { label: 'Water (H2O)', role: 'Liquid input via roots', icon: 'droplet' },
            { label: 'Carbon Dioxide (CO2)', role: 'Atmospheric gas input', icon: 'wind' },
            { label: 'Chloroplast', role: 'Green reaction chamber', icon: 'leaf' },
            { label: 'Glucose (C6H12O6)', role: 'Primary sugar output', icon: 'sparkles' },
            { label: 'Oxygen (O2)', role: 'Gaseous atmospheric output', icon: 'cloud' },
          ],
          flowDescription: [
            'Input 1: Sunlight warms leaf chloroplasts',
            'Input 2: Roots draw water upwards through stem',
            'Input 3: Leaf stomata intake carbon dioxide',
            'Transformation: 6CO2 + 6H2O + Sunlight → C6H12O6 + 6O2',
            'Output 1: Sugar feeds growing stems and flowers',
            'Output 2: Pure oxygen enriches the surrounding air',
          ],
        },
        audioScript: {
          intro: 'Welcome to this audio lesson on photosynthesis. Sit comfortably. We will explore how plants create food and clean air.',
          spokenSections: [
            {
              cue: 'Introduction to plant energy',
              text: 'Have you ever wondered where plants get their energy? Unlike humans, plants do not eat meals. Instead, they produce food directly through sunlight.',
            },
            {
              cue: 'The three inputs',
              text: 'Remember three ingredients: warm sunshine, cool water from the soil, and carbon dioxide from the air. In the leaf, these three meet.',
            },
            {
              cue: 'The outcome',
              text: 'The plant transforms these ingredients into sweet plant sugar called glucose, and releases the oxygen that we breathe every second.',
            },
          ],
          summarySpeech: 'In summary, photosynthesis powers Earth by turning sunlight, water, and carbon dioxide into life-sustaining sugar and oxygen.',
        },
      },
      keyTakeaways: [
        'Photosynthesis is how green plants convert solar energy into chemical energy.',
        'Inputs needed: Sunlight + Water + Carbon Dioxide.',
        'Outputs produced: Glucose (plant food) + Oxygen (air to breathe).',
        'Chlorophyll is the green pigment in chloroplasts that absorbs sunlight.',
      ],
      summary: 'Photosynthesis transforms sunlight, water, and carbon dioxide into glucose sugar and oxygen, sustaining plant life and providing oxygen for living creatures.',
      quizQuestions: [
        {
          id: 'q1',
          question: 'What are the three main raw ingredients required for photosynthesis?',
          options: [
            'Sunlight, Water, and Carbon Dioxide',
            'Soil, Oxygen, and Sugar',
            'Wind, Salt, and Nitrogen',
            'Moonlight, Rain, and Smoke',
          ],
          correctAnswerIndex: 0,
          explanation: 'Green plants require radiant sunlight, water absorbed by roots, and carbon dioxide from the air.',
          hint: 'Think about what plants drink from soil and breathe from air on a sunny day.',
          concept: 'Photosynthesis Inputs',
        },
        {
          id: 'q2',
          question: 'Which vital gas do green plants release as a byproduct during photosynthesis?',
          options: ['Carbon Dioxide', 'Oxygen', 'Methane', 'Helium'],
          correctAnswerIndex: 1,
          explanation: 'Plants release oxygen gas into the atmosphere, which animals and humans breathe.',
          hint: 'It is the gas your lungs need right now!',
          concept: 'Photosynthesis Outputs',
        },
        {
          id: 'q3',
          question: 'What is the name of the green pigment inside leaves that captures sunlight?',
          options: ['Hemoglobin', 'Chlorophyll', 'Melanin', 'Keratin'],
          correctAnswerIndex: 1,
          explanation: 'Chlorophyll gives plants their green coloration and traps photons from sunlight.',
          hint: 'Starts with the letters Chloro-.',
          concept: 'Leaf Cellular Biology',
        },
        {
          id: 'q4',
          question: 'What type of sugar food is created by the plant during this process?',
          options: ['Glucose', 'Table Salt', 'Vinegar', 'Lactose'],
          correctAnswerIndex: 0,
          explanation: 'Glucose (C6H12O6) is the simple carbohydrate sugar created to power plant growth.',
          hint: 'A word starting with G that means simple natural sugar.',
          concept: 'Chemical Products',
        },
        {
          id: 'q5',
          question: 'Through which microscopic leaf pores does carbon dioxide enter the plant?',
          options: ['Stomata', 'Bark cracks', 'Flower petals', 'Seed coats'],
          correctAnswerIndex: 0,
          explanation: 'Stomata are microscopic pores located primarily on the underside of leaves that open and close for gas exchange.',
          hint: 'The word sounds like "stomach openings" on leaf undersides.',
          concept: 'Leaf Anatomy',
        },
      ],
      aiGenerated: false,
    };
  }

  // Generic fallback for any arbitrary subject
  const paragraphs = content
    .split('\n')
    .map((p) => p.trim())
    .filter((p) => p.length > 0);
  const firstPara = paragraphs[0] || content.slice(0, 300);

  return {
    title: title || 'Adapted Educational Lesson',
    subject: subject || 'General Knowledge',
    originalText: content,
    readingLevel: 'Custom Learner Adapted',
    variants: {
      standard: {
        content: content,
        sections: paragraphs.map((p, idx) => ({
          title: `Section ${idx + 1}`,
          body: p,
        })),
      },
      simplified: {
        content: `Here is a clear, simple version of this lesson. ${firstPara.replace(/([.!?])\s+/g, '$1\n\n')}`,
        simplifiedWords: [
          { complex: 'Fundamental', simple: 'Important', definition: 'A key main idea' },
          { complex: 'Process', simple: 'Steps', definition: 'Actions done in order' },
          { complex: 'Mechanism', simple: 'How it works', definition: 'The parts that make something happen' },
        ],
        sections: paragraphs.slice(0, 3).map((p, idx) => ({
          title: `Part ${idx + 1}: Simple View`,
          body: p.slice(0, 200) + '... (explained simply in direct sentences).',
        })),
      },
      largeText: {
        content: content.toUpperCase().slice(0, 600),
        chunkedParagraphs: paragraphs.slice(0, 4),
      },
      stepByStep: {
        steps: paragraphs.slice(0, 4).map((p, idx) => ({
          stepNumber: idx + 1,
          title: `Key Milestone ${idx + 1}`,
          explanation: p,
          actionTip: 'Take a brief pause here to absorb this concept before continuing.',
        })),
      },
      visual: {
        diagramTitle: `${title} - Visual Structure`,
        diagramDescription: `A visual map organizing the core concepts of ${title} into clear connected modules.`,
        visualElements: [
          { label: 'Foundation Concept', role: 'Starting idea', icon: 'book' },
          { label: 'Key Process', role: 'Active mechanism', icon: 'zap' },
          { label: 'Outcome & Impact', role: 'End result', icon: 'check-circle' },
        ],
        flowDescription: [
          'Step 1: Understand the core baseline',
          'Step 2: Connect the mechanism to everyday life',
          'Step 3: Review the major result',
        ],
      },
      audioScript: {
        intro: `Hello and welcome. Today we are learning about ${title}. Let us listen together.`,
        spokenSections: paragraphs.slice(0, 3).map((p, idx) => ({
          cue: `Point ${idx + 1}`,
          text: p,
        })),
        summarySpeech: `That concludes our audio overview of ${title}. You have done wonderful work listening today.`,
      },
    },
    keyTakeaways: [
      `Key insight on ${title}.`,
      'Main principles explained in multiple formats.',
      'Core learning objectives preserved without loss of meaning.',
    ],
    summary: `Summary of ${title}: An accessible breakdown preserving all crucial facts and definitions.`,
    quizQuestions: [
      {
        id: 'q1',
        question: `What is the central focus of ${title}?`,
        options: [
          `Understanding the core concepts of ${title}`,
          'An unrelated random topic',
          'Memorizing arbitrary symbols',
          'Historical speculation only',
        ],
        correctAnswerIndex: 0,
        explanation: `This lesson explores the primary mechanisms and principles of ${title}.`,
        hint: 'Look closely at the title of the lesson.',
        concept: 'Core Subject',
      },
      {
        id: 'q2',
        question: 'Why is adapting educational content into multiple formats beneficial?',
        options: [
          'Every learner has unique strengths, preferences, and accessibility needs',
          'It makes all lessons strictly identical for everyone',
          'It deletes important scientific facts',
          'It requires no feedback',
        ],
        correctAnswerIndex: 0,
        explanation: 'Multi-format learning honors diverse neurodiversity, sensory needs, and learning paces.',
        hint: 'Think about why having audio, large text, and visuals helps different learners.',
        concept: 'Adaptive Learning',
      },
    ],
    aiGenerated: false,
  };
}

/**
 * Adapt lesson content using Gemini 3.8 Flash if available, otherwise fallback reliably.
 */
export async function adaptLessonWithAI(
  title: string,
  subject: string,
  content: string
): Promise<AdaptedLessonPayload> {
  const ai = getGeminiClient();
  if (!ai) {
    return generateDeterministicAdaptation(title, subject, content);
  }

  try {
    const prompt = `You are AdaptEd's AI Adaptive Learning Engine. Your mission is to take educational lesson content and adapt it into multiple accessible formats for students with diverse learning styles and accessibility requirements (including Dyslexia, ADHD, Visual impairment, Audio preferences, and varying reading levels).

CRITICAL REQUIREMENT:
You must strictly preserve all educational facts, scientific accuracy, definitions, formulas, and learning objectives. Never change the underlying factual meaning.

Lesson Title: ${title}
Subject: ${subject}
Original Text:
${content}

Return a valid JSON object matching this schema:
{
  "variants": {
    "standard": {
      "content": "...",
      "sections": [{"title": "...", "body": "..."}]
    },
    "simplified": {
      "content": "Simple English version (shorter sentences, active voice, everyday vocabulary)",
      "simplifiedWords": [{"complex": "...", "simple": "...", "definition": "..."}],
      "sections": [{"title": "...", "body": "..."}]
    },
    "largeText": {
      "content": "Clean, highly readable text with short chunked paragraphs",
      "chunkedParagraphs": ["...", "..."]
    },
    "stepByStep": {
      "steps": [{"stepNumber": 1, "title": "...", "explanation": "...", "actionTip": "..."}]
    },
    "visual": {
      "diagramTitle": "...",
      "diagramDescription": "...",
      "visualElements": [{"label": "...", "role": "...", "icon": "..."}],
      "flowDescription": ["...", "..."]
    },
    "audioScript": {
      "intro": "Warm, encouraging spoken introduction",
      "spokenSections": [{"cue": "...", "text": "..."}],
      "summarySpeech": "..."
    }
  },
  "keyTakeaways": ["...", "...", "..."],
  "summary": "...",
  "quizQuestions": [
    {
      "id": "q1",
      "question": "...",
      "options": ["A", "B", "C", "D"],
      "correctAnswerIndex": 0,
      "explanation": "...",
      "hint": "...",
      "concept": "..."
    }
  ]
}`;

    const timeoutPromise = new Promise<null>((_, reject) =>
      setTimeout(() => reject(new Error('Gemini API call timed out')), 15000)
    );

    const callPromise = ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const response: any = await Promise.race([callPromise, timeoutPromise]);

    const text = response.text;
    if (text) {
      const parsed = JSON.parse(text);
      return {
        title,
        subject,
        originalText: content,
        readingLevel: 'AI Adaptive Multi-Level',
        variants: parsed.variants,
        keyTakeaways: parsed.keyTakeaways || [],
        summary: parsed.summary || '',
        quizQuestions: parsed.quizQuestions || [],
        aiGenerated: true,
        modelUsed: 'gemini-3.8-flash',
      };
    }
  } catch (err) {
    console.error('Error invoking Gemini for lesson adaptation; falling back safely:', err);
  }

  return generateDeterministicAdaptation(title, subject, content);
}
