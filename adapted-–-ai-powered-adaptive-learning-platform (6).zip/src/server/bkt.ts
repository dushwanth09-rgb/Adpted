/**
 * Bayesian Knowledge Tracing (BKT) Engine for AdaptEd
 * 
 * Standard 4-parameter BKT model:
 * - P(L0): Prior probability of initial mastery
 * - P(T): Transition probability (learning rate from an opportunity)
 * - P(G): Guess probability (getting it right without knowing)
 * - P(S): Slip probability (getting it wrong despite knowing)
 */

export interface BKTParameters {
  pL0: number; // Initial knowledge
  pT: number;  // Probability of learning
  pG: number;  // Probability of guess
  pS: number;  // Probability of slip
}

export const DEFAULT_BKT_PARAMS: Record<string, BKTParameters> = {
  science_general: { pL0: 0.35, pT: 0.15, pG: 0.20, pS: 0.10 },
  photosynthesis: { pL0: 0.30, pT: 0.18, pG: 0.20, pS: 0.08 },
  solar_system: { pL0: 0.40, pT: 0.14, pG: 0.25, pS: 0.10 },
  water_cycle: { pL0: 0.45, pT: 0.16, pG: 0.20, pS: 0.08 },
  fractions: { pL0: 0.25, pT: 0.12, pG: 0.15, pS: 0.12 },
};

/**
 * Update the probability of mastery given a quiz attempt result (correct / incorrect)
 * 
 * Bayes Theorem:
 * P(L_t | correct) = (P(L_{t-1}) * (1 - P(S))) / [P(L_{t-1}) * (1 - P(S)) + (1 - P(L_{t-1})) * P(G)]
 * P(L_t | incorrect) = (P(L_{t-1}) * P(S)) / [P(L_{t-1}) * P(S) + (1 - P(L_{t-1})) * (1 - P(G))]
 * 
 * Transition to next opportunity:
 * P(L_{t+1}) = P(L_t | Obs) + (1 - P(L_t | Obs)) * P(T)
 */
export function updateMasteryBKT(
  currentMastery: number,
  isCorrect: boolean,
  params: BKTParameters = DEFAULT_BKT_PARAMS.photosynthesis
): { updatedMastery: number; posterior: number; expectedAccuracy: number } {
  const { pT, pG, pS } = params;
  const pL_prev = Math.min(Math.max(currentMastery, 0.01), 0.99);

  let posterior: number;

  if (isCorrect) {
    const numerator = pL_prev * (1 - pS);
    const denominator = numerator + (1 - pL_prev) * pG;
    posterior = denominator > 0 ? numerator / denominator : pL_prev;
  } else {
    const numerator = pL_prev * pS;
    const denominator = numerator + (1 - pL_prev) * (1 - pG);
    posterior = denominator > 0 ? numerator / denominator : pL_prev;
  }

  // Next step transition with learning
  const updatedMastery = posterior + (1 - posterior) * pT;

  // Expected probability of answering correctly on next question
  const expectedAccuracy = updatedMastery * (1 - pS) + (1 - updatedMastery) * pG;

  return {
    updatedMastery: Math.min(Math.max(Number(updatedMastery.toFixed(4)), 0.05), 0.99),
    posterior: Number(posterior.toFixed(4)),
    expectedAccuracy: Number(expectedAccuracy.toFixed(4)),
  };
}

/**
 * Contextual Multi-Armed Bandit for Content Format Recommendation
 * 
 * Arms represent format + difficulty pairings:
 * - standard_easy
 * - standard_medium
 * - simplified_easy
 * - simplified_medium
 * - audio_easy
 * - visual_medium
 * - large_text_medium
 */
export interface BanditArm {
  id: string;
  name: string;
  format: 'standard' | 'simplified' | 'large_text' | 'audio' | 'visual' | 'step_by_step';
  difficulty: 'easy' | 'medium' | 'advanced';
  pulls: number;
  totalReward: number;
  averageReward: number;
}

export interface BanditRecommendation {
  armId: string;
  format: 'standard' | 'simplified' | 'large_text' | 'audio' | 'visual' | 'step_by_step';
  difficulty: 'easy' | 'medium' | 'advanced';
  explanation: string;
  confidence: number;
  isOverrideFromPreference: boolean;
}

export const INITIAL_ARMS: BanditArm[] = [
  { id: 'standard_easy', name: 'Standard Text (Easy)', format: 'standard', difficulty: 'easy', pulls: 12, totalReward: 8.5, averageReward: 0.71 },
  { id: 'standard_medium', name: 'Standard Text (Medium)', format: 'standard', difficulty: 'medium', pulls: 15, totalReward: 9.8, averageReward: 0.65 },
  { id: 'simplified_easy', name: 'Simplified English (Easy)', format: 'simplified', difficulty: 'easy', pulls: 22, totalReward: 18.2, averageReward: 0.83 },
  { id: 'simplified_medium', name: 'Simplified English (Medium)', format: 'simplified', difficulty: 'medium', pulls: 18, totalReward: 14.1, averageReward: 0.78 },
  { id: 'audio_easy', name: 'Audio-First Lesson (Easy)', format: 'audio', difficulty: 'easy', pulls: 25, totalReward: 21.5, averageReward: 0.86 },
  { id: 'visual_medium', name: 'Visual & Interactive (Medium)', format: 'visual', difficulty: 'medium', pulls: 20, totalReward: 16.8, averageReward: 0.84 },
  { id: 'large_text_medium', name: 'Large Text Format (Medium)', format: 'large_text', difficulty: 'medium', pulls: 14, totalReward: 11.2, averageReward: 0.80 },
];

/**
 * Select recommended arm using epsilon-greedy + contextual preference weighting
 * Explicit user accessibility preferences ALWAYS have priority constraint.
 */
export function recommendFormat(
  arms: BanditArm[],
  learnerPreferences: {
    primaryFormat?: string;
    learningPace?: string;
    readingLevel?: string;
    audioPreferred?: boolean;
    visualPreferred?: boolean;
    largeTextPreferred?: boolean;
  },
  currentMastery: number
): BanditRecommendation {
  // If user explicitly configured strong preferences, respect and map them
  if (learnerPreferences.largeTextPreferred) {
    return {
      armId: 'large_text_medium',
      format: 'large_text',
      difficulty: currentMastery > 0.7 ? 'medium' : 'easy',
      explanation: 'Directly prioritized based on your selected Large Text accessibility preference.',
      confidence: 0.98,
      isOverrideFromPreference: true,
    };
  }

  if (learnerPreferences.audioPreferred && !learnerPreferences.visualPreferred) {
    return {
      armId: 'audio_easy',
      format: 'audio',
      difficulty: currentMastery > 0.6 ? 'medium' : 'easy',
      explanation: 'Audio learning format selected to match your listening preference and optimize retention.',
      confidence: 0.94,
      isOverrideFromPreference: true,
    };
  }

  if (learnerPreferences.visualPreferred && !learnerPreferences.audioPreferred) {
    return {
      armId: 'visual_medium',
      format: 'visual',
      difficulty: currentMastery > 0.6 ? 'medium' : 'easy',
      explanation: 'Visual & diagrammatic format selected to match your visual learning preference.',
      confidence: 0.95,
      isOverrideFromPreference: true,
    };
  }

  // Multi-armed bandit reward calculation with mastery context
  let bestArm = arms[0];
  let highestScore = -1;

  for (const arm of arms) {
    // Upper Confidence Bound (UCB1) style score
    const exploitation = arm.averageReward;
    const exploration = Math.sqrt((2 * Math.log(100)) / (arm.pulls + 1));
    let score = exploitation + 0.3 * exploration;

    // Contextual boost: if student has lower mastery, boost simplified and step-by-step
    if (currentMastery < 0.5 && (arm.format === 'simplified' || arm.difficulty === 'easy')) {
      score += 0.25;
    }
    // If student has high mastery, allow standard medium
    if (currentMastery > 0.75 && arm.difficulty === 'medium') {
      score += 0.15;
    }

    if (score > highestScore) {
      highestScore = score;
      bestArm = arm;
    }
  }

  return {
    armId: bestArm.id,
    format: bestArm.format,
    difficulty: bestArm.difficulty,
    explanation: `Bandit engine selected ${bestArm.name} based on ${Math.round(currentMastery * 100)}% mastery and highest engagement reward.`,
    confidence: Number(Math.min(0.70 + bestArm.averageReward * 0.25, 0.96).toFixed(2)),
    isOverrideFromPreference: false,
  };
}
