import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import { generateDeterministicAdaptation, AdaptedLessonPayload } from './aiAdaptation.ts';
import { INITIAL_ARMS, BanditArm, DEFAULT_BKT_PARAMS } from './bkt.ts';

export interface User {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  role: 'student' | 'teacher' | 'guardian';
  avatar: string;
  createdAt: string;
}

export interface LearnerPreferences {
  primaryFormat: 'large_text' | 'simplified' | 'audio' | 'visual' | 'standard' | 'step_by_step';
  largeText: boolean;
  standardText: boolean;
  dyslexiaFont: boolean;
  highContrast: boolean;
  simplifiedLanguage: boolean;
  audioLearning: boolean;
  visualLearning: boolean;
  captions: boolean;
  increasedLineSpacing: boolean;
  reducedMotion: boolean;
  speechRate: number;
}

export interface LearnerProfile {
  userId: string;
  name: string;
  age: number;
  grade: string;
  preferredLanguage: string;
  subjectInterests: string[];
  learningPace: 'slow' | 'moderate' | 'fast' | 'ai_recommend';
  readingLevel: 'simple' | 'intermediate' | 'advanced';
  preferences: LearnerPreferences;
  initialMastery: number;
  currentMastery: number;
  streakDays: number;
  lessonsCompleted: number;
  quizAccuracy: number;
  lastActive: string;
  currentLessonId?: string;
}

export interface Lesson {
  id: string;
  title: string;
  subject: string;
  topic: string;
  summary: string;
  content: string;
  durationMinutes: number;
  gradeLevel: string;
  published: boolean;
  authorId: string;
  adaptation: AdaptedLessonPayload;
  createdAt: string;
}

export interface MasteryRecord {
  studentId: string;
  topic: string;
  pMastery: number;
  attemptsCount: number;
  correctCount: number;
  lastUpdated: string;
  history: Array<{ date: string; pMastery: number; isCorrect: boolean; questionId?: string }>;
}

export interface AttemptLog {
  id: string;
  studentId: string;
  lessonId: string;
  questionId: string;
  questionText: string;
  selectedOption: number;
  isCorrect: boolean;
  timestamp: string;
  pMasteryBefore: number;
  pMasteryAfter: number;
}

export interface LessonFeedback {
  id: string;
  studentId: string;
  lessonId: string;
  rating: 'too_easy' | 'too_difficult' | 'just_right' | 'need_another_format';
  formatUsed: string;
  comment?: string;
  timestamp: string;
}

export interface TeacherAlert {
  id: string;
  teacherId: string;
  studentId: string;
  studentName: string;
  type: 'low_mastery' | 'format_recommendation' | 'streak_celebration' | 'stuck_topic';
  title: string;
  message: string;
  suggestedAction: string;
  read: boolean;
  createdAt: string;
}

export interface DatabaseSchema {
  users: User[];
  learnerProfiles: Record<string, LearnerProfile>;
  lessons: Lesson[];
  masteryStates: Record<string, Record<string, MasteryRecord>>; // studentId -> topic -> record
  attempts: AttemptLog[];
  feedbackList: LessonFeedback[];
  alerts: TeacherAlert[];
  banditArms: BanditArm[];
  guardianRelationships: Array<{ guardianId: string; studentId: string; relationship: string }>;
}

const DB_DIR = path.resolve(process.cwd(), '.data');
const DB_FILE = path.join(DB_DIR, 'adapted_db.json');

let dbMemory: DatabaseSchema | null = null;

export function getDatabase(): DatabaseSchema {
  if (dbMemory) return dbMemory;

  if (fs.existsSync(DB_FILE)) {
    try {
      const raw = fs.readFileSync(DB_FILE, 'utf-8');
      dbMemory = JSON.parse(raw);
      return dbMemory!;
    } catch (err) {
      console.error('Failed reading existing db file, seeding fresh:', err);
    }
  }

  // Create default seeded database
  dbMemory = createSeededDatabase();
  saveDatabase();
  return dbMemory;
}

export function saveDatabase(): void {
  if (!dbMemory) return;
  try {
    if (!fs.existsSync(DB_DIR)) {
      fs.mkdirSync(DB_DIR, { recursive: true });
    }
    fs.writeFileSync(DB_FILE, JSON.stringify(dbMemory, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to write db file:', err);
  }
}

function createSeededDatabase(): DatabaseSchema {
  const salt = bcrypt.genSaltSync(10);
  const defaultPasswordHash = bcrypt.hashSync('adapted123', salt);

  const studentA: User = {
    id: 'user_student_a',
    name: 'Aarav Sharma',
    email: 'student.a@adapted.demo',
    passwordHash: defaultPasswordHash,
    role: 'student',
    avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=150&q=80',
    createdAt: new Date(Date.now() - 14 * 86400000).toISOString(),
  };

  const studentB: User = {
    id: 'user_student_b',
    name: 'Meera Rao',
    email: 'student.b@adapted.demo',
    passwordHash: defaultPasswordHash,
    role: 'student',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
    createdAt: new Date(Date.now() - 20 * 86400000).toISOString(),
  };

  const teacher: User = {
    id: 'user_teacher_1',
    name: 'Ms. Elena Sharma',
    email: 'teacher@adapted.demo',
    passwordHash: defaultPasswordHash,
    role: 'teacher',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80',
    createdAt: new Date(Date.now() - 60 * 86400000).toISOString(),
  };

  const guardian: User = {
    id: 'user_guardian_1',
    name: 'Mr. Rajesh Patel',
    email: 'parent@adapted.demo',
    passwordHash: defaultPasswordHash,
    role: 'guardian',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
    createdAt: new Date(Date.now() - 14 * 86400000).toISOString(),
  };

  const profileA: LearnerProfile = {
    userId: studentA.id,
    name: studentA.name,
    age: 12,
    grade: 'Grade 6',
    preferredLanguage: 'English',
    subjectInterests: ['Life Science', 'Nature', 'Space'],
    learningPace: 'slow',
    readingLevel: 'simple',
    preferences: {
      primaryFormat: 'large_text',
      largeText: true,
      standardText: false,
      dyslexiaFont: true,
      highContrast: false,
      simplifiedLanguage: true,
      audioLearning: true,
      visualLearning: false,
      captions: true,
      increasedLineSpacing: true,
      reducedMotion: true,
      speechRate: 0.9,
    },
    initialMastery: 0.35,
    currentMastery: 0.48,
    streakDays: 4,
    lessonsCompleted: 3,
    quizAccuracy: 0.72,
    lastActive: new Date().toISOString(),
    currentLessonId: 'lesson_photosynthesis',
  };

  const profileB: LearnerProfile = {
    userId: studentB.id,
    name: studentB.name,
    age: 12,
    grade: 'Grade 6',
    preferredLanguage: 'English',
    subjectInterests: ['Biology', 'Mathematics', 'Chemistry'],
    learningPace: 'moderate',
    readingLevel: 'intermediate',
    preferences: {
      primaryFormat: 'simplified',
      largeText: false,
      standardText: false,
      dyslexiaFont: false,
      highContrast: false,
      simplifiedLanguage: true,
      audioLearning: false,
      visualLearning: true,
      captions: false,
      increasedLineSpacing: false,
      reducedMotion: false,
      speechRate: 1.0,
    },
    initialMastery: 0.60,
    currentMastery: 0.76,
    streakDays: 7,
    lessonsCompleted: 6,
    quizAccuracy: 0.88,
    lastActive: new Date().toISOString(),
    currentLessonId: 'lesson_photosynthesis',
  };

  // Seed standard lessons
  const photosynthesisAdaptation = generateDeterministicAdaptation(
    'Photosynthesis: How Plants Make Food',
    'Science',
    'Photosynthesis is the process through which green plants convert sunlight, carbon dioxide and water into glucose and oxygen.'
  );

  const waterCycleAdaptation = generateDeterministicAdaptation(
    "The Water Cycle: Earth's Natural Recycler",
    'Science',
    'The water cycle describes how water evaporates from the surface of the earth, rises into the atmosphere, cools and condenses into rain or snow in clouds, and falls again to the surface as precipitation.'
  );

  const solarSystemAdaptation = generateDeterministicAdaptation(
    'Our Solar System: Planets in Motion',
    'Science',
    'The solar system consists of the Sun and everything bound to it by gravity: the planets Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, and Neptune, along with dwarf planets and asteroids.'
  );

  const curriculumUnits = [
    // English (12 lessons)
    { subject: 'English', unit: 'English Language & Core Skills', titles: [
      'English Grammar Basics',
      'Parts of Speech',
      'Nouns and Pronouns',
      'Verbs and Tenses',
      'Sentence Formation',
      'Reading Comprehension',
      'Vocabulary Development',
      'Synonyms and Antonyms',
      'Essay Writing',
      'Creative Writing',
      'Punctuation',
      'Communication Skills'
    ]},

    // Mathematics (12 lessons)
    { subject: 'Mathematics', unit: 'Mathematics & Arithmetic', titles: [
      'Number Systems',
      'Addition and Subtraction',
      'Multiplication and Division',
      'Fractions',
      'Decimals',
      'Percentages',
      'Algebra Basics',
      'Geometry',
      'Mensuration',
      'Ratio and Proportion',
      'Basic Statistics',
      'Probability'
    ]},

    // Science (12 lessons)
    { subject: 'Science', unit: 'Science & Natural Philosophy', titles: [
      'Introduction to Science',
      'Living and Non-Living Things',
      'Human Body Systems',
      'Plants and Photosynthesis',
      'Animals and Habitats',
      'Matter and Its States',
      'Force and Motion',
      'Light and Sound',
      'Electricity and Magnetism',
      'Solar System',
      'Environment and Ecosystems',
      'Water Cycle'
    ]},

    // Social Studies (12 lessons)
    { subject: 'Social Studies', unit: 'Social Studies & History', titles: [
      'Introduction to History',
      'Ancient Civilizations',
      'Indian History',
      'Freedom Movement of India',
      'Geography Basics',
      'Continents and Oceans',
      'Climate and Weather',
      'Natural Resources',
      'Indian Constitution',
      'Democracy and Government',
      'World Geography',
      'Culture and Heritage'
    ]},

    // Computer Science (12 lessons)
    { subject: 'Computer Science', unit: 'Computer Science & Technology', titles: [
      'Introduction to Computers',
      'Computer Hardware',
      'Computer Software',
      'Input and Output Devices',
      'Operating Systems',
      'Internet and Networking',
      'Introduction to Programming',
      'HTML and CSS Basics',
      'JavaScript Basics',
      'Python Programming',
      'Cybersecurity',
      'Artificial Intelligence Basics'
    ]}
  ];

  const lessons: Lesson[] = [
    {
      id: 'lesson_photosynthesis',
      title: 'Photosynthesis: How Plants Make Food',
      subject: 'Science',
      topic: 'photosynthesis',
      summary: 'Learn how green leaves capture solar energy to produce glucose sugar and life-sustaining oxygen.',
      content: 'Photosynthesis is the process through which green plants convert sunlight, carbon dioxide and water into glucose and oxygen.',
      durationMinutes: 15,
      gradeLevel: 'Grade 6',
      published: true,
      authorId: teacher.id,
      adaptation: photosynthesisAdaptation,
      createdAt: new Date(Date.now() - 10 * 86400000).toISOString(),
    },
    {
      id: 'lesson_water_cycle',
      title: "The Water Cycle: Earth's Natural Recycler",
      subject: 'Science',
      topic: 'water_cycle',
      summary: 'Explore evaporation, condensation, precipitation, and collection across our planet.',
      content: 'The water cycle describes how water evaporates from the surface of the earth, rises into the atmosphere, cools and condenses into rain or snow in clouds, and falls again to the surface as precipitation.',
      durationMinutes: 12,
      gradeLevel: 'Grade 6',
      published: true,
      authorId: teacher.id,
      adaptation: waterCycleAdaptation,
      createdAt: new Date(Date.now() - 7 * 86400000).toISOString(),
    },
    {
      id: 'lesson_solar_system',
      title: 'Our Solar System: Planets in Motion',
      subject: 'Science',
      topic: 'solar_system',
      summary: 'Discover the celestial orbits of terrestrial and gas giant planets around our radiant sun.',
      content: 'The solar system consists of the Sun and everything bound to it by gravity: the planets Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, and Neptune, along with dwarf planets and asteroids.',
      durationMinutes: 18,
      gradeLevel: 'Grade 6',
      published: true,
      authorId: teacher.id,
      adaptation: solarSystemAdaptation,
      createdAt: new Date(Date.now() - 4 * 86400000).toISOString(),
    },
  ];

  let lessonIndex = 4;
  for (const cat of curriculumUnits) {
    for (const title of cat.titles) {
      const topicKey = title.toLowerCase().replace(/[^a-z0-9]/g, '_').slice(0, 25);
      const contentText = `${title} is a core educational topic within ${cat.subject} (${cat.unit}). It provides essential foundational knowledge, practical examples, guided exercises, and interactive reviews for developing students.`;
      const adaptation = generateDeterministicAdaptation(title, cat.subject, contentText);
      lessons.push({
        id: `lesson_${cat.subject.toLowerCase().replace(/[^a-z]/g, '')}_${lessonIndex++}`,
        title,
        subject: cat.subject,
        topic: topicKey,
        summary: `Explore foundational concepts in ${cat.unit} regarding ${title}.`,
        content: contentText,
        durationMinutes: 15,
        gradeLevel: 'Grade 6',
        published: true,
        authorId: teacher.id,
        adaptation,
        createdAt: new Date(Date.now() - lessonIndex * 3600000).toISOString(),
      });
    }
  }

  // Seed mastery states for Aarav and Meera
  const masteryStates: Record<string, Record<string, MasteryRecord>> = {
    [studentA.id]: {
      photosynthesis: {
        studentId: studentA.id,
        topic: 'photosynthesis',
        pMastery: 0.48,
        attemptsCount: 6,
        correctCount: 4,
        lastUpdated: new Date(Date.now() - 3600000).toISOString(),
        history: [
          { date: new Date(Date.now() - 4 * 86400000).toISOString(), pMastery: 0.35, isCorrect: true },
          { date: new Date(Date.now() - 3 * 86400000).toISOString(), pMastery: 0.32, isCorrect: false },
          { date: new Date(Date.now() - 2 * 86400000).toISOString(), pMastery: 0.41, isCorrect: true },
          { date: new Date(Date.now() - 1 * 86400000).toISOString(), pMastery: 0.48, isCorrect: true },
        ],
      },
      water_cycle: {
        studentId: studentA.id,
        topic: 'water_cycle',
        pMastery: 0.55,
        attemptsCount: 5,
        correctCount: 4,
        lastUpdated: new Date(Date.now() - 2 * 86400000).toISOString(),
        history: [
          { date: new Date(Date.now() - 5 * 86400000).toISOString(), pMastery: 0.40, isCorrect: true },
          { date: new Date(Date.now() - 2 * 86400000).toISOString(), pMastery: 0.55, isCorrect: true },
        ],
      },
      solar_system: {
        studentId: studentA.id,
        topic: 'solar_system',
        pMastery: 0.42,
        attemptsCount: 3,
        correctCount: 2,
        lastUpdated: new Date(Date.now() - 6 * 86400000).toISOString(),
        history: [
          { date: new Date(Date.now() - 6 * 86400000).toISOString(), pMastery: 0.42, isCorrect: true },
        ],
      },
    },
    [studentB.id]: {
      photosynthesis: {
        studentId: studentB.id,
        topic: 'photosynthesis',
        pMastery: 0.76,
        attemptsCount: 8,
        correctCount: 7,
        lastUpdated: new Date(Date.now() - 2 * 3600000).toISOString(),
        history: [
          { date: new Date(Date.now() - 5 * 86400000).toISOString(), pMastery: 0.60, isCorrect: true },
          { date: new Date(Date.now() - 3 * 86400000).toISOString(), pMastery: 0.68, isCorrect: true },
          { date: new Date(Date.now() - 1 * 86400000).toISOString(), pMastery: 0.76, isCorrect: true },
        ],
      },
      water_cycle: {
        studentId: studentB.id,
        topic: 'water_cycle',
        pMastery: 0.82,
        attemptsCount: 6,
        correctCount: 6,
        lastUpdated: new Date(Date.now() - 3 * 86400000).toISOString(),
        history: [
          { date: new Date(Date.now() - 6 * 86400000).toISOString(), pMastery: 0.65, isCorrect: true },
          { date: new Date(Date.now() - 3 * 86400000).toISOString(), pMastery: 0.82, isCorrect: true },
        ],
      },
      solar_system: {
        studentId: studentB.id,
        topic: 'solar_system',
        pMastery: 0.70,
        attemptsCount: 5,
        correctCount: 4,
        lastUpdated: new Date(Date.now() - 4 * 86400000).toISOString(),
        history: [
          { date: new Date(Date.now() - 4 * 86400000).toISOString(), pMastery: 0.70, isCorrect: true },
        ],
      },
    },
  };

  const attempts: AttemptLog[] = [
    {
      id: 'att_1',
      studentId: studentA.id,
      lessonId: 'lesson_photosynthesis',
      questionId: 'q1',
      questionText: 'What are the three main raw ingredients required for photosynthesis?',
      selectedOption: 0,
      isCorrect: true,
      timestamp: new Date(Date.now() - 3600000).toISOString(),
      pMasteryBefore: 0.41,
      pMasteryAfter: 0.48,
    },
    {
      id: 'att_2',
      studentId: studentB.id,
      lessonId: 'lesson_photosynthesis',
      questionId: 'q2',
      questionText: 'Which vital gas do green plants release as a byproduct during photosynthesis?',
      selectedOption: 1,
      isCorrect: true,
      timestamp: new Date(Date.now() - 7200000).toISOString(),
      pMasteryBefore: 0.68,
      pMasteryAfter: 0.76,
    },
  ];

  const alerts: TeacherAlert[] = [
    {
      id: 'alert_1',
      teacherId: teacher.id,
      studentId: studentA.id,
      studentName: studentA.name,
      type: 'format_recommendation',
      title: 'Format Recommendation for Aarav',
      message: 'Student Aarav performs 28% better with audio and step-by-step explanations. Consider enabling the audio version of the next lesson.',
      suggestedAction: 'Enable audio mode on next assignment',
      read: false,
      createdAt: new Date(Date.now() - 12 * 3600000).toISOString(),
    },
    {
      id: 'alert_2',
      teacherId: teacher.id,
      studentId: studentA.id,
      studentName: studentA.name,
      type: 'low_mastery',
      title: 'Photosynthesis Concept Check',
      message: 'Aarav scored low on stomata leaf anatomy quiz questions. Simplified diagram recommended.',
      suggestedAction: 'Assign visual mini-review',
      read: false,
      createdAt: new Date(Date.now() - 24 * 3600000).toISOString(),
    },
    {
      id: 'alert_3',
      teacherId: teacher.id,
      studentId: studentB.id,
      studentName: studentB.name,
      type: 'streak_celebration',
      title: '7-Day Learning Streak: Meera Rao',
      message: 'Meera has completed 7 consecutive days of science lessons with 88% average quiz accuracy.',
      suggestedAction: 'Send encouragement badge',
      read: true,
      createdAt: new Date(Date.now() - 36 * 3600000).toISOString(),
    },
  ];

  const feedbackList: LessonFeedback[] = [
    {
      id: 'fb_1',
      studentId: studentA.id,
      lessonId: 'lesson_photosynthesis',
      rating: 'just_right',
      formatUsed: 'large_text',
      comment: 'The large text and audio narration made it super easy to understand the leaf parts.',
      timestamp: new Date(Date.now() - 2 * 86400000).toISOString(),
    },
    {
      id: 'fb_2',
      studentId: studentB.id,
      lessonId: 'lesson_photosynthesis',
      rating: 'just_right',
      formatUsed: 'simplified',
      comment: 'Loved the visual diagram showing the inputs and outputs.',
      timestamp: new Date(Date.now() - 86400000).toISOString(),
    },
  ];

  return {
    users: [studentA, studentB, teacher, guardian],
    learnerProfiles: {
      [studentA.id]: profileA,
      [studentB.id]: profileB,
    },
    lessons,
    masteryStates,
    attempts,
    feedbackList,
    alerts,
    banditArms: INITIAL_ARMS,
    guardianRelationships: [
      { guardianId: guardian.id, studentId: studentA.id, relationship: 'Parent' },
    ],
  };
}
